---
title: "Product Requirements Document (PRD)"
subtitle: "Aplikasi Pembelajaran Koding Diagnosis dan Terminologi Medis Berbasis Web"
---

# 1. Informasi Dokumen

| Item | Keterangan |
|---|---|
| Nama Produk | Aplikasi Pembelajaran Koding Diagnosis dan Terminologi Medis (nama kerja: **KodeMedis Learn**) |
| Versi Dokumen | 1.0 (Draft) |
| Tanggal | 20 Oktober 2026 |
| Platform | Web (responsif: desktop, tablet, ponsel) |
| Target Pengguna | Mahasiswa dan dosen program studi Rekam Medis dan Informasi Kesehatan (RMIK) |
| Status | Draft untuk ditinjau pemangku kepentingan |

# 2. Ringkasan Eksekutif

Aplikasi ini adalah media pembelajaran interaktif berbasis web bagi mahasiswa RMIK untuk mempelajari terminologi medis dan berlatih koding diagnosis. Sistem menyediakan materi pembelajaran, bank soal, simulasi kasus klinis, penilaian otomatis, dan pembahasan jawaban berbasis referensi yang relevan. Dosen dapat memantau hasil latihan dan perkembangan kompetensi mahasiswa melalui dashboard. Tujuan akhirnya adalah meningkatkan pemahaman proses koding secara praktis dan kesiapan mahasiswa menghadapi Praktik Kerja Lapangan (PKL).

# 3. Latar Belakang dan Permasalahan

## 3.1 Latar Belakang

Koding diagnosis (ICD-10) dan tindakan (ICD-9-CM) adalah kompetensi inti perekam medis. Kualitas koding berpengaruh langsung pada pelaporan morbiditas dan mortalitas, statistik kesehatan, serta klaim pembiayaan. Penguasaan kompetensi ini membutuhkan dasar terminologi medis yang kuat dan latihan berulang dengan kasus yang bervariasi.

## 3.2 Permasalahan

1. Latihan koding mahasiswa terbatas pada waktu kelas dan jumlah kasus yang tersedia.
2. Umpan balik atas hasil latihan lambat karena dosen harus menilai manual.
3. Dosen sulit memetakan kelemahan kompetensi mahasiswa secara objektif dan berkelanjutan.
4. Materi terminologi medis dan koding tersebar di banyak sumber dan tidak terstruktur.
5. Mahasiswa belum terbiasa dengan kasus klinis yang menyerupai dokumen rekam medis sebenarnya sebelum PKL.

# 4. Tujuan Produk

| Tujuan | Indikator Keberhasilan (target awal) |
|---|---|
| Meningkatkan penguasaan terminologi medis | Rata-rata skor kuis terminologi naik minimal 15% antara pretest dan posttest |
| Meningkatkan akurasi koding diagnosis | Akurasi koding pada simulasi kasus mencapai minimal 75% pada akhir semester |
| Mempercepat umpan balik | 100% soal objektif dinilai otomatis dalam kurang dari 3 detik |
| Memudahkan pemantauan dosen | Dosen dapat melihat perkembangan per mahasiswa dan per kelas tanpa rekap manual |
| Meningkatkan kesiapan PKL | Minimal 80% mahasiswa menilai aplikasi membantu kesiapan PKL (survei) |

**Di luar tujuan (non-goals) versi 1.0:** integrasi langsung dengan SIMRS rumah sakit, penggunaan data pasien nyata, aplikasi mobile native, dan fitur klaim INA-CBG penuh.

# 5. Pemangku Kepentingan dan Persona

| Peran | Kebutuhan Utama |
|---|---|
| Mahasiswa | Belajar mandiri, berlatih koding, mendapat nilai dan pembahasan instan, melihat progres |
| Dosen | Mengelola materi dan soal, memantau hasil kelas, mengidentifikasi mahasiswa yang perlu pendampingan |
| Admin Program Studi | Mengelola pengguna, kelas, dan pengaturan sistem |
| Pembimbing Lapangan / Alumni (opsional) | Berkontribusi kasus klinis dan masukan relevansi praktik |

## 5.1 Persona

- **Raisa (mahasiswa semester 3).** Kesulitan menghafal istilah medis dan menentukan kode pada kasus kompleks. Ingin latihan kapan saja dan langsung tahu letak kesalahannya.
- **Bu Ratna (dosen koding).** Mengampu tiga kelas. Ingin tahu bab atau blok ICD-10 mana yang paling sering salah dijawab mahasiswa agar bisa menyesuaikan pengajaran.
- **Pak Dedi (admin prodi).** Perlu mengimpor daftar mahasiswa per angkatan dan mengelola akun dengan cepat.

# 6. Ruang Lingkup

## 6.1 Dalam Lingkup (In Scope)

- Manajemen akun dan peran (mahasiswa, dosen, admin).
- Modul materi terminologi medis dan koding diagnosis.
- Bank soal (pilihan ganda, isian kode, mencocokkan, benar/salah).
- Simulasi kasus klinis dengan latihan koding diagnosis.
- Penilaian otomatis dan pembahasan jawaban bersitasi referensi.
- Dashboard dosen dan dashboard progres mahasiswa.
- Kamus terminologi medis dan pencarian kode ICD (referensi belajar).
- Laporan dan ekspor hasil (CSV/XLSX/PDF).

## 6.2 Di Luar Lingkup (Out of Scope) Versi 1.0

- Koding tindakan ICD-9-CM penuh (direncanakan fase 2, struktur data disiapkan sejak awal).
- Integrasi SIMRS/E-Klaim, dan data pasien riil.
- Fitur pembelajaran sosial (forum), gamifikasi lanjutan, dan aplikasi mobile native.

## 6.3 Asumsi dan Ketergantungan

- Seluruh kasus klinis bersifat fiktif atau sudah dianonimkan sepenuhnya.
- Data ICD-10 yang dipakai mengikuti edisi yang ditetapkan dan digunakan di Indonesia; lisensi dan hak penggunaan perlu dipastikan oleh institusi.
- Konten materi dan soal divalidasi oleh dosen pakar sebelum dipublikasikan.
- Institusi menyediakan hosting dan domain, serta pengguna memiliki akses internet.

# 7. Alur Pengguna Utama

1. **Belajar:** Mahasiswa masuk, memilih modul, membaca materi, menandai selesai.
2. **Latihan:** Mahasiswa mengerjakan kuis atau latihan per topik, mendapat skor dan pembahasan otomatis.
3. **Simulasi kasus:** Mahasiswa membaca ringkasan kasus (anamnesis, pemeriksaan, hasil penunjang, diagnosis dokter), menentukan diagnosis utama dan sekunder, lalu memasukkan kode ICD-10. Sistem menilai dan menampilkan pembahasan langkah koding.
4. **Pantau:** Dosen membuka dashboard, melihat rata-rata kelas, topik lemah, dan mahasiswa berisiko, lalu menindaklanjuti.
5. **Kelola konten:** Dosen membuat atau mengimpor materi dan soal, menetapkan tingkat kesulitan, topik, dan referensi.

# 8. Kebutuhan Fungsional

Prioritas: **P0** wajib (MVP), **P1** penting, **P2** tambahan.

## 8.1 Autentikasi dan Manajemen Pengguna

| ID | Kebutuhan | Prioritas |
|---|---|---|
| FR-01 | Login dan logout dengan email/NIM dan kata sandi; reset kata sandi lewat email | P0 |
| FR-02 | Peran dan hak akses: mahasiswa, dosen, admin (RBAC) | P0 |
| FR-03 | Admin dapat membuat, menonaktifkan, dan mengimpor akun massal (CSV) | P0 |
| FR-04 | Pengelolaan kelas/angkatan dan penautan dosen pengampu serta mahasiswa | P0 |
| FR-05 | Login tunggal (SSO) institusi | P2 |

## 8.2 Modul Materi Pembelajaran

| ID | Kebutuhan | Prioritas |
|---|---|---|
| FR-10 | Struktur materi: Modul > Topik > Subtopik (misalnya anatomi, sistem organ, prefiks/sufiks/akar kata, singkatan medis, bab ICD-10) | P0 |
| FR-11 | Penyajian materi berupa teks, gambar, tabel, dan tautan/berkas pendukung (PDF, video tertaut) | P0 |
| FR-12 | Dosen dapat membuat, mengubah, menerbitkan, dan mengarsipkan materi (editor teks kaya) | P0 |
| FR-13 | Penanda progres baca per mahasiswa dan fitur lanjutkan belajar | P1 |
| FR-14 | Kamus terminologi medis dengan pencarian, arti, asal kata (akar/prefiks/sufiks), dan contoh pemakaian | P0 |
| FR-15 | Flashcard terminologi dengan pengulangan berjarak (spaced repetition) | P2 |
| FR-16 | Pencarian kode dan istilah ICD-10 (referensi belajar), termasuk Volume 1 (Tabular) dan Volume 3 (Indeks Alfabetis) | P1 |

## 8.3 Bank Soal

| ID | Kebutuhan | Prioritas |
|---|---|---|
| FR-20 | Tipe soal: pilihan ganda, jawaban benar/salah, mencocokkan, isian singkat, isian kode ICD-10 | P0 |
| FR-21 | Atribut soal: topik, subtopik, tingkat kesulitan (mudah/sedang/sulit), kunci jawaban, pembahasan, referensi, status (draf/terbit) | P0 |
| FR-22 | Impor dan ekspor soal massal (CSV/XLSX) dengan templat | P1 |
| FR-23 | Pembuatan paket latihan/kuis dengan pemilihan soal manual atau acak berdasarkan topik dan tingkat kesulitan | P0 |
| FR-24 | Pengaturan kuis: durasi, jumlah percobaan, acak urutan soal/opsi, jadwal buka-tutup, mode latihan atau ujian | P1 |
| FR-25 | Telaah soal oleh dosen kedua sebelum terbit (alur persetujuan) | P2 |
| FR-26 | Analisis butir soal sederhana (tingkat kesukaran dan daya beda) | P2 |

## 8.4 Simulasi Kasus Klinis dan Latihan Koding

| ID | Kebutuhan | Prioritas |
|---|---|---|
| FR-30 | Kasus berisi: identitas fiktif, keluhan, riwayat, pemeriksaan fisik, hasil penunjang, terapi, dan diagnosis dokter, ditampilkan menyerupai resume medis | P0 |
| FR-31 | Mahasiswa mengisi diagnosis utama dan diagnosis sekunder beserta kode ICD-10 | P0 |
| FR-32 | Mahasiswa dapat melakukan pencarian kode ICD-10 selama latihan (mode bantuan) atau dinonaktifkan pada mode ujian | P1 |
| FR-33 | Kunci jawaban kasus mencakup diagnosis utama, diagnosis sekunder, kode yang diterima, dan bobot per komponen | P0 |
| FR-34 | Penilaian parsial: kode tepat sampai karakter ke-3 (kategori), ke-4 (subkategori), dan kode lengkap diberi bobot berbeda | P1 |
| FR-35 | Pembahasan langkah koding: identifikasi diagnosis utama, penentuan lead term, penelusuran Indeks, verifikasi di Tabular, aturan inklusi/eksklusi | P0 |
| FR-36 | Tingkat kasus: dasar, menengah, kompleks (komorbid, komplikasi, kode ganda dagger-asterisk, kode penyebab luar/morbiditas) | P1 |
| FR-37 | Pustaka kasus yang dapat dicari menurut sistem organ, bab ICD-10, dan tingkat kesulitan | P1 |
| FR-38 | Simulasi lanjutan: koding tindakan ICD-9-CM dan klaim | P2 (fase 2) |

## 8.5 Penilaian Otomatis dan Pembahasan

| ID | Kebutuhan | Prioritas |
|---|---|---|
| FR-40 | Penilaian otomatis soal objektif dan isian kode sesaat setelah dikirim | P0 |
| FR-41 | Penilaian isian kode dengan normalisasi (huruf besar/kecil, tanda titik, spasi) dan daftar kode alternatif yang diterima | P0 |
| FR-42 | Setiap soal dan kasus menampilkan pembahasan beserta rujukan (misalnya ICD-10 WHO, buku ajar, regulasi nasional) | P0 |
| FR-43 | Ringkasan hasil: skor, waktu, benar/salah per soal, dan topik yang perlu diperkuat | P0 |
| FR-44 | Riwayat percobaan dan kemampuan melihat ulang hasil | P0 |
| FR-45 | Dosen dapat mengoreksi atau menimpa nilai (override) dan memberi komentar pada jawaban kasus | P1 |
| FR-46 | Rekomendasi materi otomatis berdasarkan topik dengan skor rendah | P1 |

## 8.6 Dashboard Dosen

| ID | Kebutuhan | Prioritas |
|---|---|---|
| FR-50 | Ringkasan kelas: jumlah mahasiswa aktif, rata-rata skor, tingkat penyelesaian, dan aktivitas terbaru | P0 |
| FR-51 | Hasil per mahasiswa: riwayat nilai, waktu belajar, tren skor, dan capaian per topik | P0 |
| FR-52 | Peta kompetensi: capaian per topik/bab ICD-10 dalam bentuk grafik (radar/bar/heatmap) | P1 |
| FR-53 | Daftar soal dengan tingkat kesalahan tertinggi dan kesalahan koding yang sering muncul | P1 |
| FR-54 | Penanda mahasiswa berisiko (misalnya skor di bawah ambang atau tidak aktif) | P1 |
| FR-55 | Filter berdasarkan kelas, angkatan, periode, topik, dan tingkat kesulitan | P0 |
| FR-56 | Ekspor laporan ke CSV/XLSX/PDF | P1 |
| FR-57 | Pembanding capaian antar kelas atau antar semester | P2 |

## 8.7 Dashboard Mahasiswa

| ID | Kebutuhan | Prioritas |
|---|---|---|
| FR-60 | Ringkasan progres: modul selesai, skor terbaru, dan target | P0 |
| FR-61 | Grafik perkembangan kompetensi per topik dan kesiapan PKL (indikator kompetensi) | P1 |
| FR-62 | Daftar tugas/kuis yang aktif beserta tenggat | P1 |
| FR-63 | Pretest dan posttest untuk mengukur peningkatan | P1 |
| FR-64 | Lencana pencapaian dan papan peringkat opsional (dapat dimatikan dosen) | P2 |

## 8.8 Administrasi Sistem

| ID | Kebutuhan | Prioritas |
|---|---|---|
| FR-70 | Pengelolaan master data: program studi, kelas, mata kuliah, topik, dan tahun akademik | P0 |
| FR-71 | Log aktivitas (audit trail) untuk perubahan konten, nilai, dan akun | P1 |
| FR-72 | Pengumuman dan notifikasi (dalam aplikasi dan email) | P2 |
| FR-73 | Pencadangan data dan pemulihan | P0 |

# 9. Aturan Bisnis Penilaian

1. **Soal objektif:** benar = bobot penuh; salah = 0 (pengurangan nilai salah bersifat opsional per kuis).
2. **Isian kode:** nilai penuh bila cocok dengan kode kunci atau salah satu alternatif yang diterima.
3. **Kasus klinis (contoh bobot default, dapat diatur dosen):**
   - Diagnosis utama: 50%
   - Diagnosis sekunder: 30%
   - Kelengkapan kode tambahan (misalnya penyebab luar, kode ganda): 10%
   - Ketepatan alasan/penelusuran (opsional): 10%
4. **Penilaian parsial kode:** kategori 3 karakter benar mendapat 40% bobot komponen, subkategori 4 karakter benar 70%, kode lengkap 100% (nilai dapat dikonfigurasi).
5. **Ambang kompetensi default:** Mahir ≥ 85, Cakap 70–84, Berkembang 55–69, Perlu Pendampingan < 55 (dapat disesuaikan prodi).
6. Skor akhir topik dihitung dari percobaan terbaik atau terakhir sesuai pengaturan dosen.

# 10. Kebutuhan Non-Fungsional

| ID | Kategori | Kebutuhan |
|---|---|---|
| NFR-01 | Kinerja | Halaman utama dimuat ≤ 3 detik pada jaringan 4G; penilaian otomatis ≤ 3 detik |
| NFR-02 | Skalabilitas | Mendukung minimal 500 pengguna terdaftar dan 150 pengguna bersamaan saat ujian |
| NFR-03 | Ketersediaan | Ketersediaan ≥ 99% pada jam akademik; pencadangan harian |
| NFR-04 | Keamanan | HTTPS, kata sandi ter-hash (bcrypt/argon2), proteksi OWASP Top 10, pembatasan percobaan login, sesi berbatas waktu |
| NFR-05 | Privasi | Tidak ada data pasien nyata; data pengguna dikelola sesuai UU Pelindungan Data Pribadi |
| NFR-06 | Kegunaan | Antarmuka berbahasa Indonesia, mudah dipelajari tanpa pelatihan panjang, dan responsif di berbagai ukuran layar |
| NFR-07 | Aksesibilitas | Mengacu WCAG 2.1 AA (kontras, navigasi papan ketik, teks alternatif) |
| NFR-08 | Kompatibilitas | Peramban modern terbaru (Chrome, Edge, Firefox, Safari) |
| NFR-09 | Keandalan ujian | Jawaban tersimpan otomatis berkala sehingga tidak hilang saat koneksi terputus sementara |
| NFR-10 | Pemeliharaan | Kode terdokumentasi, pengujian otomatis, dan pembaruan data ICD yang terpisah dari kode aplikasi |
| NFR-11 | Integritas ujian | Opsi pengacakan soal, pembatasan waktu, dan pencatatan aktivitas dasar |

# 11. Arsitektur dan Usulan Teknologi

Pilihan teknologi bersifat usulan dan dapat disesuaikan dengan kompetensi tim dan infrastruktur institusi.

| Lapisan | Usulan |
|---|---|
| Front-end | React atau Next.js, Tailwind CSS, pustaka grafik (Chart.js/Recharts) |
| Back-end | Node.js (NestJS/Express) atau Laravel; REST API |
| Basis data | PostgreSQL (atau MySQL) |
| Penyimpanan berkas | Object storage (S3-compatible) atau penyimpanan lokal server |
| Pencarian | Pencarian teks penuh PostgreSQL untuk kamus dan ICD-10 |
| Autentikasi | JWT/sesi aman, RBAC |
| Deployment | Docker, server institusi atau cloud; CI/CD |

## 11.1 Entitas Data Utama

| Entitas | Atribut Utama |
|---|---|
| User | id, nama, email/NIM, peran, status |
| Class | id, nama kelas, tahun akademik, dosen pengampu |
| Enrollment | user_id, class_id |
| Module / Topic | id, judul, parent_id, urutan, status |
| Material | id, topic_id, konten, lampiran, referensi |
| Term (kamus) | id, istilah, arti, akar/prefiks/sufiks, contoh, sistem organ |
| ICDCode | kode, deskripsi, bab, blok, edisi, status valid |
| Question | id, tipe, topic_id, kesulitan, teks, opsi, kunci, pembahasan, referensi, status |
| Quiz / QuizItem | id, pengaturan, soal terpilih |
| Attempt / Answer | user_id, quiz_id, jawaban, skor, waktu mulai/selesai |
| ClinicalCase | id, narasi klinis, tingkat, topik, status |
| CaseKey | case_id, diagnosis utama/sekunder, kode diterima, bobot |
| CaseSubmission | user_id, case_id, jawaban kode, skor per komponen, komentar dosen |
| CompetencyScore | user_id, topic_id, skor, tanggal |
| ActivityLog | aktor, aksi, objek, waktu |

# 12. Kebutuhan Antarmuka (Daftar Layar)

**Mahasiswa:** Login, Beranda/Dashboard, Daftar Modul, Detail Materi, Kamus Istilah, Pencarian ICD-10, Daftar Kuis, Halaman Mengerjakan Kuis, Hasil dan Pembahasan, Pustaka Kasus, Halaman Simulasi Kasus, Riwayat dan Progres.

**Dosen:** Dashboard Kelas, Detail Mahasiswa, Kelola Materi, Kelola Bank Soal, Kelola Kuis, Kelola Kasus Klinis, Koreksi dan Komentar, Laporan dan Ekspor.

**Admin:** Kelola Pengguna, Kelola Kelas, Master Data, Log Aktivitas, Pengaturan Sistem.

# 13. Referensi Pembahasan dan Tata Kelola Konten

- Pembahasan wajib mencantumkan minimal satu rujukan: ICD-10 WHO (Volume 1, 2, 3), buku ajar terminologi medis dan koding, serta regulasi nasional yang relevan (misalnya Permenkes tentang Rekam Medis dan standar profesi perekam medis).
- Setiap konten memiliki status: draf, ditelaah, terbit, arsip; dan mencatat penulis, penelaah, serta tanggal revisi.
- Pembaruan edisi atau perubahan kode ICD dilakukan melalui proses versi data, sehingga soal lama tetap terkait dengan edisi yang digunakan saat dibuat.
- Kasus klinis dirancang fiktif; bila diadaptasi dari kasus nyata, wajib dianonimkan penuh dan disetujui institusi.

# 14. Metrik Keberhasilan

| Kategori | Metrik | Target Awal |
|---|---|---|
| Adopsi | Persentase mahasiswa aktif mingguan | ≥ 70% selama semester berjalan |
| Keterlibatan | Rata-rata latihan per mahasiswa per minggu | ≥ 3 sesi |
| Pembelajaran | Peningkatan skor pretest ke posttest | ≥ 15% |
| Kompetensi | Akurasi koding diagnosis pada kasus menengah | ≥ 75% |
| Efisiensi dosen | Pengurangan waktu rekap dan koreksi | ≥ 50% |
| Kepuasan | Skor kepuasan pengguna (SUS) | ≥ 70 |
| Kualitas teknis | Waktu henti pada masa ujian | ≤ 1% |

# 15. Rencana Rilis dan Tonggak

| Fase | Durasi Perkiraan | Cakupan |
|---|---|---|
| Fase 0: Penemuan | 2–3 minggu | Wawancara dosen/mahasiswa, penyusunan kurikulum modul, penetapan data ICD, desain UX |
| Fase 1: MVP | 8–10 minggu | Akun dan peran, materi, kamus, bank soal objektif, kuis, penilaian otomatis, dashboard dasar |
| Fase 2: Simulasi Kasus | 6–8 minggu | Kasus klinis, penilaian parsial kode, pembahasan langkah koding, dashboard kompetensi |
| Fase 3: Uji Coba | 4 minggu | Uji coba terbatas satu kelas, uji kegunaan, perbaikan |
| Fase 4: Peluncuran dan Evaluasi | 2 minggu + berkelanjutan | Peluncuran satu prodi, pelatihan dosen, evaluasi efektivitas |
| Fase Lanjutan | Setelah evaluasi | ICD-9-CM, flashcard, analisis butir soal, SSO, integrasi lanjutan |

# 16. Strategi Pengujian dan Kriteria Penerimaan

**Jenis pengujian:** uji unit dan integrasi, uji fungsional per kebutuhan, uji kinerja saat ujian serentak, uji keamanan dasar, dan uji penerimaan pengguna (UAT) oleh dosen dan mahasiswa.

**Kriteria penerimaan MVP:**

1. Seluruh kebutuhan P0 lolos uji fungsional tanpa cacat kritis.
2. Mahasiswa dapat menyelesaikan alur belajar, kuis, dan simulasi satu kasus dari awal sampai melihat pembahasan tanpa bantuan.
3. Dosen dapat membuat soal, menerbitkan kuis, dan melihat hasil kelas pada dashboard.
4. Hasil penilaian otomatis konsisten dengan kunci jawaban pada 100% sampel uji.
5. Uji 150 pengguna bersamaan berjalan tanpa kegagalan layanan.
6. Skor kegunaan (SUS) pada UAT ≥ 70.

# 17. Risiko dan Mitigasi

| Risiko | Dampak | Mitigasi |
|---|---|---|
| Kualitas atau kesalahan kunci jawaban soal/kasus | Tinggi | Telaah dua dosen, uji coba soal, mekanisme laporan kesalahan dan revisi cepat |
| Keterbatasan lisensi atau ketersediaan data ICD | Tinggi | Konfirmasi lisensi sejak awal, gunakan sumber resmi, pisahkan data dari kode |
| Kode alternatif yang sah sehingga penilaian dianggap tidak adil | Sedang | Daftar kode diterima, penilaian parsial, dan fitur koreksi dosen |
| Adopsi rendah oleh dosen/mahasiswa | Sedang | Pelatihan singkat, integrasi dengan tugas perkuliahan, templat impor mudah |
| Kecurangan saat ujian | Sedang | Acak soal/opsi, batas waktu, mode ujian tanpa bantuan pencarian |
| Beban server saat ujian serentak | Sedang | Uji beban, caching, penskalaan server |
| Kebocoran data pengguna | Tinggi | Praktik keamanan standar, hak akses minimal, pencadangan terenkripsi |
| Beban pembuatan konten awal | Sedang | Kurasi bertahap, kolaborasi dosen dan alumni, impor massal |

# 18. Pertanyaan Terbuka

1. Edisi ICD-10 dan sumber data resmi mana yang akan menjadi acuan utama (dan apakah ICD-9-CM masuk MVP)?
2. Apakah autentikasi akan terhubung dengan sistem akademik/SSO kampus?
3. Siapa penanggung jawab telaah konten dan pembaruan bank soal setiap semester?
4. Apakah aplikasi akan dipakai untuk penilaian formal (UTS/UAS) atau hanya latihan formatif?
5. Apakah dibutuhkan mode luring (offline) untuk daerah dengan koneksi terbatas?
6. Siapa yang menyediakan infrastruktur hosting dan memelihara aplikasi setelah peluncuran?

# 19. Lampiran: Contoh Struktur Modul Awal

| Modul | Topik Contoh |
|---|---|
| 1. Dasar Terminologi Medis | Akar kata, prefiks, sufiks, singkatan, istilah arah dan posisi tubuh |
| 2. Terminologi per Sistem Organ | Kardiovaskular, respirasi, pencernaan, muskuloskeletal, saraf, endokrin, urogenital, kulit, dan lainnya |
| 3. Pengantar Klasifikasi dan ICD-10 | Sejarah, struktur Volume 1–3, konvensi dan tanda baca |
| 4. Aturan Koding Diagnosis | Diagnosis utama, diagnosis sekunder, kode dagger-asterisk, kode penyebab luar |
| 5. Koding per Bab ICD-10 | Penyakit infeksi, neoplasma, kehamilan dan persalinan, cedera, dan seterusnya |
| 6. Studi Kasus dan Persiapan PKL | Kasus terpadu, evaluasi akhir, tips kerja di unit rekam medis |

## Contoh Alur Penilaian Satu Kasus

| Komponen | Jawaban Mahasiswa | Kunci | Skor |
|---|---|---|---|
| Diagnosis utama | (diisi mahasiswa) | (kode kunci) | Penuh / parsial / 0 |
| Diagnosis sekunder | (diisi mahasiswa) | (kode kunci) | Penuh / parsial / 0 |
| Kode tambahan | (diisi mahasiswa) | (kode kunci) | Penuh / parsial / 0 |
