<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;

class RoleFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $session = session();
        if (! $session->get('isLoggedIn')) {
            return redirect()->to(site_url('/'))->with('error', 'Silakan masuk terlebih dahulu.');
        }

        $userRole = $session->get('user')['role'] ?? null;

        // Check if the role is allowed
        if ($arguments && ! in_array($userRole, $arguments, true)) {
            // Redirect based on current user's actual role
            $redirectPath = match ($userRole) {
                'admin'     => 'admin/dashboard',
                'dosen'     => 'dosen/dashboard',
                'mahasiswa' => 'mahasiswa/dashboard',
                default     => '/',
            };

            return redirect()->to(site_url($redirectPath))->with('error', 'Anda tidak memiliki hak akses ke halaman tersebut.');
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do nothing
    }
}
