<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-patch-check-fill"></i> Kamus Standar RMIK</span>
            <span class="badge bg-light text-muted border">FR-14</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-translate text-success me-2"></i>Kamus Terminologi Medis
        </h3>
        <p class="text-muted mb-0">Daftar istilah klinis lengkap dengan pembedahan akar kata (root), awalan (prefix), dan akhiran (suffix).</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <span class="badge bg-success px-3 py-2 fs-6">
            <i class="bi bi-book me-1"></i> Total <?= count($terms) ?> Istilah Medis
        </span>
    </div>
</div>

<!-- Search & System Organ Filter -->
<div class="card card-official p-3 mb-4">
    <form method="get" action="<?= site_url('kamus') ?>" class="row g-2 align-items-center">
        <div class="col-md-6">
            <div class="input-group">
                <span class="input-group-text bg-white text-success border-end-0"><i class="bi bi-search"></i></span>
                <input type="text" name="q" class="form-control border-start-0" placeholder="Ketik nama istilah, arti, atau akar kata (misal: cardi, gastr)..." value="<?= esc($q ?? '') ?>">
            </div>
        </div>
        <div class="col-md-4">
            <select name="system" class="form-select">
                <option value="">-- Semua Sistem Organ Tubuh --</option>
                <?php foreach ($systems as $sys): ?>
                    <option value="<?= $sys ?>" <?= ($system === $sys) ? 'selected' : '' ?>><?= $sys ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-green-official w-100">
                <i class="bi bi-filter"></i> Cari
            </button>
        </div>
    </form>
</div>

<!-- Terminology Grid -->
<div class="row g-3">
    <?php if (empty($terms)): ?>
        <div class="col-12 text-center py-5">
            <i class="bi bi-search text-muted fs-1 d-block mb-2"></i>
            <h5 class="text-muted">Istilah medis tidak ditemukan.</h5>
            <p class="small text-muted">Coba gunakan kata kunci lain atau pilih semua sistem organ.</p>
        </div>
    <?php else: ?>
        <?php foreach ($terms as $t): ?>
            <div class="col-md-6 col-lg-4">
                <div class="card card-official h-100">
                    <div class="card-header-official d-flex justify-content-between align-items-center">
                        <span class="fw-bold text-dark fs-5"><?= esc($t['term']) ?></span>
                        <span class="badge bg-success-subtle text-success border border-success-subtle">
                            <?= esc($t['body_system'] ?? 'Umum') ?>
                        </span>
                    </div>
                    <div class="card-body d-flex flex-column">
                        <p class="text-dark small mb-3"><?= esc($t['meaning']) ?></p>

                        <!-- Breakdown akar kata -->
                        <div class="p-2 bg-light rounded-3 border mb-3 small flex-grow-1">
                            <div class="text-muted fw-bold mb-1" style="font-size: 0.75rem;"><i class="bi bi-diagram-3 me-1"></i> STRUKTUR KATA:</div>
                            <?php if ($t['prefix']): ?>
                                <div><span class="badge bg-secondary-subtle text-secondary">Prefix:</span> <?= esc($t['prefix']) ?></div>
                            <?php endif; ?>
                            <?php if ($t['root_word']): ?>
                                <div><span class="badge bg-success-subtle text-success">Root:</span> <strong><?= esc($t['root_word']) ?></strong></div>
                            <?php endif; ?>
                            <?php if ($t['suffix']): ?>
                                <div><span class="badge bg-info-subtle text-info">Suffix:</span> <?= esc($t['suffix']) ?></div>
                            <?php endif; ?>
                        </div>

                        <?php if ($t['example_sentence']): ?>
                            <div class="border-top pt-2 small text-muted">
                                <i class="bi bi-file-medical text-success me-1"></i> <em>"<?= esc($t['example_sentence']) ?>"</em>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?= $this->endSection() ?>
