<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'KodeMedis Learn - Sistem Pembelajaran Koding Diagnosis & Rekam Medis') ?></title>
    
    <!-- Google Fonts: Plus Jakarta Sans & JetBrains Mono -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600;700&display=swap" rel="stylesheet">
    
    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Icons -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <!-- Chart.js -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

    <style>
        :root {
            --km-primary: #059669;
            --km-primary-dark: #047857;
            --km-primary-deep: #064e3b;
            --km-primary-light: #ecfdf5;
            --km-accent-mint: #10b981;
            --km-sidebar-width: 270px;
            --km-bg: #f8fafc;
            --km-card-bg: #ffffff;
            --km-text: #0f172a;
            --km-text-muted: #64748b;
            --km-border: #e2e8f0;
            --km-border-green: #d1fae5;
        }

        * {
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--km-bg);
            color: var(--km-text);
            margin: 0;
            padding: 0;
            overflow-x: hidden;
        }

        /* ===================================================
           SIDEBAR STYLES (Bersih, Rapi, Tanpa Tumpang Tindih)
           =================================================== */
        #app-sidebar {
            width: var(--km-sidebar-width);
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            background: linear-gradient(180deg, #064e3b 0%, #047857 60%, #065f46 100%);
            color: #ffffff;
            z-index: 1050;
            display: flex;
            flex-direction: column;
            overflow-y: auto;
            border-right: 1px solid rgba(255, 255, 255, 0.1);
            box-shadow: 4px 0 20px rgba(0, 0, 0, 0.08);
            transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        }

        #app-sidebar::-webkit-scrollbar {
            width: 5px;
        }
        #app-sidebar::-webkit-scrollbar-thumb {
            background: rgba(255, 255, 255, 0.2);
            border-radius: 4px;
        }

        /* Sidebar Brand */
        .sidebar-brand {
            padding: 20px 20px 16px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.12);
            background: rgba(0, 0, 0, 0.15);
        }

        .sidebar-brand-badge {
            background: #ffffff;
            color: #047857;
            font-weight: 800;
            padding: 8px 12px;
            border-radius: 10px;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.15);
        }

        /* User Profile Snippet in Sidebar */
        .sidebar-user {
            padding: 16px 20px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.08);
            background: rgba(255, 255, 255, 0.04);
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .sidebar-user-avatar {
            width: 42px;
            height: 42px;
            border-radius: 10px;
            background: #ffffff;
            color: #047857;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 800;
            font-size: 1.1rem;
            flex-shrink: 0;
            box-shadow: 0 2px 6px rgba(0,0,0,0.15);
        }

        /* Sidebar Nav Links */
        .sidebar-nav {
            padding: 16px 12px;
            flex-grow: 1;
        }

        .sidebar-heading {
            font-size: 0.72rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            color: #a7f3d0;
            font-weight: 700;
            padding: 12px 14px 6px 14px;
            margin-top: 6px;
        }

        .sidebar-nav-link {
            color: #ecfdf5 !important;
            font-weight: 600;
            font-size: 0.88rem;
            padding: 10px 14px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            transition: all 0.18s ease;
            margin-bottom: 3px;
        }

        .sidebar-nav-link i {
            font-size: 1.15rem;
            color: #a7f3d0;
            transition: color 0.18s ease;
        }

        .sidebar-nav-link:hover {
            color: #ffffff !important;
            background-color: rgba(255, 255, 255, 0.12);
            transform: translateX(3px);
        }

        .sidebar-nav-link:hover i {
            color: #ffffff;
        }

        .sidebar-nav-link.active {
            color: #ffffff !important;
            background: #10b981;
            font-weight: 700;
            box-shadow: 0 4px 12px rgba(16, 185, 129, 0.35);
        }

        .sidebar-nav-link.active i {
            color: #ffffff;
        }

        /* Sidebar Footer */
        .sidebar-footer {
            padding: 14px 16px;
            border-top: 1px solid rgba(255, 255, 255, 0.12);
            background: rgba(0, 0, 0, 0.2);
        }

        /* ===================================================
           MAIN CONTENT AREA (Offset by Sidebar on Desktop)
           =================================================== */
        #app-main {
            margin-left: var(--km-sidebar-width);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            width: calc(100% - var(--km-sidebar-width));
            transition: all 0.3s ease;
        }

        /* Sticky Top Bar */
        #app-topbar {
            position: sticky;
            top: 0;
            z-index: 1030;
            background: #ffffff;
            border-bottom: 1px solid var(--km-border);
            padding: 10px 24px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.02);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        /* Mobile Sidebar Backdrop */
        .sidebar-backdrop {
            position: fixed;
            top: 0;
            left: 0;
            width: 100vw;
            height: 100vh;
            background: rgba(0, 0, 0, 0.45);
            backdrop-filter: blur(2px);
            z-index: 1045;
            display: none;
        }

        /* Media Queries: Mobile & Tablet */
        @media (max-width: 991.98px) {
            #app-sidebar {
                transform: translateX(-100%);
            }
            #app-sidebar.show {
                transform: translateX(0);
            }
            #app-main {
                margin-left: 0;
                width: 100%;
            }
            .sidebar-backdrop.show {
                display: block;
            }
        }

        /* ===================================================
           CARDS & CONTENT STYLES (Rapi & Tidak Bertumpuk)
           =================================================== */
        .card-official {
            background: #ffffff;
            border: 1px solid var(--km-border);
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.03);
            margin-bottom: 24px;
        }

        .card-official .card-header-official {
            background: linear-gradient(180deg, #f0fdf4 0%, #ffffff 100%);
            border-bottom: 1px solid var(--km-border-green);
            padding: 14px 20px;
            font-weight: 700;
            color: #064e3b;
            border-top-left-radius: 12px;
            border-top-right-radius: 12px;
        }

        .btn-green-official {
            background-color: #059669;
            color: #ffffff;
            font-weight: 600;
            border: none;
            border-radius: 8px;
            padding: 8px 16px;
            transition: all 0.2s ease;
        }

        .btn-green-official:hover {
            background-color: #047857;
            color: #ffffff;
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(5, 150, 105, 0.25);
        }

        .btn-outline-green {
            border: 1.5px solid #059669;
            color: #059669;
            font-weight: 600;
            border-radius: 8px;
            background: #ffffff;
            transition: all 0.2s ease;
        }

        .btn-outline-green:hover {
            background-color: #059669;
            color: #ffffff;
        }

        .icd-code-pill {
            font-family: 'JetBrains Mono', monospace;
            background-color: #ecfdf5;
            color: #047857;
            border: 1px solid #a7f3d0;
            padding: 3px 8px;
            border-radius: 6px;
            font-weight: 700;
            font-size: 0.85rem;
            display: inline-block;
        }

        .medical-seal {
            display: inline-flex;
            align-items: center;
            gap: 4px;
            font-size: 0.75rem;
            color: #047857;
            background: #ecfdf5;
            padding: 3px 9px;
            border-radius: 20px;
            font-weight: 700;
            border: 1px solid #a7f3d0;
        }

        /* Footer */
        .footer-official {
            margin-top: auto;
            background: #ffffff;
            border-top: 1px solid var(--km-border);
            padding: 20px 24px;
            color: var(--km-text-muted);
            font-size: 0.84rem;
        }
    </style>
</head>
<body>
    <?php $currentUser = session()->get('user') ?? null; ?>

    <?php if ($currentUser): ?>
    <!-- Mobile Backdrop -->
    <div class="sidebar-backdrop" id="sidebarBackdrop" onclick="toggleSidebar()"></div>

    <!-- ==============================================
         LEFT SIDEBAR NAVIGATION (Rapi & Terstruktur)
         ============================================== -->
    <aside id="app-sidebar">
        <!-- Brand Header -->
        <div class="sidebar-brand">
            <div class="sidebar-brand-badge mb-2">
                <i class="bi bi-hospital fs-4 text-success"></i>
                <div>
                    <span class="fs-6 fw-bold d-block lh-1">KodeMedis</span>
                    <small class="text-muted fw-bold" style="font-size: 0.65rem; letter-spacing: 0.5px;">RMIK LEARN</small>
                </div>
            </div>
            <div class="small text-white-50 mt-1 d-flex align-items-center gap-1" style="font-size: 0.72rem;">
                <i class="bi bi-shield-check text-warning"></i> Standar Resmi WHO ICD-10
            </div>
        </div>

        <!-- User Profile Card -->
        <div class="sidebar-user">
            <div class="sidebar-user-avatar">
                <?= strtoupper(substr($currentUser['name'] ?? 'U', 0, 1)) ?>
            </div>
            <div class="overflow-hidden">
                <div class="fw-bold text-white text-truncate small"><?= esc($currentUser['name']) ?></div>
                <span class="badge bg-white text-success fw-bold text-uppercase" style="font-size: 0.68rem; padding: 2px 7px;">
                    <i class="bi bi-person-fill"></i> <?= esc($currentUser['role']) ?>
                </span>
            </div>
        </div>

        <!-- Navigation Links per Role -->
        <nav class="sidebar-nav">
            <!-- 1. Menu Khusus Administrator -->
            <?php if ($currentUser['role'] === 'admin'): ?>
                <div class="sidebar-heading">Administrator</div>
                <a class="sidebar-nav-link <?= url_is('admin/dashboard*') ? 'active' : '' ?>" href="<?= site_url('admin/dashboard') ?>">
                    <i class="bi bi-speedometer2"></i> Dashboard Admin
                </a>
                <a class="sidebar-nav-link <?= url_is('admin/users*') ? 'active' : '' ?>" href="<?= site_url('admin/users') ?>">
                    <i class="bi bi-people-fill"></i> Manajemen Pengguna
                </a>
                <a class="sidebar-nav-link <?= url_is('admin/classes*') ? 'active' : '' ?>" href="<?= site_url('admin/classes') ?>">
                    <i class="bi bi-mortarboard-fill"></i> Kelas & Roster
                </a>

            <!-- 2. Menu Khusus Dosen -->
            <?php elseif ($currentUser['role'] === 'dosen'): ?>
                <div class="sidebar-heading">Pengajaran</div>
                <a class="sidebar-nav-link <?= url_is('dosen/dashboard*') ? 'active' : '' ?>" href="<?= site_url('dosen/dashboard') ?>">
                    <i class="bi bi-speedometer2"></i> Dashboard Dosen
                </a>
                <a class="sidebar-nav-link <?= url_is('dosen/modules*') ? 'active' : '' ?>" href="<?= site_url('dosen/modules') ?>">
                    <i class="bi bi-journal-text"></i> Modul Materi
                </a>
                <a class="sidebar-nav-link <?= url_is('dosen/questions*') ? 'active' : '' ?>" href="<?= site_url('dosen/questions') ?>">
                    <i class="bi bi-card-checklist"></i> Bank Soal
                </a>
                <a class="sidebar-nav-link <?= url_is('dosen/quizzes*') ? 'active' : '' ?>" href="<?= site_url('dosen/quizzes') ?>">
                    <i class="bi bi-file-earmark-check"></i> Kuis & Ujian
                </a>
                <a class="sidebar-nav-link <?= url_is('dosen/cases*') ? 'active' : '' ?>" href="<?= site_url('dosen/cases') ?>">
                    <i class="bi bi-clipboard2-pulse"></i> Simulasi Kasus
                </a>
                <a class="sidebar-nav-link <?= url_is('dosen/analytics*') ? 'active' : '' ?>" href="<?= site_url('dosen/analytics') ?>">
                    <i class="bi bi-graph-up-arrow"></i> Peta Analitik
                </a>

            <!-- 3. Menu Khusus Mahasiswa -->
            <?php elseif ($currentUser['role'] === 'mahasiswa'): ?>
                <div class="sidebar-heading">Ruang Belajar</div>
                <a class="sidebar-nav-link <?= url_is('mahasiswa/dashboard*') ? 'active' : '' ?>" href="<?= site_url('mahasiswa/dashboard') ?>">
                    <i class="bi bi-house-door"></i> Beranda
                </a>
                <a class="sidebar-nav-link <?= url_is('mahasiswa/modules*') ? 'active' : '' ?>" href="<?= site_url('mahasiswa/modules') ?>">
                    <i class="bi bi-book-half"></i> Modul Belajar
                </a>
                <a class="sidebar-nav-link <?= url_is('mahasiswa/quizzes*') ? 'active' : '' ?>" href="<?= site_url('mahasiswa/quizzes') ?>">
                    <i class="bi bi-pencil-square"></i> Latihan Kuis
                </a>
                <a class="sidebar-nav-link <?= url_is('mahasiswa/cases*') ? 'active' : '' ?>" href="<?= site_url('mahasiswa/cases') ?>">
                    <i class="bi bi-file-earmark-medical"></i> Resume Medis
                </a>
                <a class="sidebar-nav-link <?= url_is('mahasiswa/competency*') ? 'active' : '' ?>" href="<?= site_url('mahasiswa/competency') ?>">
                    <i class="bi bi-award-fill"></i> Peta Kompetensi
                </a>
            <?php endif; ?>

            <!-- Alat Klinis Standar (Semua Pengguna) -->
            <div class="sidebar-heading">Referensi Klinis</div>
            <a class="sidebar-nav-link <?= url_is('kamus*') ? 'active' : '' ?>" href="<?= site_url('kamus') ?>">
                <i class="bi bi-translate"></i> Kamus Terminologi
            </a>
            <a class="sidebar-nav-link <?= url_is('icd10*') ? 'active' : '' ?>" href="<?= site_url('icd10') ?>">
                <i class="bi bi-search"></i> Pencarian ICD-10
            </a>
        </nav>

        <!-- Sidebar Footer Action -->
        <div class="sidebar-footer">
            <a href="<?= site_url('logout') ?>" class="btn btn-sm btn-outline-light w-100 d-flex align-items-center justify-content-center gap-2 py-2">
                <i class="bi bi-box-arrow-right"></i> <span>Keluar Sistem</span>
            </a>
        </div>
    </aside>

    <!-- ==============================================
         MAIN WRAPPER (Top Bar + Dynamic Content)
         ============================================== -->
    <div id="app-main">
        <!-- Top Bar Header -->
        <header id="app-topbar">
            <div class="d-flex align-items-center gap-3">
                <!-- Mobile Hamburger Toggle -->
                <button type="button" class="btn btn-sm btn-outline-secondary d-lg-none" onclick="toggleSidebar()">
                    <i class="bi bi-list fs-5"></i>
                </button>

                <!-- Page Header Title Context -->
                <div class="d-none d-sm-block">
                    <span class="medical-seal"><i class="bi bi-shield-check"></i> Terverifikasi RMIK</span>
                </div>
            </div>

            <!-- Topbar Right Badges & Indicators -->
            <div class="d-flex align-items-center gap-3">
                <div class="d-none d-md-flex align-items-center text-muted small gap-3">
                    <span><i class="bi bi-clock me-1 text-success"></i> <?= date('d M Y') ?></span>
                    <span class="badge bg-light text-secondary border">XAMPP MySQL</span>
                    <span class="badge bg-success-subtle text-success border border-success-subtle"><i class="bi bi-check-circle-fill me-1"></i> Sistem Aktif</span>
                </div>

                <div class="d-flex align-items-center gap-2">
                    <span class="fw-bold text-dark small d-none d-sm-inline"><?= esc($currentUser['name']) ?></span>
                    <a href="<?= site_url('logout') ?>" class="btn btn-sm btn-outline-danger" title="Keluar">
                        <i class="bi bi-power"></i>
                    </a>
                </div>
            </div>
        </header>

        <!-- Dynamic Main Content Area -->
        <main class="flex-grow-1 p-3 p-md-4">
            <!-- Flash Message Alerts -->
            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show d-flex align-items-center shadow-sm border-success mb-4" role="alert" style="background-color: #ecfdf5;">
                    <i class="bi bi-check-circle-fill text-success me-2 fs-5"></i>
                    <div class="text-success-emphasis fw-semibold"><?= session()->getFlashdata('success') ?></div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center shadow-sm mb-4" role="alert">
                    <i class="bi bi-exclamation-triangle-fill text-danger me-2 fs-5"></i>
                    <div><?= session()->getFlashdata('error') ?></div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- Rendered Child Section -->
            <?= $this->renderSection('content') ?>
        </main>

        <!-- Official Footer -->
        <footer class="footer-official">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-2">
                <div>
                    <strong>KodeMedis Learn</strong> &copy; <?= date('Y') ?> &middot; Portal Pembelajaran Koding Diagnosis & Terminologi Medis RMIK
                </div>
                <div class="small">
                    <span class="badge bg-light text-success border border-success"><i class="bi bi-check-circle-fill me-1"></i> Standar WHO ICD-10</span>
                </div>
            </div>
        </footer>
    </div>

    <!-- Toggle Script for Mobile Sidebar -->
    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('app-sidebar');
            const backdrop = document.getElementById('sidebarBackdrop');
            sidebar.classList.toggle('show');
            backdrop.classList.toggle('show');
        }
    </script>
    <?php else: ?>
        <!-- For non-logged in views (e.g. login) -->
        <?= $this->renderSection('content') ?>
    <?php endif; ?>

    <!-- Bootstrap 5 Bundle JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <?= $this->renderSection('scripts') ?>
</body>
</html>
