<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= esc($title ?? 'KodeMedis Learn - Portal Resmi RMIK') ?></title>
    <meta name="description" content="Portal Pembelajaran Koding Diagnosis & Terminologi Medis RMIK">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        :root {
            --km-primary: #059669;
            --km-primary-dark: #047857;
            --km-primary-deep: #064e3b;
            --km-border-green: #d1fae5;
        }
        * { box-sizing: border-box; }
        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: linear-gradient(135deg, #064e3b 0%, #047857 40%, #059669 75%, #10b981 100%);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 24px 16px;
            position: relative;
            overflow-x: hidden;
        }
        body::before {
            content: '';
            position: fixed;
            top: -120px; right: -120px;
            width: 420px; height: 420px;
            background: rgba(255,255,255,0.05);
            border-radius: 50%;
            pointer-events: none;
        }
        body::after {
            content: '';
            position: fixed;
            bottom: -150px; left: -100px;
            width: 500px; height: 500px;
            background: rgba(0,0,0,0.07);
            border-radius: 50%;
            pointer-events: none;
        }
        .auth-card {
            background: #ffffff;
            border-radius: 20px;
            box-shadow: 0 32px 72px -12px rgba(6,78,59,0.45), 0 0 0 1px rgba(255,255,255,0.1);
            width: 100%;
            max-width: 520px;
            overflow: hidden;
            position: relative;
            z-index: 1;
            animation: slideUp 0.4s cubic-bezier(0.4,0,0.2,1);
        }
        @keyframes slideUp {
            from { opacity:0; transform:translateY(24px); }
            to   { opacity:1; transform:translateY(0); }
        }
        .auth-header {
            background: linear-gradient(180deg, #f0fdf4 0%, #ffffff 100%);
            padding: 28px 32px 22px;
            text-align: center;
            border-bottom: 2px solid var(--km-border-green);
        }
        .brand-icon {
            display: inline-flex;
            align-items: center; justify-content: center;
            width: 64px; height: 64px;
            border-radius: 18px;
            background: linear-gradient(135deg, #059669, #047857);
            color: #fff;
            font-size: 32px;
            margin-bottom: 14px;
            box-shadow: 0 12px 24px -4px rgba(5,150,105,0.45);
        }
        .auth-tabs {
            display: flex;
            border-bottom: 2px solid #e2e8f0;
            background: #f8fafc;
        }
        .auth-tab-btn {
            flex: 1;
            padding: 14px 10px;
            font-size: 0.875rem;
            font-weight: 700;
            color: #64748b;
            background: transparent;
            border: none;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 7px;
            transition: all 0.2s ease;
            position: relative;
        }
        .auth-tab-btn::after {
            content: '';
            position: absolute;
            bottom: -2px; left: 0; right: 0;
            height: 2px;
            background: var(--km-primary);
            transform: scaleX(0);
            transition: transform 0.2s ease;
        }
        .auth-tab-btn.active { color: var(--km-primary-dark); background: #ffffff; }
        .auth-tab-btn.active::after { transform: scaleX(1); }
        .auth-body { padding: 28px 32px 24px; }
        .form-label {
            font-size: 0.84rem;
            font-weight: 700;
            color: #475569;
            margin-bottom: 6px;
        }
        .form-control, .form-select {
            border-radius: 9px;
            padding: 11px 14px;
            font-size: 0.93rem;
            border: 1.5px solid #e2e8f0;
            font-family: 'Plus Jakarta Sans', sans-serif;
            transition: border-color 0.15s, box-shadow 0.15s;
        }
        .form-control:focus, .form-select:focus {
            border-color: #059669;
            box-shadow: 0 0 0 4px rgba(5,150,105,0.12);
            outline: none;
        }
        .input-group-text {
            background: #f1f5f9;
            border: 1.5px solid #e2e8f0;
            color: #94a3b8;
        }
        .input-group .form-control { border-left: none; }
        .btn-submit {
            background: linear-gradient(135deg, #059669, #047857);
            border: none;
            color: #fff;
            font-weight: 700;
            font-size: 0.95rem;
            padding: 13px;
            border-radius: 10px;
            width: 100%;
            transition: all 0.2s ease;
            box-shadow: 0 4px 12px rgba(5,150,105,0.3);
            cursor: pointer;
        }
        .btn-submit:hover {
            background: linear-gradient(135deg, #047857, #065f46);
            transform: translateY(-2px);
            box-shadow: 0 8px 20px -2px rgba(4,120,87,0.4);
            color: #fff;
        }
        .demo-box {
            background: #f8fafc;
            border: 1.5px solid #e2e8f0;
            border-radius: 10px;
            padding: 14px;
        }
        .demo-box-title {
            font-size: 0.72rem;
            font-weight: 700;
            text-transform: uppercase;
            letter-spacing: 0.7px;
            color: #94a3b8;
            margin-bottom: 10px;
        }
        .quick-btn {
            font-size: 0.79rem;
            font-weight: 600;
            border-radius: 8px;
            padding: 6px 12px;
            cursor: pointer;
            transition: all 0.15s ease;
            border: 1.5px solid;
            background: #fff;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }
        .quick-btn:hover { transform: translateY(-1px); }
        .pass-toggle {
            position: absolute;
            right: 12px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #94a3b8;
            cursor: pointer;
            z-index: 5;
            padding: 0 4px;
            font-size: 1rem;
        }
        .role-pills { display: flex; gap: 8px; flex-wrap: wrap; }
        .role-pill input[type="radio"] { display: none; }
        .role-pill label {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 8px 16px;
            border: 1.5px solid #e2e8f0;
            border-radius: 8px;
            font-size: 0.84rem;
            font-weight: 600;
            color: #64748b;
            cursor: pointer;
            transition: all 0.15s ease;
            background: #fff;
        }
        .role-pill input:checked + label {
            border-color: #059669;
            background: #ecfdf5;
            color: #047857;
        }
        .role-pill label:hover { border-color: #a7f3d0; background: #f0fdf4; }
        .strength-bar {
            height: 4px;
            border-radius: 2px;
            background: #e2e8f0;
            margin-top: 6px;
            overflow: hidden;
        }
        .strength-fill {
            height: 100%;
            border-radius: 2px;
            width: 0;
            transition: width 0.3s ease, background 0.3s ease;
        }
        .auth-footer-note {
            text-align: center;
            font-size: 0.78rem;
            color: #94a3b8;
            margin-top: 16px;
        }
        .alert { border-radius: 10px; font-size: 0.88rem; }
        @media (max-width: 480px) {
            .auth-body { padding: 20px; }
            .auth-header { padding: 22px 20px 18px; }
        }
    </style>
</head>
<body>
    <div style="position:fixed; top:18px; left:18px; z-index:2; opacity:0.35;">
        <span style="color:#fff; font-size:0.75rem; font-weight:700; letter-spacing:1px;">&#9673; WHO ICD-10 STANDARD</span>
    </div>

    <div class="auth-card">
        <!-- Brand Header -->
        <div class="auth-header">
            <div class="brand-icon"><i class="bi bi-hospital"></i></div>
            <div class="d-flex justify-content-center align-items-center gap-2 mb-1">
                <h1 class="h5 fw-bold text-dark mb-0">KodeMedis Learn</h1>
                <span class="badge" style="background:#dcfce7; color:#166534; font-size:0.68rem; border:1px solid #bbf7d0;">RESMI RMIK</span>
            </div>
            <p class="text-muted mb-0" style="font-size:0.84rem;">Portal Pembelajaran Koding Diagnosis &amp; Terminologi Medis</p>
        </div>

        <!-- Tab Navigation -->
        <div class="auth-tabs" role="tablist">
            <button class="auth-tab-btn active" id="tab-login-btn" onclick="switchTab('login')" role="tab" aria-selected="true">
                <i class="bi bi-box-arrow-in-right"></i> Masuk
            </button>
            <button class="auth-tab-btn" id="tab-register-btn" onclick="switchTab('register')" role="tab" aria-selected="false">
                <i class="bi bi-person-plus-fill"></i> Daftar Akun Baru
            </button>
        </div>

        <div class="auth-body">
            <!-- Flash Messages -->
            <?php if (session()->getFlashdata('success')): ?>
                <div class="alert alert-success alert-dismissible fade show d-flex align-items-center gap-2 py-2 mb-3" style="background:#ecfdf5; border-color:#a7f3d0; color:#065f46;">
                    <i class="bi bi-check-circle-fill fs-5"></i>
                    <div><?= session()->getFlashdata('success') ?></div>
                    <button type="button" class="btn-close ms-auto py-2" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('error')): ?>
                <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center gap-2 py-2 mb-3">
                    <i class="bi bi-exclamation-triangle-fill fs-5"></i>
                    <div><?= session()->getFlashdata('error') ?></div>
                    <button type="button" class="btn-close ms-auto py-2" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if (session()->getFlashdata('register_error')): ?>
                <div class="alert alert-danger alert-dismissible fade show d-flex align-items-center gap-2 py-2 mb-3" id="regAlert">
                    <i class="bi bi-exclamation-triangle-fill fs-5"></i>
                    <div><?= session()->getFlashdata('register_error') ?></div>
                    <button type="button" class="btn-close ms-auto py-2" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>

            <!-- ===== TAB LOGIN ===== -->
            <div id="tab-login">
                <form action="<?= site_url('login') ?>" method="post" id="loginForm" novalidate>
                    <?= csrf_field() ?>
                    <div class="mb-3">
                        <label for="identifier" class="form-label">
                            <i class="bi bi-person-fill text-success me-1"></i> Email atau NIM / NIP
                        </label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="bi bi-person"></i></span>
                            <input type="text" class="form-control" id="identifier" name="identifier"
                                   value="<?= old('identifier') ?>"
                                   placeholder="admin@kodemedis.ac.id atau 202401001"
                                   required autofocus autocomplete="username">
                        </div>
                    </div>
                    <div class="mb-4">
                        <label for="password" class="form-label">
                            <i class="bi bi-lock-fill text-success me-1"></i> Kata Sandi
                        </label>
                        <div class="input-group position-relative">
                            <span class="input-group-text"><i class="bi bi-key"></i></span>
                            <input type="password" class="form-control pe-5" id="password" name="password"
                                   placeholder="••••••••" required autocomplete="current-password">
                            <button type="button" class="pass-toggle" onclick="togglePass('password','eyeLogin')">
                                <i class="bi bi-eye" id="eyeLogin"></i>
                            </button>
                        </div>
                    </div>
                    <button type="submit" class="btn-submit mb-3" id="loginBtn">
                        <i class="bi bi-box-arrow-in-right me-1"></i> Masuk ke Portal
                    </button>
                </form>

                <!-- Demo Credentials -->
                <div class="demo-box">
                    <div class="demo-box-title"><i class="bi bi-lightning-charge-fill text-warning me-1"></i> Akun Demo – Klik untuk isi otomatis</div>
                    <div class="d-flex flex-wrap gap-2">
                        <button class="quick-btn" style="color:#dc2626;border-color:#fca5a5;" onclick="fillLogin('admin@kodemedis.ac.id','password123')">
                            <i class="bi bi-shield-lock"></i> Admin
                        </button>
                        <button class="quick-btn" style="color:#2563eb;border-color:#93c5fd;" onclick="fillLogin('ratna@kodemedis.ac.id','password123')">
                            <i class="bi bi-person-video3"></i> Dosen
                        </button>
                        <button class="quick-btn" style="color:#059669;border-color:#6ee7b7;" onclick="fillLogin('raisa@student.kodemedis.ac.id','password123')">
                            <i class="bi bi-mortarboard"></i> Mahasiswa
                        </button>
                    </div>
                </div>
                <div class="auth-footer-note mt-3">
                    Belum punya akun?
                    <a href="#" onclick="switchTab('register');return false;" class="fw-bold text-success">Daftar di sini &rarr;</a>
                </div>
            </div>

            <!-- ===== TAB REGISTER ===== -->
            <div id="tab-register" style="display:none;">
                <form action="<?= site_url('register') ?>" method="post" id="registerForm" novalidate>
                    <?= csrf_field() ?>

                    <?php if (!empty(session()->getFlashdata('errors'))): ?>
                        <div class="alert alert-danger py-2 mb-3" style="font-size:0.83rem;">
                            <i class="bi bi-exclamation-triangle-fill me-1"></i>
                            <ul class="mb-0 ps-3 mt-1">
                                <?php foreach ((array)session()->getFlashdata('errors') as $err): ?>
                                    <li><?= esc($err) ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <div class="mb-3">
                        <label for="reg_name" class="form-label">
                            <i class="bi bi-person-badge text-success me-1"></i> Nama Lengkap <span class="text-danger">*</span>
                        </label>
                        <input type="text" class="form-control" id="reg_name" name="name"
                               value="<?= old('name') ?>" placeholder="Masukkan nama lengkap Anda" required>
                    </div>

                    <div class="mb-3">
                        <label for="reg_nim_nip" class="form-label">
                            <i class="bi bi-card-text text-success me-1"></i> NIM / NIP
                            <span class="text-muted fw-normal" style="font-size:0.77rem;">(opsional)</span>
                        </label>
                        <input type="text" class="form-control" id="reg_nim_nip" name="nim_nip"
                               value="<?= old('nim_nip') ?>" placeholder="Contoh: 202401001">
                    </div>

                    <div class="mb-3">
                        <label for="reg_email" class="form-label">
                            <i class="bi bi-envelope-fill text-success me-1"></i> Alamat Email <span class="text-danger">*</span>
                        </label>
                        <input type="email" class="form-control" id="reg_email" name="email"
                               value="<?= old('email') ?>" placeholder="nama@institusi.ac.id" required>
                    </div>

                    <div class="mb-3">
                        <label class="form-label d-block">
                            <i class="bi bi-people-fill text-success me-1"></i> Saya adalah <span class="text-danger">*</span>
                        </label>
                        <div class="role-pills">
                            <div class="role-pill">
                                <input type="radio" name="role" id="role_mahasiswa" value="mahasiswa"
                                    <?= (old('role','mahasiswa') === 'mahasiswa') ? 'checked' : '' ?>>
                                <label for="role_mahasiswa"><i class="bi bi-mortarboard-fill"></i> Mahasiswa</label>
                            </div>
                            <div class="role-pill">
                                <input type="radio" name="role" id="role_dosen" value="dosen"
                                    <?= (old('role') === 'dosen') ? 'checked' : '' ?>>
                                <label for="role_dosen"><i class="bi bi-person-video3"></i> Dosen</label>
                            </div>
                        </div>
                    </div>

                    <div class="mb-2">
                        <label for="reg_password" class="form-label">
                            <i class="bi bi-lock-fill text-success me-1"></i> Kata Sandi <span class="text-danger">*</span>
                        </label>
                        <div class="position-relative">
                            <input type="password" class="form-control pe-5" id="reg_password" name="password"
                                   placeholder="Minimal 6 karakter" required
                                   oninput="checkStrength(this.value)" autocomplete="new-password">
                            <button type="button" class="pass-toggle" onclick="togglePass('reg_password','eyeReg')">
                                <i class="bi bi-eye" id="eyeReg"></i>
                            </button>
                        </div>
                        <div class="strength-bar"><div class="strength-fill" id="strengthFill"></div></div>
                        <div class="d-flex justify-content-between mt-1" style="font-size:0.73rem; color:#94a3b8;">
                            <span id="strengthLabel"></span><span>Min. 6 karakter</span>
                        </div>
                    </div>

                    <div class="mb-4">
                        <label for="reg_confirm" class="form-label">
                            <i class="bi bi-lock-fill text-success me-1"></i> Konfirmasi Kata Sandi <span class="text-danger">*</span>
                        </label>
                        <div class="position-relative">
                            <input type="password" class="form-control pe-5" id="reg_confirm" name="password_confirm"
                                   placeholder="Ulangi kata sandi" required autocomplete="new-password">
                            <button type="button" class="pass-toggle" onclick="togglePass('reg_confirm','eyeConfirm')">
                                <i class="bi bi-eye" id="eyeConfirm"></i>
                            </button>
                        </div>
                        <div id="confirmMsg" style="font-size:0.78rem; margin-top:4px;"></div>
                    </div>

                    <div class="p-3 rounded-3 mb-4" style="background:#fffbeb; border:1px solid #fde68a; font-size:0.82rem; color:#92400e;">
                        <i class="bi bi-info-circle-fill me-1 text-warning"></i>
                        <strong>Info:</strong> Akun yang didaftarkan akan langsung aktif dan dapat digunakan untuk login.
                    </div>

                    <button type="submit" class="btn-submit" id="registerBtn">
                        <i class="bi bi-person-plus-fill me-1"></i> Buat Akun Sekarang
                    </button>
                </form>
                <div class="auth-footer-note mt-3">
                    Sudah punya akun?
                    <a href="#" onclick="switchTab('login');return false;" class="fw-bold text-success">&larr; Kembali ke Login</a>
                </div>
            </div>
        </div><!-- /.auth-body -->
    </div><!-- /.auth-card -->

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function switchTab(tab) {
            document.getElementById('tab-login').style.display    = (tab === 'login')    ? 'block' : 'none';
            document.getElementById('tab-register').style.display = (tab === 'register') ? 'block' : 'none';
            document.getElementById('tab-login-btn').classList.toggle('active',    tab === 'login');
            document.getElementById('tab-register-btn').classList.toggle('active', tab === 'register');
        }

        // Auto-switch to register tab on register errors
        <?php if (session()->getFlashdata('errors') || session()->getFlashdata('register_error')): ?>
        switchTab('register');
        <?php endif; ?>

        function fillLogin(id, pw) {
            document.getElementById('identifier').value = id;
            document.getElementById('password').value   = pw;
            const btn = document.getElementById('loginBtn');
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Memuat...';
            btn.disabled = true;
            document.getElementById('loginForm').submit();
        }

        function togglePass(fieldId, iconId) {
            const f = document.getElementById(fieldId);
            const i = document.getElementById(iconId);
            f.type = (f.type === 'password') ? 'text' : 'password';
            i.className = (f.type === 'text') ? 'bi bi-eye-slash' : 'bi bi-eye';
        }

        function checkStrength(val) {
            let s = 0;
            if (val.length >= 6)  s++;
            if (val.length >= 10) s++;
            if (/[A-Z]/.test(val) && /[a-z]/.test(val)) s++;
            if (/[0-9]/.test(val)) s++;
            if (/[^A-Za-z0-9]/.test(val)) s++;
            const lvl = [
                ['0%',   '#e2e8f0', ''],
                ['25%',  '#f87171', '<span style="color:#dc2626">Sangat Lemah</span>'],
                ['50%',  '#fb923c', '<span style="color:#ea580c">Cukup</span>'],
                ['75%',  '#facc15', '<span style="color:#ca8a04">Kuat</span>'],
                ['90%',  '#34d399', '<span style="color:#059669">Sangat Kuat</span>'],
                ['100%', '#059669', '<span style="color:#047857;font-weight:700">Sempurna ✓</span>'],
            ][Math.min(s,5)];
            const f = document.getElementById('strengthFill');
            f.style.width = lvl[0]; f.style.background = lvl[1];
            document.getElementById('strengthLabel').innerHTML = lvl[2];
        }

        document.getElementById('reg_confirm').addEventListener('input', function() {
            const pass = document.getElementById('reg_password').value;
            const msg  = document.getElementById('confirmMsg');
            if (!this.value) { msg.innerHTML = ''; return; }
            msg.innerHTML = (pass === this.value)
                ? '<span style="color:#059669"><i class="bi bi-check-circle-fill me-1"></i>Kata sandi cocok</span>'
                : '<span style="color:#dc2626"><i class="bi bi-x-circle-fill me-1"></i>Kata sandi tidak cocok</span>';
        });

        document.getElementById('registerForm').addEventListener('submit', function(e) {
            if (document.getElementById('reg_password').value !== document.getElementById('reg_confirm').value) {
                e.preventDefault();
                alert('Kata sandi dan konfirmasi tidak cocok!');
                return;
            }
            const btn = document.getElementById('registerBtn');
            btn.innerHTML = '<span class="spinner-border spinner-border-sm me-2"></span> Mendaftarkan...';
            btn.disabled = true;
        });
    </script>
</body>
</html>
