<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Banner Hasil Nilai -->
        <div class="card card-official p-4 mb-4 border-<?= ($attempt['passed']) ? 'success' : 'danger' ?>" style="background: <?= ($attempt['passed']) ? '#f0fdf4' : '#fef2f2' ?>;">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div>
                    <span class="badge <?= ($attempt['passed']) ? 'bg-success' : 'bg-danger' ?> px-3 py-2 fs-6 mb-2">
                        <?= ($attempt['passed']) ? 'LULUS KOMPETENSI' : 'BELUM MEMENUHI STANDAR' ?>
                    </span>
                    <h3 class="fw-bold text-dark mb-1"><?= esc($quiz['title']) ?></h3>
                    <div class="text-muted small">
                        Waktu Pengiriman: <?= date('d M Y, H:i', strtotime($attempt['submitted_at'])) ?> WIB &middot; Ambang Batas: <?= esc($quiz['passing_score']) ?>
                    </div>
                </div>
                <div class="text-center p-3 bg-white rounded-3 border shadow-sm" style="min-width: 160px;">
                    <div class="text-muted small fw-semibold text-uppercase">Skor Akhir</div>
                    <div class="display-5 fw-bold <?= ($attempt['passed']) ? 'text-success' : 'text-danger' ?>">
                        <?= esc($attempt['score']) ?>
                    </div>
                    <small class="text-muted">dari 100 poin</small>
                </div>
            </div>
        </div>

        <!-- Rincian Pembahasan Soal per Soal -->
        <h5 class="fw-bold text-dark mb-3"><i class="bi bi-journal-check text-success me-2"></i>Rincian Pembahasan & Kunci Jawaban</h5>

        <?php $no = 1; foreach ($answers as $ans): ?>
            <div class="card card-official mb-4 p-4 border-start border-4 border-<?= ($ans['is_correct']) ? 'success' : 'danger' ?>">
                <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                    <span class="fw-bold fs-6 text-dark">Soal Nomor <?= $no++ ?></span>
                    <div>
                        <?php if ($ans['is_correct']): ?>
                            <span class="badge bg-success px-3 py-2"><i class="bi bi-check-circle me-1"></i> Benar (+<?= esc($ans['score_earned']) ?> poin)</span>
                        <?php else: ?>
                            <span class="badge bg-danger px-3 py-2"><i class="bi bi-x-circle me-1"></i> Salah (0 poin)</span>
                        <?php endif; ?>
                    </div>
                </div>

                <div class="fs-6 text-dark mb-3">
                    <?= $ans['question_text'] ?>
                </div>

                <div class="row g-2 mb-3 small">
                    <div class="col-md-6">
                        <div class="p-2 border rounded bg-light">
                            <strong>Jawaban Anda:</strong>
                            <span class="d-block mt-1 font-monospace fw-bold <?= ($ans['is_correct']) ? 'text-success' : 'text-danger' ?>">
                                <?= esc($ans['user_answer'] ?: '(Tidak dijawab)') ?>
                            </span>
                        </div>
                    </div>
                    <?php if (! $ans['is_correct'] && $ans['code_answer_key']): ?>
                        <div class="col-md-6">
                            <div class="p-2 border rounded bg-success-subtle border-success-subtle">
                                <strong class="text-success">Kunci Kode yang Benar:</strong>
                                <span class="d-block mt-1 font-monospace fw-bold text-success">
                                    <?= esc($ans['code_answer_key']) ?>
                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Pembahasan & Sitasi Resmi (FR-42) -->
                <div class="p-3 bg-light rounded-3 border">
                    <div class="fw-bold text-success mb-1 small"><i class="bi bi-info-circle me-1"></i> Pembahasan Alur Penalaran:</div>
                    <p class="small text-dark mb-2"><?= esc($ans['explanation']) ?></p>
                    <?php if (! empty($ans['reference_source'])): ?>
                        <div class="small text-muted border-top pt-2">
                            <i class="bi bi-bookmark-check-fill text-success me-1"></i> <strong>Rujukan Resmi:</strong> <?= esc($ans['reference_source']) ?>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>

        <div class="text-center py-3">
            <a href="<?= site_url('mahasiswa/quizzes') ?>" class="btn btn-green-official px-4">
                <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar Latihan Kuis
            </a>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
