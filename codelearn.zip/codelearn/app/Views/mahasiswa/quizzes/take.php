<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Sticky Timer Strip -->
        <div class="card card-official sticky-top shadow-sm mb-4 border-success" style="top: 75px; z-index: 1000; background: #f0fdf4;">
            <div class="card-body py-2 px-3 d-flex justify-content-between align-items-center">
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-success text-white">UJIAN AKTIF</span>
                    <strong class="text-dark small d-none d-sm-inline"><?= esc($quiz['title']) ?></strong>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <i class="bi bi-stopwatch-fill text-danger fs-5"></i>
                    <span class="small fw-semibold text-muted">Sisa Waktu:</span>
                    <span id="timerCountdown" class="fs-5 fw-bold text-danger font-monospace">--:--</span>
                </div>
            </div>
        </div>

        <form id="quizForm" action="<?= site_url('mahasiswa/quizzes/submit/' . $attemptId) ?>" method="post">
            <?= csrf_field() ?>

            <?php $no = 1; foreach ($quiz['questions'] as $q): ?>
                <div class="card card-official mb-4 p-4" id="soal-<?= $no ?>">
                    <div class="d-flex justify-content-between align-items-center mb-3 pb-2 border-bottom">
                        <span class="badge bg-success px-3 py-2 fs-6">
                            Soal Nomor <?= $no ?>
                        </span>
                        <span class="badge bg-light text-muted border text-capitalize">
                            Tipe: <?= esc(str_replace('_', ' ', $q['type'])) ?> &middot; Bobot: <?= esc($q['weight']) ?> Poin
                        </span>
                    </div>

                    <div class="fs-6 text-dark mb-4 fw-medium">
                        <?= $q['question_text'] ?>
                    </div>

                    <!-- Pilihan Ganda -->
                    <?php if ($q['type'] === 'multiple_choice' || $q['type'] === 'true_false'): ?>
                        <div class="d-flex flex-column gap-2 mb-2">
                            <?php foreach ($q['options'] as $idx => $opt): ?>
                                <label class="p-3 border rounded-3 bg-light d-flex align-items-center gap-3 cursor-pointer option-item">
                                    <input class="form-check-input mt-0 fs-5" type="radio" name="answers[<?= $q['id'] ?>]" value="<?= esc($opt['option_text']) ?>">
                                    <span class="text-dark"><?= esc($opt['option_text']) ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>

                    <!-- Isian Kode ICD-10 -->
                    <?php elseif ($q['type'] === 'code_fill'): ?>
                        <div class="p-3 bg-light rounded-3 border">
                            <label class="form-label small fw-bold text-success mb-2">
                                <i class="bi bi-keyboard me-1"></i> Masukkan Kode ICD-10 Diagnosis:
                            </label>
                            <input type="text" name="answers[<?= $q['id'] ?>]" class="form-control form-control-lg font-monospace text-uppercase" placeholder="Contoh: I10 atau A09.0" style="max-width: 300px;">
                            <div class="small text-muted mt-2">
                                * Tuliskan kode diagnosis secara spesifik sesuai kaidah ICD-10 WHO.
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            <?php $no++; endforeach; ?>

            <div class="card card-official p-4 text-center">
                <h5 class="fw-bold mb-2">Konfirmasi Pengiriman Ujian</h5>
                <p class="text-muted small mb-3">Pastikan Anda telah memeriksa kembali seluruh jawaban sebelum mengirimkan hasil ujian.</p>
                <div class="d-flex justify-content-center gap-2">
                    <button type="submit" class="btn btn-green-official px-5 py-2 fs-6" onclick="return confirm('Kirimkan lembar jawaban Anda sekarang?')">
                        <i class="bi bi-send-check me-1"></i> Selesaikan & Kirim Ujian
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    // Timer Countdown Ujian
    const durationMinutes = <?= (int) $quiz['duration_minutes'] ?>;
    let timeRemaining = durationMinutes * 60;
    const timerDisplay = document.getElementById('timerCountdown');
    const form = document.getElementById('quizForm');

    const interval = setInterval(function() {
        const minutes = Math.floor(timeRemaining / 60);
        const seconds = timeRemaining % 60;
        timerDisplay.textContent = 
            (minutes < 10 ? '0' : '') + minutes + ':' + 
            (seconds < 10 ? '0' : '') + seconds;

        if (timeRemaining <= 0) {
            clearInterval(interval);
            alert('Waktu ujian telah berakhir! Sistem akan mengirimkan jawaban Anda secara otomatis.');
            form.submit();
        }
        timeRemaining--;
    }, 1000);
</script>
<?= $this->endSection() ?>
