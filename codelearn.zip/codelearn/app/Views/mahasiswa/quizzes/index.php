<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-pencil-square"></i> Evaluasi Formatif</span>
            <span class="badge bg-light text-muted border">FR-24, FR-40</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-file-earmark-check text-success me-2"></i>Latihan Kuis & Ujian Koding
        </h3>
        <p class="text-muted mb-0">Uji ketepatan pemahaman terminologi medis dan kecepatan penetapan kode diagnosis dengan auto-grading instan.</p>
    </div>
</div>

<div class="row g-4">
    <?php if (empty($quizzes)): ?>
        <div class="col-12 text-center py-5 text-muted">
            <i class="bi bi-inbox fs-1 d-block mb-2"></i>
            Belum ada kuis atau ujian yang aktif untuk kelas Anda saat ini.
        </div>
    <?php else: ?>
        <?php foreach ($quizzes as $qz): ?>
            <div class="col-md-6">
                <div class="card card-official h-100">
                    <div class="card-header-official d-flex justify-content-between align-items-center">
                        <span class="badge bg-light text-dark border">
                            <i class="bi bi-clock me-1"></i> <?= esc($qz['duration_minutes']) ?> Menit
                        </span>
                        <span class="badge bg-success-subtle text-success">
                            Standar Lulus: ≥ <?= esc($qz['passing_score']) ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <h5 class="fw-bold text-dark mb-2"><?= esc($qz['title']) ?></h5>
                        <p class="text-muted small mb-3"><?= esc($qz['description'] ?? 'Latihan mandiri kuis koding diagnosis.') ?></p>

                        <?php if ($qz['last_attempt']): ?>
                            <div class="p-3 bg-light rounded-3 border mb-3 d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="small text-muted">Skor Percobaan Terakhir:</div>
                                    <div class="fs-4 fw-bold <?= ($qz['last_attempt']['score'] >= $qz['passing_score']) ? 'text-success' : 'text-danger' ?>">
                                        <?= esc($qz['last_attempt']['score']) ?> / 100
                                    </div>
                                </div>
                                <div>
                                    <a href="<?= site_url('mahasiswa/quizzes/review/' . $qz['last_attempt']['id']) ?>" class="btn btn-sm btn-outline-secondary">
                                        <i class="bi bi-journal-text me-1"></i> Lihat Pembahasan
                                    </a>
                                </div>
                            </div>
                        <?php endif; ?>

                        <div class="d-grid">
                            <a href="<?= site_url('mahasiswa/quizzes/start/' . $qz['id']) ?>" class="btn btn-green-official" onclick="return confirm('Mulai kuis sekarang? Waktu pengerjaan akan langsung berjalan.')">
                                <i class="bi bi-play-circle me-1"></i> <?= ($qz['last_attempt']) ? 'Kerjakan Ulang Kuis' : 'Mulai Kerjakan Kuis' ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?= $this->endSection() ?>
