<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-book-half"></i> Pembelajaran Mandiri</span>
            <span class="badge bg-light text-muted border">FR-10, FR-13</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-journal-medical text-success me-2"></i>Modul Materi Pembelajaran Koding
        </h3>
        <p class="text-muted mb-0">Pelajari konsep terminologi medis, struktur Volume ICD-10, dan kaidah koding diagnosis morbiditas.</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <div class="card card-official p-3 d-inline-block text-start" style="min-width: 250px;">
            <div class="d-flex justify-content-between align-items-center mb-1">
                <span class="small fw-bold text-success">Progres Kurikulum:</span>
                <span class="small fw-bold"><?= $completedCount ?> / <?= $totalTopics ?> Topik (<?= $percent ?>%)</span>
            </div>
            <div class="progress" style="height: 8px;">
                <div class="progress-bar bg-success" style="width: <?= $percent ?>%"></div>
            </div>
        </div>
    </div>
</div>

<div class="row g-4">
    <?php foreach ($modules as $m): ?>
        <div class="col-md-6 col-lg-4">
            <div class="card card-official h-100 d-flex flex-column">
                <div class="card-header-official d-flex align-items-center gap-2">
                    <div class="bg-success text-white p-2 rounded-2">
                        <i class="bi <?= esc($m['icon']) ?>"></i>
                    </div>
                    <div>
                        <div class="fw-bold text-dark mb-0 fs-6"><?= esc($m['title']) ?></div>
                        <small class="text-muted"><?= count($m['topics']) ?> Topik Pembelajaran</small>
                    </div>
                </div>
                <div class="card-body flex-grow-1">
                    <p class="text-muted small mb-3"><?= esc($m['description']) ?></p>

                    <div class="list-group list-group-flush mb-3 border rounded-2">
                        <?php foreach ($m['topics'] as $tp): ?>
                            <?php $isDone = in_array($tp['id'], $completedTopicIds, true); ?>
                            <a href="<?= site_url('mahasiswa/modules/read/' . $tp['id']) ?>" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center py-2 px-3 small">
                                <div>
                                    <span class="text-dark fw-semibold"><?= esc($tp['title']) ?></span>
                                    <div class="text-muted" style="font-size: 0.75rem;"><i class="bi bi-clock me-1"></i><?= esc($tp['estimated_minutes']) ?> mnt</div>
                                </div>
                                <?php if ($isDone): ?>
                                    <span class="badge bg-success-subtle text-success"><i class="bi bi-check2-circle"></i> Selesai</span>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted border">Belum</span>
                                <?php endif; ?>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>
<?= $this->endSection() ?>
