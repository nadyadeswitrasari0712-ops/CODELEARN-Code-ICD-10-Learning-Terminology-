<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="mb-3">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb small">
            <li class="breadcrumb-item"><a href="<?= site_url('mahasiswa/modules') ?>" class="text-success text-decoration-none">Modul</a></li>
            <li class="breadcrumb-item text-muted"><?= esc($module['title']) ?></li>
            <li class="breadcrumb-item active"><?= esc($topic['title']) ?></li>
        </ol>
    </nav>
</div>

<div class="row g-4">
    <div class="col-lg-9">
        <div class="card card-official p-4 p-md-5">
            <div class="d-flex flex-wrap justify-content-between align-items-center pb-3 mb-4 border-bottom">
                <div>
                    <span class="badge bg-success-subtle text-success border border-success-subtle mb-2">
                        <?= esc($module['title']) ?>
                    </span>
                    <h3 class="fw-bold text-dark mb-1"><?= esc($topic['title']) ?></h3>
                    <div class="text-muted small">
                        <i class="bi bi-clock me-1"></i> Estimasi Waktu Baca: <?= esc($topic['estimated_minutes']) ?> Menit
                    </div>
                </div>
                <div class="mt-3 mt-md-0">
                    <?php if ($isCompleted): ?>
                        <span class="badge bg-success px-3 py-2 fs-6">
                            <i class="bi bi-check-circle-fill me-1"></i> Topik Telah Diselesaikan
                        </span>
                    <?php else: ?>
                        <form action="<?= site_url('mahasiswa/modules/complete/' . $topic['id']) ?>" method="post">
                            <?= csrf_field() ?>
                            <button type="submit" class="btn btn-green-official">
                                <i class="bi bi-check-lg me-1"></i> Tandai Selesai Belajar
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Content HTML -->
            <div class="article-content fs-6" style="line-height: 1.8;">
                <?= $material['content'] ?? '<p class="text-muted">Konten materi belum diisi oleh dosen.</p>' ?>
            </div>

            <!-- Referensi Rujukan Resmi (FR-42) -->
            <?php if (! empty($material['reference_source'])): ?>
                <div class="p-3 bg-light rounded-3 border-start border-4 border-success mt-4 small text-muted">
                    <strong class="text-dark d-block mb-1"><i class="bi bi-journal-bookmark text-success me-1"></i> Rujukan & Referensi Resmi:</strong>
                    <?= esc($material['reference_source']) ?>
                </div>
            <?php endif; ?>

            <div class="d-flex justify-content-between align-items-center mt-5 pt-3 border-top">
                <a href="<?= site_url('mahasiswa/modules') ?>" class="btn btn-outline-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar Modul
                </a>
                <?php if ($nextTopic): ?>
                    <a href="<?= site_url('mahasiswa/modules/read/' . $nextTopic['id']) ?>" class="btn btn-green-official">
                        Lanjut ke Topik Berikutnya <i class="bi bi-arrow-right ms-1"></i>
                    </a>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Sidebar Alat Belajar Klinis Cepat -->
    <div class="col-lg-3">
        <div class="card card-official p-3 mb-3">
            <h6 class="fw-bold text-dark mb-2"><i class="bi bi-tools text-success me-1"></i> Akses Cepat Klinis</h6>
            <div class="d-grid gap-2">
                <a href="<?= site_url('kamus') ?>" target="_blank" class="btn btn-sm btn-outline-green text-start">
                    <i class="bi bi-translate me-1"></i> Buka Kamus Istilah
                </a>
                <a href="<?= site_url('icd10') ?>" target="_blank" class="btn btn-sm btn-outline-green text-start">
                    <i class="bi bi-search me-1"></i> Cari Kode ICD-10
                </a>
            </div>
        </div>

        <div class="card card-official p-3">
            <h6 class="fw-bold text-dark mb-2"><i class="bi bi-lightbulb text-warning me-1"></i> Tips Perekam Medis</h6>
            <p class="small text-muted mb-0">
                Jangan pernah menetapkan kode diagnosis langsung dari ingatan tanpa melakukan verifikasi di Tabular List (Volume 1) untuk memastikan tidak ada aturan eksklusi (*excludes*) yang berlaku.
            </p>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
