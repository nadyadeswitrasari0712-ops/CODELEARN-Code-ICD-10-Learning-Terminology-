<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-8">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-mortarboard-fill"></i> Mahasiswa Rekam Medis (RMIK)</span>
            <span class="badge bg-success-subtle text-success border border-success-subtle">Semester 3 Aktif</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            Selamat Datang, <?= esc($user['name']) ?>!
        </h3>
        <p class="text-muted mb-0">
            NIM: <strong><?= esc($user['nim_nip'] ?? '-') ?></strong> &middot; Portal Pembelajaran Koding Diagnosis & Terminologi Medis Berbasis Web.
        </p>
    </div>
    <div class="col-md-4 text-md-end mt-3 mt-md-0">
        <a href="<?= site_url('mahasiswa/competency') ?>" class="btn btn-green-official">
            <i class="bi bi-award-fill me-1"></i> Cek Kesiapan PKL Anda
        </a>
    </div>
</div>

<!-- 4 Pilar Menu Utama Belajar Mahasiswa (Fase 2 s/d 5) -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-lg-3">
        <div class="card card-official h-100 p-3 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="badge bg-light text-success border border-success">FASE 2</span>
                <i class="bi bi-book-half fs-4 text-success"></i>
            </div>
            <h6 class="fw-bold text-dark mb-1">Materi & Terminologi</h6>
            <p class="small text-muted mb-3">Pelajari modul dasar pembentukan istilah medis & ICD-10.</p>
            <a href="<?= site_url('mahasiswa/modules') ?>" class="btn btn-sm btn-green-official mt-auto">
                Buka Belajar <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card card-official h-100 p-3 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="badge bg-light text-success border border-success">FASE 3</span>
                <i class="bi bi-pencil-square fs-4 text-success"></i>
            </div>
            <h6 class="fw-bold text-dark mb-1">Latihan Bank Soal</h6>
            <p class="small text-muted mb-3">Uji pemahaman kuis objektif & isian kode dengan timer.</p>
            <a href="<?= site_url('mahasiswa/quizzes') ?>" class="btn btn-sm btn-green-official mt-auto">
                Kerjakan Kuis <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card card-official h-100 p-3 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="badge bg-light text-success border border-success">FASE 4</span>
                <i class="bi bi-clipboard2-pulse fs-4 text-success"></i>
            </div>
            <h6 class="fw-bold text-dark mb-1">Simulasi Kasus Riil</h6>
            <p class="small text-muted mb-3">Baca berkas resume medis & tetapkan kode diagnosis.</p>
            <a href="<?= site_url('mahasiswa/cases') ?>" class="btn btn-sm btn-green-official mt-auto">
                Simulasi Kasus <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card card-official h-100 p-3 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="badge bg-light text-success border border-success">FASE 5</span>
                <i class="bi bi-award fs-4 text-success"></i>
            </div>
            <h6 class="fw-bold text-dark mb-1">Kesiapan PKL</h6>
            <p class="small text-muted mb-3">Radar penguasaan bab ICD & rekomendasi belajar.</p>
            <a href="<?= site_url('mahasiswa/competency') ?>" class="btn btn-sm btn-green-official mt-auto">
                Lihat Kesiapan <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>
</div>

<!-- Kelas Terdaftar & Pengumuman -->
<div class="row g-4">
    <div class="col-lg-7">
        <div class="card card-official p-4 h-100">
            <h5 class="fw-bold mb-3 text-dark"><i class="bi bi-journal-bookmark text-success me-2"></i>Kelas Terdaftar Anda</h5>
            <?php foreach ($enrolledClasses as $c): ?>
                <div class="p-3 bg-light rounded-3 border mb-3">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="badge bg-white text-dark border"><?= esc($c['year_name'] ?? '2026/2027') ?></span>
                        <span class="badge bg-success-subtle text-success"><i class="bi bi-check-circle"></i> Mahasiswa Aktif</span>
                    </div>
                    <h5 class="fw-bold text-dark mb-1"><?= esc($c['class_name']) ?></h5>
                    <div class="text-muted small mb-3">
                        <i class="bi bi-person-video3 me-1 text-success"></i> Dosen: <strong><?= esc($c['dosen_name'] ?? '-') ?></strong>
                    </div>
                    <p class="text-muted small mb-3"><?= esc($c['description'] ?? 'Latihan terminologi medis dan koding diagnosis ICD-10.') ?></p>
                    <div class="d-flex gap-2">
                        <a href="<?= site_url('mahasiswa/modules') ?>" class="btn btn-sm btn-green-official">
                            <i class="bi bi-book me-1"></i> Buka Materi
                        </a>
                        <a href="<?= site_url('mahasiswa/cases') ?>" class="btn btn-sm btn-outline-green">
                            <i class="bi bi-clipboard2-pulse me-1"></i> Kerjakan Kasus
                        </a>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="col-lg-5">
        <div class="card card-official p-4 h-100">
            <h5 class="fw-bold mb-3 text-dark"><i class="bi bi-megaphone-fill text-warning me-2"></i>Papan Pengumuman Kelas</h5>
            <div class="p-3 bg-light rounded-3 border-start border-4 border-success mb-3">
                <div class="fw-bold text-dark small mb-1">Persiapan Ujian Mandiri & Pembekalan PKL</div>
                <p class="small text-muted mb-2">
                    Latihan simulasi kasus resume medis telah dibuka. Pastikan Anda menyelesaikan minimal 2 kasus klinis dan mempelajari kamus istilah sebelum pembekalan PKL minggu depan.
                </p>
                <div class="text-muted" style="font-size:0.75rem;">
                    <i class="bi bi-clock me-1"></i> Dosen Pengampu &middot; Bu Ratna, M.Kes
                </div>
            </div>

            <!-- Shortcut Alat Cepat -->
            <div class="p-3 bg-success-subtle rounded-3 border border-success-subtle mt-auto">
                <h6 class="fw-bold text-success mb-2"><i class="bi bi-search-heart me-1"></i> Alat Bantu Klinis Cepat:</h6>
                <div class="d-flex gap-2">
                    <a href="<?= site_url('kamus') ?>" class="btn btn-sm btn-white bg-white text-success border border-success w-100">
                        <i class="bi bi-translate"></i> Kamus Istilah
                    </a>
                    <a href="<?= site_url('icd10') ?>" class="btn btn-sm btn-white bg-white text-success border border-success w-100">
                        <i class="bi bi-search"></i> Cari ICD-10
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
