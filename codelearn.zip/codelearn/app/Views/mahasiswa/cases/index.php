<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-file-earmark-medical"></i> Simulator Rekam Medis</span>
            <span class="badge bg-light text-muted border">FR-30, FR-36</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-clipboard2-pulse text-success me-2"></i>Simulasi Kasus Klinis (Resume Medis)
        </h3>
        <p class="text-muted mb-0">Berlatih membaca berkas rekam medis autentik rumah sakit, menentukan diagnosis utama & sekunder, serta mengode ICD-10.</p>
    </div>
</div>

<div class="row g-4">
    <?php if (empty($cases)): ?>
        <div class="col-12 text-center py-5 text-muted">
            Belum ada kasus klinis yang diterbitkan.
        </div>
    <?php else: ?>
        <?php foreach ($cases as $c): ?>
            <div class="col-md-6">
                <div class="card card-official h-100">
                    <div class="card-header-official d-flex justify-content-between align-items-center">
                        <span class="badge bg-light text-dark border"><code><?= esc($c['case_number']) ?></code></span>
                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle text-capitalize">
                            Tingkat: <?= esc($c['difficulty']) ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <h5 class="fw-bold text-dark mb-2"><?= esc($c['title']) ?></h5>
                        
                        <div class="p-2 bg-light rounded-2 border mb-3 small">
                            <strong>Pasien:</strong> <?= esc($c['patient_name']) ?> (<?= esc($c['patient_age']) ?>, <?= esc($c['patient_gender']) ?>) &middot; <?= esc($c['admission_type']) ?>
                        </div>

                        <p class="text-muted small mb-3">
                            <strong>Keluhan Utama:</strong> <?= esc(substr($c['chief_complaint'], 0, 140)) ?>...
                        </p>

                        <?php if ($c['my_submission']): ?>
                            <div class="p-3 bg-success-subtle rounded-3 border border-success-subtle mb-3 d-flex justify-content-between align-items-center">
                                <div>
                                    <div class="small text-muted">Skor Anda:</div>
                                    <div class="fs-4 fw-bold text-success">
                                        <?= esc($c['my_submission']['dosen_override_score'] !== null ? $c['my_submission']['dosen_override_score'] : $c['my_submission']['total_score']) ?> / 100
                                    </div>
                                </div>
                                <a href="<?= site_url('mahasiswa/cases/review/' . $c['my_submission']['id']) ?>" class="btn btn-sm btn-outline-success">
                                    <i class="bi bi-journal-text me-1"></i> Pembahasan & Catatan Dosen
                                </a>
                            </div>
                        <?php endif; ?>

                        <div class="d-grid">
                            <a href="<?= site_url('mahasiswa/cases/play/' . $c['id']) ?>" class="btn btn-green-official">
                                <i class="bi bi-box-arrow-in-right me-1"></i> <?= ($c['my_submission']) ? 'Simulasi Ulang Kasus Ini' : 'Buka & Kerjakan Kasus' ?>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?= $this->endSection() ?>
