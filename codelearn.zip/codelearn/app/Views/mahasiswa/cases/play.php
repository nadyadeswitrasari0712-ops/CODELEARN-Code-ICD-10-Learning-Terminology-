<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="mb-3 d-flex justify-content-between align-items-center">
    <a href="<?= site_url('mahasiswa/cases') ?>" class="btn btn-sm btn-outline-secondary">
        <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar Kasus
    </a>
    <div>
        <button type="button" class="btn btn-sm btn-outline-green" data-bs-toggle="modal" data-bs-target="#icdHelperModal">
            <i class="bi bi-search me-1"></i> Mode Bantuan: Cari Kode ICD-10 (FR-32)
        </button>
    </div>
</div>

<div class="row g-4">
    <!-- Lembar Berkas Rekam Medis Pasien (Hospital E-Medical Record) -->
    <div class="col-lg-7">
        <div class="card card-official shadow-sm">
            <!-- Official Hospital Header Strip -->
            <div class="p-3 bg-white border-bottom text-center">
                <div class="d-flex justify-content-center align-items-center gap-2 mb-1">
                    <i class="bi bi-hospital fs-3 text-success"></i>
                    <h5 class="fw-bold text-dark mb-0 text-uppercase">Rumah Sakit Umum Pusat Pendidikan RMIK</h5>
                </div>
                <div class="small text-muted text-uppercase fw-semibold" style="letter-spacing: 0.5px;">
                    Lembar Ringkasan Masuk & Keluar (Discharge Summary Record)
                </div>
            </div>

            <!-- Patient Metadata Box -->
            <div class="p-3 bg-light border-bottom">
                <div class="row g-2 small">
                    <div class="col-sm-6">
                        <strong>Nomor Rekam Medis:</strong> <code><?= esc($case['case_number']) ?></code>
                    </div>
                    <div class="col-sm-6">
                        <strong>Jenis Perawatan:</strong> <?= esc($case['admission_type']) ?>
                    </div>
                    <div class="col-sm-6">
                        <strong>Nama Pasien:</strong> <?= esc($case['patient_name']) ?>
                    </div>
                    <div class="col-sm-6">
                        <strong>Umur / Gender:</strong> <?= esc($case['patient_age']) ?> / <?= ($case['patient_gender'] === 'L') ? 'Laki-laki' : 'Perempuan' ?>
                    </div>
                </div>
            </div>

            <!-- Medical Record Narrative Body -->
            <div class="card-body p-4">
                <div class="mb-4">
                    <h6 class="fw-bold text-success border-bottom pb-1"><i class="bi bi-chat-left-dots-fill me-1"></i> 1. Keluhan Utama & Riwayat Penyakit</h6>
                    <p class="text-dark small mb-2"><?= nl2br(esc($case['chief_complaint'])) ?></p>
                    <p class="text-dark small mb-0"><strong>Riwayat Penyakit Terdahulu:</strong> <?= nl2br(esc($case['history_illness'])) ?></p>
                </div>

                <div class="mb-4">
                    <h6 class="fw-bold text-success border-bottom pb-1"><i class="bi bi-heart-pulse-fill me-1"></i> 2. Pemeriksaan Fisik & Tanda Vital</h6>
                    <p class="text-dark small mb-0"><?= nl2br(esc($case['physical_exam'])) ?></p>
                </div>

                <?php if ($case['diagnostic_tests']): ?>
                    <div class="mb-4">
                        <h6 class="fw-bold text-success border-bottom pb-1"><i class="bi bi-file-earmark-medical-fill me-1"></i> 3. Hasil Pemeriksaan Penunjang (Lab & EKG/Radiologi)</h6>
                        <div class="p-3 bg-light rounded-2 border small font-monospace">
                            <?= nl2br(esc($case['diagnostic_tests'])) ?>
                        </div>
                    </div>
                <?php endif; ?>

                <?php if ($case['medical_therapy']): ?>
                    <div class="mb-4">
                        <h6 class="fw-bold text-success border-bottom pb-1"><i class="bi bi-capsule-pill me-1"></i> 4. Tindakan & Terapi Farmakologi</h6>
                        <p class="text-dark small mb-0"><?= nl2br(esc($case['medical_therapy'])) ?></p>
                    </div>
                <?php endif; ?>

                <div class="p-3 bg-success-subtle rounded-3 border border-success-subtle">
                    <h6 class="fw-bold text-success mb-2"><i class="bi bi-person-fill-check me-1"></i> 5. Catatan Resume Keluar Dokter Penanggung Jawab Pelayanan (DPJP)</h6>
                    <p class="text-dark small mb-0 fw-semibold">
                        <?= nl2br(esc($case['attending_physician_notes'])) ?>
                    </p>
                </div>
            </div>
        </div>
    </div>

    <!-- Lembar Kerja Koding Mahasiswa (Worksheet Koding Perekam Medis) -->
    <div class="col-lg-5">
        <div class="card card-official shadow-sm sticky-top" style="top: 80px;">
            <div class="card-header-official">
                <i class="bi bi-pencil-square me-1"></i> Formulir Penetapan Koding Klinis Mahasiswa
            </div>
            <div class="card-body p-4">
                <p class="small text-muted mb-3">
                    Berdasarkan resume medis di samping, tetapkan <strong>Diagnosis Utama</strong> dan <strong>Diagnosis Sekunder</strong> beserta kode <strong>ICD-10</strong> yang akurat.
                </p>

                <form action="<?= site_url('mahasiswa/cases/submit/' . $case['id']) ?>" method="post">
                    <?= csrf_field() ?>

                    <!-- Diagnosis Utama (Bobot 50%) -->
                    <div class="p-3 bg-light rounded-3 border mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="form-label small fw-bold text-success mb-0">
                                <i class="bi bi-1-circle-fill me-1"></i> Diagnosis Utama (Bobot 50%)
                            </label>
                            <span class="badge bg-success-subtle text-success">Wajib</span>
                        </div>
                        <div class="mb-2">
                            <input type="text" name="primary_title" class="form-control form-control-sm" placeholder="Nama Diagnosis Utama (Inggris/Indonesia)" required>
                        </div>
                        <div class="input-group">
                            <span class="input-group-text bg-white small fw-bold text-muted">Kode ICD-10:</span>
                            <input type="text" name="primary_icd" class="form-control form-control-sm font-monospace text-uppercase" placeholder="Contoh: I21.0" required>
                        </div>
                        <div class="small text-muted mt-1" style="font-size: 0.72rem;">
                            * Penilaian parsial: Cocok 3 karakter (40%), cocok 4 karakter (70%), kode lengkap (100%).
                        </div>
                    </div>

                    <!-- Diagnosis Sekunder (Bobot 30%) -->
                    <div class="p-3 bg-light rounded-3 border mb-3">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <label class="form-label small fw-bold text-success mb-0">
                                <i class="bi bi-2-circle-fill me-1"></i> Diagnosis Sekunder (Bobot 30%)
                            </label>
                            <span class="badge bg-secondary-subtle text-secondary">Komorbid / Komplikasi</span>
                        </div>
                        <div class="mb-2">
                            <input type="text" name="secondary_title" class="form-control form-control-sm" placeholder="Nama Diagnosis Sekunder (Komorbid)" required>
                        </div>
                        <div class="input-group">
                            <span class="input-group-text bg-white small fw-bold text-muted">Kode ICD-10:</span>
                            <input type="text" name="secondary_icd" class="form-control form-control-sm font-monospace text-uppercase" placeholder="Contoh: I10" required>
                        </div>
                    </div>

                    <!-- Langkah Penelusuran Lead Term (Bobot 20%) -->
                    <div class="mb-4">
                        <label class="form-label small fw-bold text-dark">
                            <i class="bi bi-journal-arrow-down text-success me-1"></i> Langkah Lead Term Volume 3 (Bobot 20%)
                        </label>
                        <textarea name="lead_term" class="form-control form-control-sm" rows="3" placeholder="Tuliskan kata kunci (lead term) dan subterm yang Anda telusuri di Volume 3..." required></textarea>
                    </div>

                    <button type="submit" class="btn btn-green-official w-100 py-2 fs-6">
                        <i class="bi bi-send-check me-1"></i> Kirim & Dapatkan Nilai Otomatis
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Modal Pencarian Cepat ICD-10 (Mode Bantuan FR-32) -->
<div class="modal fade" id="icdHelperModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h6 class="modal-title fw-bold text-dark">
                    <i class="bi bi-search text-success me-1"></i> Mode Bantuan: Penelusuran Cepat ICD-10
                </h6>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="input-group mb-3">
                    <span class="input-group-text bg-light"><i class="bi bi-search"></i></span>
                    <input type="text" id="liveSearchInput" class="form-control" placeholder="Ketik diagnosis atau kode (misal: Infark, Hipertensi, I21)..." onkeyup="performLiveSearch()">
                </div>

                <div id="liveSearchResults" class="border rounded-2" style="max-height: 320px; overflow-y: auto;">
                    <div class="p-3 text-center text-muted small">
                        Ketik minimal 2 karakter untuk menampilkan hasil pencarian.
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Tutup</button>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    let searchTimeout = null;

    function performLiveSearch() {
        clearTimeout(searchTimeout);
        const query = document.getElementById('liveSearchInput').value.trim();
        const resultsContainer = document.getElementById('liveSearchResults');

        if (query.length < 2) {
            resultsContainer.innerHTML = '<div class="p-3 text-center text-muted small">Ketik minimal 2 karakter untuk mencari kode ICD-10.</div>';
            return;
        }

        searchTimeout = setTimeout(function() {
            resultsContainer.innerHTML = '<div class="p-3 text-center text-muted small"><div class="spinner-border spinner-border-sm text-success me-1"></div> Mencari data...</div>';

            fetch('<?= site_url('api/icd/search?q=') ?>' + encodeURIComponent(query))
                .then(response => response.json())
                .then(data => {
                    if (data.length === 0) {
                        resultsContainer.innerHTML = '<div class="p-3 text-center text-muted small">Tidak ditemukan kode yang cocok.</div>';
                        return;
                    }

                    let html = '<div class="list-group list-group-flush">';
                    data.forEach(item => {
                        html += `
                            <div class="list-group-item d-flex justify-content-between align-items-center py-2 px-3">
                                <div>
                                    <span class="icd-code-pill me-2">${item.code}</span>
                                    <strong class="text-dark small">${item.description}</strong>
                                    <div class="text-muted" style="font-size:0.75rem;">Bab ${item.chapter_no}: ${item.chapter_title}</div>
                                </div>
                                <button type="button" class="btn btn-sm btn-outline-success" onclick="copyIcdCode('${item.code}')">
                                    Pilih
                                </button>
                            </div>
                        `;
                    });
                    html += '</div>';
                    resultsContainer.innerHTML = html;
                })
                .catch(err => {
                    resultsContainer.innerHTML = '<div class="p-3 text-center text-danger small">Gagal memuat data pencarian.</div>';
                });
        }, 300);
    }

    function copyIcdCode(code) {
        navigator.clipboard.writeText(code).then(() => {
            alert('Kode ' + code + ' disalin! Tempelkan pada kolom formulir.');
        });
    }
</script>
<?= $this->endSection() ?>
