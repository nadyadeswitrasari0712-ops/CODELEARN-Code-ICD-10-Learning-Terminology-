<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row justify-content-center">
    <div class="col-lg-10">
        <!-- Banner Skor Hasil Evaluasi -->
        <div class="card card-official p-4 mb-4 border-success" style="background: #f0fdf4;">
            <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
                <div>
                    <span class="badge bg-success px-3 py-2 fs-6 mb-2">
                        HASIL EVALUASI RESUME MEDIS
                    </span>
                    <h3 class="fw-bold text-dark mb-1"><?= esc($case['title']) ?></h3>
                    <div class="text-muted small">
                        Nomor RM: <code><?= esc($case['case_number']) ?></code> &middot; Tanggal Submit: <?= date('d M Y, H:i', strtotime($submission['submitted_at'])) ?> WIB
                    </div>
                </div>
                <div class="text-center p-3 bg-white rounded-3 border shadow-sm" style="min-width: 170px;">
                    <div class="text-muted small fw-semibold text-uppercase">Skor Akhir</div>
                    <div class="display-5 fw-bold text-success">
                        <?= esc($submission['dosen_override_score'] !== null ? $submission['dosen_override_score'] : $submission['total_score']) ?>
                    </div>
                    <small class="text-muted">dari 100 poin</small>
                </div>
            </div>
        </div>

        <!-- Umpan Balik Dosen Pengampu (FR-45) -->
        <?php if (! empty($submission['dosen_notes'])): ?>
            <div class="card card-official p-4 mb-4 border-start border-4 border-primary" style="background: #f8fafc;">
                <h6 class="fw-bold text-primary mb-2"><i class="bi bi-chat-quote-fill me-2"></i>Evaluasi & Catatan Klinis Dosen Pengampu:</h6>
                <p class="text-dark small mb-0 fst-italic">"<?= esc($submission['dosen_notes']) ?>"</p>
                <?php if ($submission['dosen_override_score'] !== null): ?>
                    <div class="small text-muted mt-2">
                        * Dosen telah menyesuaikan skor evaluasi menjadi <strong><?= esc($submission['dosen_override_score']) ?></strong> poin.
                    </div>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <!-- Rincian Penilaian Parsial (FR-34) -->
        <div class="card card-official p-4 mb-4">
            <h5 class="fw-bold text-dark mb-3"><i class="bi bi-diagram-3-fill text-success me-2"></i>Rincian Penilaian Parsial (Multi-Level Matching)</h5>

            <div class="table-responsive">
                <table class="table table-bordered align-middle mb-0">
                    <thead class="table-light small text-uppercase">
                        <tr>
                            <th>Komponen Koding</th>
                            <th>Jawaban Diagnosis Anda</th>
                            <th>Kode ICD-10 Anda</th>
                            <th>Tingkat Kecocokan</th>
                            <th class="text-center">Skor Didapat</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php foreach ($details as $det): ?>
                            <tr>
                                <td>
                                    <strong class="text-dark">
                                        <?= ($det['component_type'] === 'primary') ? '1. Diagnosis Utama (50%)' : '2. Diagnosis Sekunder (30%)' ?>
                                    </strong>
                                </td>
                                <td><?= esc($det['input_diagnosis_text']) ?></td>
                                <td><span class="icd-code-pill"><?= esc($det['input_icd_code']) ?></span></td>
                                <td>
                                    <?php if ($det['match_level'] === 'full'): ?>
                                        <span class="badge bg-success-subtle text-success"><i class="bi bi-check-circle"></i> Cocok Lengkap (100%)</span>
                                    <?php elseif ($det['match_level'] === '4_char'): ?>
                                        <span class="badge bg-warning-subtle text-warning"><i class="bi bi-info-circle"></i> Subkategori 4 Karakter (70%)</span>
                                    <?php elseif ($det['match_level'] === '3_char'): ?>
                                        <span class="badge bg-info-subtle text-info"><i class="bi bi-info-circle"></i> Kategori 3 Karakter (40%)</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger-subtle text-danger"><i class="bi bi-x-circle"></i> Tidak Cocok (0%)</span>
                                    <?php endif; ?>
                                </td>
                                <td class="text-center fw-bold text-success fs-6">
                                    <?= esc($det['earned_score']) ?> / <?= esc($det['max_score']) ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <tr class="table-light">
                            <td colspan="4" class="text-end fw-bold">Skor Langkah Lead Term & Prosedur:</td>
                            <td class="text-center fw-bold text-success fs-6"><?= esc($submission['additional_score']) ?> / 20.00</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Panduan Pembahasan Langkah Koding Standar WHO (FR-35, FR-42) -->
        <div class="card card-official p-4 mb-4">
            <h5 class="fw-bold text-dark mb-3"><i class="bi bi-compass-fill text-success me-2"></i>Panduan Langkah Koding Resmi (Berdasarkan WHO ICD-10)</h5>

            <div class="p-3 bg-light rounded-3 border mb-3">
                <div class="fw-bold text-success small mb-1"><i class="bi bi-1-circle me-1"></i> Penelusuran Indeks Alfabetis (Volume 3):</div>
                <div class="small text-dark font-monospace" style="white-space: pre-line;">
                    <?= esc($case['key']['lead_term_steps']) ?>
                </div>
            </div>

            <div class="p-3 bg-light rounded-3 border mb-3">
                <div class="fw-bold text-success small mb-1"><i class="bi bi-2-circle me-1"></i> Verifikasi Tabular List (Volume 1):</div>
                <p class="small text-dark mb-0"><?= esc($case['key']['tabular_check_steps']) ?></p>
            </div>

            <?php if (! empty($case['key']['inclusion_exclusion_notes'])): ?>
                <div class="p-3 bg-warning-subtle rounded-3 border border-warning-subtle mb-3">
                    <div class="fw-bold text-warning-emphasis small mb-1"><i class="bi bi-exclamation-triangle me-1"></i> Aturan Inklusi & Eksklusi:</div>
                    <p class="small text-dark mb-0"><?= esc($case['key']['inclusion_exclusion_notes']) ?></p>
                </div>
            <?php endif; ?>

            <div class="p-3 bg-light rounded-3 border small text-muted">
                <i class="bi bi-bookmark-check-fill text-success me-1"></i> <strong>Rujukan Resmi:</strong> <?= esc($case['key']['reference_source']) ?>
            </div>
        </div>

        <div class="text-center py-3">
            <a href="<?= site_url('mahasiswa/cases') ?>" class="btn btn-green-official px-4">
                <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar Kasus
            </a>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
