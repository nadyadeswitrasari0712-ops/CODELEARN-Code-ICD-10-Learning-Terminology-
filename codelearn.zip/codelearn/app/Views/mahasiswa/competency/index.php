<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-award-fill"></i> Standar Evaluasi PKL</span>
            <span class="badge bg-light text-muted border">FR-46, FR-61</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-award text-success me-2"></i>Peta Kompetensi & Kesiapan PKL
        </h3>
        <p class="text-muted mb-0">Indikator kesiapan mahasiswa Rekam Medis menghadapi Praktik Kerja Lapangan (PKL) di fasilitas pelayanan kesehatan.</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <button type="button" class="btn btn-outline-secondary" onclick="window.print()">
            <i class="bi bi-printer me-1"></i> Cetak Lembar Kelayakan
        </button>
    </div>
</div>

<!-- Kartu Resmi Kesiapan PKL -->
<div class="card card-official p-4 mb-4 border-success" style="background: linear-gradient(135deg, #f0fdf4 0%, #ffffff 100%);">
    <div class="row align-items-center g-4">
        <div class="col-md-8">
            <div class="d-flex align-items-center gap-2 mb-2">
                <span class="badge bg-<?= $readiness['class'] ?> px-3 py-2 fs-6">
                    STATUS KESIAPAN: <?= strtoupper($readiness['status']) ?>
                </span>
                <span class="small text-muted fw-semibold">Standar Prodi RMIK</span>
            </div>
            <h4 class="fw-bold text-dark mb-2">
                <?= esc($user['name']) ?> <span class="text-muted fw-normal fs-6">(NIM: <?= esc($user['nim_nip'] ?? '-') ?>)</span>
            </h4>
            <p class="text-dark mb-0 small">
                <?= esc($readiness['desc']) ?> Rata-rata akurasi koding diagnosis Anda saat ini mencapai <strong><?= esc($overallAvg) ?>%</strong> dari seluruh latihan dan simulasi kasus yang telah diselesaikan.
            </p>
        </div>
        <div class="col-md-4 text-center border-start-md">
            <div class="p-3 bg-white rounded-3 border shadow-sm d-inline-block" style="min-width: 180px;">
                <div class="text-muted small fw-semibold text-uppercase">Indeks Akurasi Koding</div>
                <div class="display-5 fw-bold text-success mt-1"><?= esc($overallAvg) ?>%</div>
                <small class="badge bg-light text-dark border mt-1">Akumulasi <?= count($scores) ?> Bab</small>
            </div>
        </div>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Radar Chart Kemampuan Mandiri -->
    <div class="col-lg-6">
        <div class="card card-official h-100 p-4">
            <h5 class="fw-bold mb-1 text-dark"><i class="bi bi-radar text-success me-2"></i>Radar Penguasaan per Bab ICD-10</h5>
            <small class="text-muted d-block mb-3">Memetakan kekuatan dan kelemahan spesialisasi koding klinis Anda.</small>
            
            <div class="position-relative" style="height: 300px;">
                <canvas id="studentRadarChart"></canvas>
            </div>
        </div>
    </div>

    <!-- Modul Rekomendasi Remedial Cerdas (FR-46) -->
    <div class="col-lg-6">
        <div class="card card-official h-100 p-4">
            <h5 class="fw-bold mb-1 text-dark"><i class="bi bi-lightbulb-fill text-warning me-2"></i>Rekomendasi Penguatan Belajar</h5>
            <small class="text-muted d-block mb-3">Materi yang disarankan sistem berdasarkan topik dengan nilai belum optimal.</small>

            <?php if (empty($weakChapters)): ?>
                <div class="alert alert-success d-flex align-items-center small mb-3">
                    <i class="bi bi-check-circle-fill me-2 fs-5"></i>
                    <div>Selamat! Seluruh bab ICD-10 Anda telah melampaui standar kelulusan minimal (≥ 70%).</div>
                </div>
            <?php else: ?>
                <div class="alert alert-warning small mb-3">
                    <strong>Perhatian:</strong> Perlu pendalaman intensif pada:
                    <ul class="mb-0 ps-3 mt-1">
                        <?php foreach ($weakChapters as $wc): ?>
                            <li><strong><?= esc($wc['chapter_code']) ?>:</strong> <?= esc($wc['chapter_name']) ?> (Skor: <?= esc($wc['score']) ?>%)</li>
                        <?php endforeach; ?>
                    </ul>
                </div>
            <?php endif; ?>

            <div class="list-group list-group-flush border rounded-3">
                <?php foreach ($recommendedModules as $rm): ?>
                    <div class="list-group-item d-flex justify-content-between align-items-center py-2 px-3 small">
                        <div>
                            <div class="fw-semibold text-dark"><?= esc($rm['title']) ?></div>
                            <div class="text-muted" style="font-size:0.75rem;">Modul Resmi Pembelajaran</div>
                        </div>
                        <a href="<?= site_url('mahasiswa/modules') ?>" class="btn btn-sm btn-outline-green">
                            Pelajari <i class="bi bi-arrow-right"></i>
                        </a>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>

<!-- Tabel Rincian Skor per Bab -->
<div class="card card-official p-4">
    <h5 class="fw-bold mb-3 text-dark"><i class="bi bi-list-check text-success me-2"></i>Transkrip Capaian Koding per Bab Klasifikasi</h5>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
                <tr>
                    <th class="ps-4">Kode Bab</th>
                    <th>Nama Bab / Spesialisasi Penyakit</th>
                    <th class="text-center">Akurasi Koding</th>
                    <th class="text-center">Total Latihan</th>
                    <th class="text-center">Kategori Kelayakan</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scores as $s): ?>
                    <tr>
                        <td class="ps-4">
                            <span class="badge bg-light text-dark border fw-bold"><?= esc($s['chapter_code']) ?></span>
                        </td>
                        <td>
                            <div class="fw-semibold text-dark"><?= esc($s['chapter_name']) ?></div>
                        </td>
                        <td class="text-center">
                            <span class="fw-bold fs-6 <?= ((float)$s['score'] >= 75) ? 'text-success' : 'text-danger' ?>">
                                <?= esc($s['score']) ?>%
                            </span>
                        </td>
                        <td class="text-center text-muted small">
                            <?= esc($s['total_assessments']) ?> Sesi
                        </td>
                        <td class="text-center">
                            <?php if ((float)$s['score'] >= 85): ?>
                                <span class="badge bg-success-subtle text-success border border-success-subtle">Mahir</span>
                            <?php elseif ((float)$s['score'] >= 70): ?>
                                <span class="badge bg-info-subtle text-info border border-info-subtle">Cakap</span>
                            <?php elseif ((float)$s['score'] >= 55): ?>
                                <span class="badge bg-warning-subtle text-warning border border-warning-subtle">Berkembang</span>
                            <?php else: ?>
                                <span class="badge bg-danger-subtle text-danger border border-danger-subtle">Perlu Pendampingan</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const labels = <?= $radarLabels ?>;
        const values = <?= $radarValues ?>;

        const ctx = document.getElementById('studentRadarChart').getContext('2d');
        new Chart(ctx, {
            type: 'radar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Tingkat Kemampuan Anda (%)',
                    data: values,
                    backgroundColor: 'rgba(16, 185, 129, 0.25)',
                    borderColor: '#059669',
                    pointBackgroundColor: '#047857',
                    pointBorderColor: '#ffffff',
                    pointHoverBackgroundColor: '#ffffff',
                    pointHoverBorderColor: '#047857'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        angleLines: { color: 'rgba(0, 0, 0, 0.08)' },
                        suggestedMin: 0,
                        suggestedMax: 100,
                        ticks: { stepSize: 20 }
                    }
                }
            }
        });
    });
</script>
<?= $this->endSection() ?>
