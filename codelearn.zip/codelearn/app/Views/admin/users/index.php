<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-6">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-people-fill"></i> Manajemen Akun</span>
            <span class="badge bg-light text-muted border">FR-01, FR-03</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            Manajemen Pengguna Sistem
        </h3>
        <p class="text-muted mb-0">Kelola akun Administrator, Dosen Koding, dan Mahasiswa RMIK.</p>
    </div>
    <div class="col-md-6 text-md-end mt-3 mt-md-0 d-flex flex-wrap justify-content-md-end gap-2">
        <button type="button" class="btn btn-green-official" data-bs-toggle="modal" data-bs-target="#addUserModal">
            <i class="bi bi-person-plus-fill me-1"></i> Tambah Pengguna
        </button>
        <button type="button" class="btn btn-outline-green" data-bs-toggle="modal" data-bs-target="#importCsvModal">
            <i class="bi bi-file-earmark-spreadsheet me-1"></i> Impor CSV Massal
        </button>
    </div>
</div>

<!-- Filters & Search Bar -->
<div class="card card-official p-3 mb-4">
    <form method="get" action="<?= site_url('admin/users') ?>" class="row g-2 align-items-center">
        <div class="col-md-5">
            <div class="input-group">
                <span class="input-group-text bg-white text-success border-end-0"><i class="bi bi-search"></i></span>
                <input type="text" name="q" class="form-control border-start-0" placeholder="Cari nama, email, atau NIM/NIP..." value="<?= esc($search ?? '') ?>">
            </div>
        </div>
        <div class="col-md-4">
            <select name="role" class="form-select">
                <option value="">-- Semua Peran Pengguna --</option>
                <option value="admin" <?= ($roleFilter === 'admin') ? 'selected' : '' ?>>Administrator</option>
                <option value="dosen" <?= ($roleFilter === 'dosen') ? 'selected' : '' ?>>Dosen Pengampu</option>
                <option value="mahasiswa" <?= ($roleFilter === 'mahasiswa') ? 'selected' : '' ?>>Mahasiswa</option>
            </select>
        </div>
        <div class="col-md-3 d-flex gap-2">
            <button type="submit" class="btn btn-green-official w-100">
                <i class="bi bi-funnel me-1"></i> Filter
            </button>
            <?php if ($search || $roleFilter): ?>
                <a href="<?= site_url('admin/users') ?>" class="btn btn-outline-secondary">Reset</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<!-- User Table -->
<div class="card card-official">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
                <tr>
                    <th class="ps-4">Pengguna</th>
                    <th>NIM / NIP</th>
                    <th>Peran</th>
                    <th>Status</th>
                    <th>Terdaftar Sejak</th>
                    <th class="text-end pe-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($users)): ?>
                    <tr>
                        <td colspan="6" class="text-center py-4 text-muted">
                            <i class="bi bi-inbox fs-2 d-block mb-2"></i>
                            Tidak ada data pengguna ditemukan.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($users as $u): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="d-flex align-items-center gap-2">
                                    <div class="bg-success text-white rounded-circle d-flex align-items-center justify-content-center fw-bold" style="width: 38px; height: 38px; font-size: 0.95rem;">
                                        <?= strtoupper(substr($u['name'], 0, 1)) ?>
                                    </div>
                                    <div>
                                        <div class="fw-semibold text-dark"><?= esc($u['name']) ?></div>
                                        <div class="text-muted small"><?= esc($u['email']) ?></div>
                                    </div>
                                </div>
                            </td>
                            <td>
                                <code><?= esc($u['nim_nip'] ?? '-') ?></code>
                            </td>
                            <td>
                                <span class="badge rounded-pill <?= 'badge-role-' . $u['role'] ?> text-capitalize px-3 py-1">
                                    <?= esc($u['role']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($u['status'] === 'active'): ?>
                                    <span class="badge bg-success-subtle text-success border border-success-subtle">
                                        <i class="bi bi-check-circle me-1"></i> Aktif
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle">
                                        <i class="bi bi-x-circle me-1"></i> Nonaktif
                                    </span>
                                <?php endif; ?>
                            </td>
                            <td class="small text-muted">
                                <?= $u['created_at'] ? date('d M Y', strtotime($u['created_at'])) : '-' ?>
                            </td>
                            <td class="text-end pe-4">
                                <?php if ($u['id'] != session()->get('user')['id']): ?>
                                    <form action="<?= site_url('admin/users/' . $u['id'] . '/toggle') ?>" method="post" class="d-inline">
                                        <?= csrf_field() ?>
                                        <button type="submit" class="btn btn-sm <?= ($u['status'] === 'active') ? 'btn-outline-danger' : 'btn-outline-success' ?>">
                                            <?php if ($u['status'] === 'active'): ?>
                                                <i class="bi bi-power"></i> Nonaktifkan
                                            <?php else: ?>
                                                <i class="bi bi-check-lg"></i> Aktifkan
                                            <?php endif; ?>
                                        </button>
                                    </form>
                                <?php else: ?>
                                    <span class="badge bg-light text-muted border">Akun Anda</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Pengguna -->
<div class="modal fade" id="addUserModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="<?= site_url('admin/users') ?>" method="post" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Tambah Pengguna Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Nama Lengkap</label>
                    <input type="text" name="name" class="form-control" placeholder="Contoh: Siti Rahmawati, S.Tr.Kes" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Alamat Email</label>
                    <input type="email" name="email" class="form-control" placeholder="user@kodemedis.ac.id" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">NIM atau NIP</label>
                    <input type="text" name="nim_nip" class="form-control" placeholder="Contoh: 202401050 atau 19800101...">
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Peran (Role)</label>
                    <select name="role" class="form-select" required>
                        <option value="mahasiswa">Mahasiswa</option>
                        <option value="dosen">Dosen</option>
                        <option value="admin">Administrator</option>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Kata Sandi Awal</label>
                    <input type="password" name="password" class="form-control" placeholder="Minimal 6 karakter" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-green-official">Simpan Pengguna</button>
            </div>
        </form>
    </div>
</div>

<!-- Modal Impor CSV -->
<div class="modal fade" id="importCsvModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="<?= site_url('admin/users/import-csv') ?>" method="post" enctype="multipart/form-data" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Impor Pengguna Massal via CSV</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <p class="small text-muted mb-3">
                    Format kolom file <code>.csv</code>: <br>
                    <strong>nim_nip, name, email, role</strong> (role: <em>admin / dosen / mahasiswa</em>).
                </p>
                <div class="p-2 bg-light border rounded small mb-3">
                    <strong>Contoh format CSV:</strong><br>
                    <code>nim_nip,name,email,role<br>202401010,Ahmad Fauzi,ahmad@student.kodemedis.ac.id,mahasiswa</code>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Pilih Berkas CSV</label>
                    <input type="file" name="csv_file" class="form-control" accept=".csv" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-green-official">Mulai Impor</button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
