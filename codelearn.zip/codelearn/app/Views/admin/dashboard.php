<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-8">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-shield-check"></i> Panel Administrator</span>
            <span class="badge bg-light text-muted border">Fase 1</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            Dashboard Administrator Prodi RMIK
        </h3>
        <p class="text-muted mb-0">
            Selamat datang kembali, <strong><?= esc($user['name']) ?></strong>. Kelola pengguna, kelas akademik, dan pantau aktivitas sistem.
        </p>
    </div>
    <div class="col-md-4 text-md-end mt-3 mt-md-0">
        <span class="badge bg-success px-3 py-2 fs-6">
            <i class="bi bi-calendar-check me-1"></i> Tahun: <?= esc($stats['active_year']['year_name'] ?? '2026/2027') ?> (<?= ucfirst(esc($stats['active_year']['semester'] ?? 'ganjil')) ?>)
        </span>
    </div>
</div>

<!-- Stat Cards -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-lg-4">
        <div class="card card-official p-4 h-100 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="text-muted small fw-bold text-uppercase">Total Mahasiswa</div>
                    <div class="fs-2 fw-bold text-dark mt-1"><?= esc($stats['total_students']) ?></div>
                    <div class="small text-success mt-1"><i class="bi bi-check-circle"></i> Terdaftar aktif</div>
                </div>
                <div class="bg-success-subtle text-success p-3 rounded-4 fs-3">
                    <i class="bi bi-mortarboard-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-4">
        <div class="card card-official p-4 h-100 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="text-muted small fw-bold text-uppercase">Dosen Pengampu</div>
                    <div class="fs-2 fw-bold text-dark mt-1"><?= esc($stats['total_lecturers']) ?></div>
                    <div class="small text-info mt-1"><i class="bi bi-person-video3"></i> Dosen terdaftar</div>
                </div>
                <div class="bg-info-subtle text-info p-3 rounded-4 fs-3">
                    <i class="bi bi-person-badge-fill"></i>
                </div>
            </div>
        </div>
    </div>

    <div class="col-sm-6 col-lg-4">
        <div class="card card-official p-4 h-100 border-start border-4 border-warning">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <div class="text-muted small fw-bold text-uppercase">Kelas Perkuliahan</div>
                    <div class="fs-2 fw-bold text-dark mt-1"><?= esc($stats['total_classes']) ?></div>
                    <div class="small text-muted mt-1"><i class="bi bi-book"></i> Semester berjalan</div>
                </div>
                <div class="bg-warning-subtle text-warning p-3 rounded-4 fs-3">
                    <i class="bi bi-collection-fill"></i>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Quick Action Shortcuts & Audit Log -->
<div class="row g-4">
    <div class="col-lg-4">
        <div class="card card-official p-4 mb-4">
            <h5 class="fw-bold mb-3 text-dark"><i class="bi bi-lightning-charge text-warning me-2"></i>Aksi Cepat</h5>
            <div class="d-grid gap-2">
                <a href="<?= site_url('admin/users') ?>" class="btn btn-outline-green text-start py-2">
                    <i class="bi bi-person-plus-fill me-2"></i> Tambah / Kelola Pengguna
                </a>
                <a href="<?= site_url('admin/classes') ?>" class="btn btn-green-official text-start py-2">
                    <i class="bi bi-plus-circle-fill me-2"></i> Buka Kelas Akademik Baru
                </a>
                <a href="<?= site_url('admin/users') ?>" class="btn btn-outline-secondary text-start py-2">
                    <i class="bi bi-file-earmark-spreadsheet-fill me-2"></i> Impor Pengguna CSV Massal
                </a>
            </div>
        </div>

        <div class="card card-official p-4">
            <h5 class="fw-bold mb-2 text-dark"><i class="bi bi-shield-lock-fill text-success me-2"></i>Status Keamanan</h5>
            <div class="p-3 bg-light rounded-3 small text-muted">
                <div class="fw-bold text-success mb-1">Proteksi RBAC & MySQL Aktif</div>
                <p class="mb-0">
                    Setiap hak akses role (Admin, Dosen, Mahasiswa) terfilter ketat melalui sistem Filter CodeIgniter 4.
                </p>
            </div>
        </div>
    </div>

    <div class="col-lg-8">
        <div class="card card-official p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0 text-dark"><i class="bi bi-clock-history text-success me-2"></i>Log Aktivitas Terbaru (Audit Trail)</h5>
                <span class="badge bg-light text-secondary border">FR-71</span>
            </div>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light small text-uppercase text-muted">
                        <tr>
                            <th>Waktu</th>
                            <th>Pengguna</th>
                            <th>Aksi</th>
                            <th>Modul</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody class="small">
                        <?php if (empty($recentLogs)): ?>
                            <tr>
                                <td colspan="5" class="text-center text-muted py-3">Belum ada aktivitas tercatat.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($recentLogs as $log): ?>
                                <tr>
                                    <td class="text-nowrap text-muted"><?= date('d M H:i', strtotime($log['created_at'])) ?></td>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= esc($log['user_name'] ?? 'Sistem') ?></div>
                                        <div class="text-muted" style="font-size: 0.72rem;"><?= esc($log['user_role'] ?? '-') ?></div>
                                    </td>
                                    <td><span class="badge bg-light text-dark border"><?= esc($log['action']) ?></span></td>
                                    <td><span class="badge bg-success-subtle text-success border border-success-subtle"><?= esc($log['module']) ?></span></td>
                                    <td><?= esc($log['detail'] ?? '-') ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
