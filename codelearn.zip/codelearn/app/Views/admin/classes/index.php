<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-6">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-mortarboard-fill"></i> Akademik & Kurikulum</span>
            <span class="badge bg-light text-muted border">FR-04, FR-70</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            Manajemen Kelas & Roster Perkuliahan
        </h3>
        <p class="text-muted mb-0">Kelola kelas perkuliahan RMIK, dosen pembina, dan roster mahasiswa terdaftar.</p>
    </div>
    <div class="col-md-6 text-md-end mt-3 mt-md-0">
        <button type="button" class="btn btn-green-official" data-bs-toggle="modal" data-bs-target="#addClassModal">
            <i class="bi bi-plus-lg me-1"></i> Buka Kelas Perkuliahan Baru
        </button>
    </div>
</div>

<!-- Class Table -->
<div class="card card-official">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
                <tr>
                    <th class="ps-4">Nama Kelas</th>
                    <th>Tahun Akademik</th>
                    <th>Dosen Pengampu</th>
                    <th>Mahasiswa Terdaftar</th>
                    <th class="text-end pe-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($classes)): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5 text-muted">
                            Belum ada kelas perkuliahan dibuat.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($classes as $c): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold text-dark"><?= esc($c['class_name']) ?></div>
                                <div class="text-muted small"><?= esc($c['description'] ?? 'Tanpa deskripsi') ?></div>
                            </td>
                            <td>
                                <span class="badge bg-light text-secondary border">
                                    <?= esc($c['year_name'] ?? '-') ?> (Semester <?= ucfirst(esc($c['semester'] ?? '')) ?>)
                                </span>
                            </td>
                            <td>
                                <div class="fw-semibold text-dark"><i class="bi bi-person-video3 me-1 text-success"></i> <?= esc($c['dosen_name'] ?? 'Belum ditentukan') ?></div>
                                <div class="text-muted small"><?= esc($c['dosen_email'] ?? '') ?></div>
                            </td>
                            <td>
                                <span class="badge bg-success-subtle text-success fw-bold px-3 py-2">
                                    <i class="bi bi-people me-1"></i> <?= esc($c['total_students']) ?> Mahasiswa
                                </span>
                            </td>
                            <td class="text-end pe-4">
                                <a href="<?= site_url('admin/classes/' . $c['id']) ?>" class="btn btn-sm btn-outline-green">
                                    <i class="bi bi-sliders me-1"></i> Kelola Mahasiswa
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Buka Kelas Baru -->
<div class="modal fade" id="addClassModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="<?= site_url('admin/classes') ?>" method="post" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Buka Kelas Perkuliahan Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Nama Kelas</label>
                    <input type="text" name="class_name" class="form-control" placeholder="Contoh: RMIK 3B - Koding Diagnosis & Rekam Medis" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Tahun Akademik</label>
                    <select name="academic_year_id" class="form-select" required>
                        <?php foreach ($academicYears as $y): ?>
                            <option value="<?= $y['id'] ?>" <?= ($y['is_active']) ? 'selected' : '' ?>>
                                <?= esc($y['year_name']) ?> - Semester <?= ucfirst(esc($y['semester'])) ?> <?= ($y['is_active']) ? '(Aktif)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Dosen Pengampu</label>
                    <select name="dosen_id" class="form-select" required>
                        <option value="">-- Pilih Dosen Pengampu --</option>
                        <?php foreach ($lecturers as $l): ?>
                            <option value="<?= $l['id'] ?>"><?= esc($l['name']) ?> (<?= esc($l['email']) ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Deskripsi Kelas (Opsional)</label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Catatan pengantar kelas..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-green-official">Simpan Kelas</button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
