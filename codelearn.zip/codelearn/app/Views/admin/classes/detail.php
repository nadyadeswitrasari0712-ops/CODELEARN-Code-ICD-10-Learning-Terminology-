<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="mb-4">
    <a href="<?= site_url('admin/classes') ?>" class="btn btn-sm btn-outline-secondary mb-2">
        <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar Kelas
    </a>
    <div class="d-flex flex-wrap justify-content-between align-items-center">
        <div>
            <h3 class="fw-bold text-dark mb-1">
                <?= esc($class['class_name']) ?>
            </h3>
            <div class="text-muted small">
                Dosen Pengampu: <strong><?= esc($class['dosen_name'] ?? '-') ?></strong> &middot; Tahun: <?= esc($class['year_name'] ?? '-') ?> (Semester <?= ucfirst(esc($class['semester'] ?? '')) ?>)
            </div>
        </div>
        <div class="mt-3 mt-md-0">
            <span class="badge bg-success px-3 py-2 fs-6">
                Total <?= count($enrolledStudents) ?> Mahasiswa Terdaftar
            </span>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Form Tambah Mahasiswa ke Kelas -->
    <div class="col-lg-4">
        <div class="card card-official p-4 mb-4">
            <h5 class="fw-bold mb-3 text-dark"><i class="bi bi-person-plus text-success me-2"></i>Daftarkan Mahasiswa</h5>
            <p class="small text-muted mb-3">Pilih mahasiswa aktif yang belum terdaftar di kelas perkuliahan ini.</p>

            <form action="<?= site_url('admin/classes/' . $class['id'] . '/enroll') ?>" method="post">
                <?= csrf_field() ?>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Pilih Mahasiswa</label>
                    <select name="student_id" class="form-select" required <?= empty($availableStudents) ? 'disabled' : '' ?>>
                        <?php if (empty($availableStudents)): ?>
                            <option value="">Semua mahasiswa sudah terdaftar</option>
                        <?php else: ?>
                            <option value="">-- Pilih Mahasiswa --</option>
                            <?php foreach ($availableStudents as $s): ?>
                                <option value="<?= $s['id'] ?>">
                                    <?= esc($s['name']) ?> (<?= esc($s['nim_nip'] ?? $s['email']) ?>)
                                </option>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </select>
                </div>
                <button type="submit" class="btn btn-green-official w-100" <?= empty($availableStudents) ? 'disabled' : '' ?>>
                    <i class="bi bi-check-lg me-1"></i> Daftarkan ke Kelas
                </button>
            </form>
        </div>
    </div>

    <!-- Tabel Daftar Mahasiswa di Kelas Ini -->
    <div class="col-lg-8">
        <div class="card card-official">
            <div class="card-header-official py-3">
                <i class="bi bi-people text-success me-2"></i>Daftar Roster Mahasiswa Terdaftar
            </div>
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-muted small text-uppercase">
                        <tr>
                            <th class="ps-4">No</th>
                            <th>Nama Mahasiswa</th>
                            <th>NIM</th>
                            <th>Tanggal Terdaftar</th>
                            <th class="text-end pe-4">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($enrolledStudents)): ?>
                            <tr>
                                <td colspan="5" class="text-center py-5 text-muted">
                                    <i class="bi bi-person-x fs-2 d-block mb-2"></i>
                                    Belum ada mahasiswa yang didaftarkan ke kelas ini.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php $no = 1; foreach ($enrolledStudents as $item): ?>
                                <tr>
                                    <td class="ps-4 fw-semibold text-muted"><?= $no++ ?></td>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= esc($item['name']) ?></div>
                                        <div class="text-muted small"><?= esc($item['email']) ?></div>
                                    </td>
                                    <td><code><?= esc($item['nim_nip'] ?? '-') ?></code></td>
                                    <td class="small text-muted">
                                        <?= date('d M Y, H:i', strtotime($item['enrolled_at'])) ?>
                                    </td>
                                    <td class="text-end pe-4">
                                        <form action="<?= site_url('admin/classes/' . $class['id'] . '/remove/' . $item['student_id']) ?>" method="post" class="d-inline" onsubmit="return confirm('Keluarkan mahasiswa ini dari kelas?')">
                                            <?= csrf_field() ?>
                                            <button type="submit" class="btn btn-sm btn-outline-danger" title="Keluarkan dari kelas">
                                                <i class="bi bi-trash"></i> Hapus
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>
