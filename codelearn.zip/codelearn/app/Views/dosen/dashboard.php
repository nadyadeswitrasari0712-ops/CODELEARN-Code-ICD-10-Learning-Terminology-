<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-8">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-person-video3"></i> Dosen Koding & Terminologi RMIK</span>
            <span class="badge bg-success-subtle text-success border border-success-subtle">Aktif Mengajar</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            Dashboard Dosen Pengampu
        </h3>
        <p class="text-muted mb-0">
            Selamat datang kembali, <strong><?= esc($user['name']) ?></strong>. Kelola materi kurikulum, pantau hasil ujian mahasiswa, dan evaluasi simulasi rekam medis.
        </p>
    </div>
    <div class="col-md-4 text-md-end mt-3 mt-md-0">
        <span class="badge bg-success px-3 py-2 fs-6">
            <i class="bi bi-hospital me-1"></i> Standar Kurikulum ICD-10 WHO
        </span>
    </div>
</div>

<!-- Quick Navigation Cards across Phases 2 to 5 -->
<div class="row g-3 mb-4">
    <div class="col-sm-6 col-lg-3">
        <div class="card card-official h-100 p-3 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-muted small fw-bold text-uppercase">Fase 2: Materi</span>
                <i class="bi bi-journal-text fs-4 text-success"></i>
            </div>
            <h6 class="fw-bold text-dark mb-1">Modul & Kurikulum</h6>
            <p class="small text-muted mb-3">Atur modul bertingkat dan lampiran referensi.</p>
            <a href="<?= site_url('dosen/modules') ?>" class="btn btn-sm btn-outline-green mt-auto">
                Buka Modul <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card card-official h-100 p-3 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-muted small fw-bold text-uppercase">Fase 3: Asesmen</span>
                <i class="bi bi-card-checklist fs-4 text-success"></i>
            </div>
            <h6 class="fw-bold text-dark mb-1">Bank Soal & Kuis</h6>
            <p class="small text-muted mb-3">Soal pilihan ganda, benar/salah & isian kode ICD.</p>
            <a href="<?= site_url('dosen/questions') ?>" class="btn btn-sm btn-outline-green mt-auto">
                Bank Soal <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card card-official h-100 p-3 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-muted small fw-bold text-uppercase">Fase 4: Simulasi</span>
                <i class="bi bi-clipboard2-pulse fs-4 text-success"></i>
            </div>
            <h6 class="fw-bold text-dark mb-1">Resume Medis</h6>
            <p class="small text-muted mb-3">Studi kasus riil & koreksi override dosen.</p>
            <a href="<?= site_url('dosen/cases') ?>" class="btn btn-sm btn-outline-green mt-auto">
                Kelola Kasus <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>

    <div class="col-sm-6 col-lg-3">
        <div class="card card-official h-100 p-3 border-start border-4 border-success">
            <div class="d-flex justify-content-between align-items-center mb-2">
                <span class="text-muted small fw-bold text-uppercase">Fase 5: Analitik</span>
                <i class="bi bi-graph-up-arrow fs-4 text-success"></i>
            </div>
            <h6 class="fw-bold text-dark mb-1">Peta Kompetensi</h6>
            <p class="small text-muted mb-3">Radar penguasaan bab & deteksi siswa berisiko.</p>
            <a href="<?= site_url('dosen/analytics') ?>" class="btn btn-sm btn-outline-green mt-auto">
                Lihat Analitik <i class="bi bi-arrow-right"></i>
            </a>
        </div>
    </div>
</div>

<!-- Kelas yang Diampu Dosen -->
<div class="card card-official p-4 mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h5 class="fw-bold mb-0 text-dark"><i class="bi bi-collection text-success me-2"></i>Kelas Perkuliahan Aktif yang Anda Bina</h5>
        <span class="badge bg-success"><?= count($myClasses) ?> Kelas Terdaftar</span>
    </div>

    <div class="row g-3">
        <?php foreach ($myClasses as $c): ?>
            <div class="col-md-6">
                <div class="card h-100 border rounded-3 p-3 shadow-sm bg-light">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <span class="badge bg-light text-dark border"><?= esc($c['year_name'] ?? '2026/2027') ?></span>
                        <span class="badge bg-success-subtle text-success">
                            <i class="bi bi-people"></i> <?= esc($c['total_students']) ?> Mahasiswa
                        </span>
                    </div>
                    <h5 class="fw-bold text-dark mb-1"><?= esc($c['class_name']) ?></h5>
                    <p class="text-muted small mb-3"><?= esc($c['description'] ?? 'Kelas koding diagnosis dan terminologi medis.') ?></p>
                    
                    <div class="d-flex flex-wrap gap-2">
                        <a href="<?= site_url('dosen/quizzes') ?>" class="btn btn-sm btn-green-official">
                            <i class="bi bi-file-earmark-check me-1"></i> Paket Kuis Ujian
                        </a>
                        <a href="<?= site_url('dosen/cases') ?>" class="btn btn-sm btn-outline-green">
                            <i class="bi bi-clipboard2-pulse me-1"></i> Kasus Resume Medis
                        </a>
                        <a href="<?= site_url('dosen/analytics?class_id=' . $c['id']) ?>" class="btn btn-sm btn-outline-secondary">
                            <i class="bi bi-graph-up me-1"></i> Analisis Kelas
                        </a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>
<?= $this->endSection() ?>
