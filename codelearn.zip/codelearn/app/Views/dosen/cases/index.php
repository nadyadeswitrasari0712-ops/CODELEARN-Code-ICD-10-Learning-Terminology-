<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-file-earmark-medical"></i> Simulator Resume Medis</span>
            <span class="badge bg-light text-muted border">FR-30, FR-33</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-clipboard2-pulse text-success me-2"></i>Kelola Kasus Klinis Resume Medis
        </h3>
        <p class="text-muted mb-0">Rancang studi kasus rekam medis fiktif (anamnesis, PF, lab, terapi, dokter DPJP) dan tetapkan kunci koding bertingkat.</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <button type="button" class="btn btn-green-official" data-bs-toggle="modal" data-bs-target="#createCaseModal">
            <i class="bi bi-plus-lg me-1"></i> Buat Kasus Resume Medis Baru
        </button>
    </div>
</div>

<div class="row g-3">
    <?php if (empty($cases)): ?>
        <div class="col-12 text-center py-5 text-muted">
            Belum ada kasus klinis dibuat.
        </div>
    <?php else: ?>
        <?php foreach ($cases as $cs): ?>
            <div class="col-md-6">
                <div class="card card-official h-100">
                    <div class="card-header-official d-flex justify-content-between align-items-center">
                        <span class="badge bg-light text-dark border"><code><?= esc($cs['case_number']) ?></code></span>
                        <span class="badge bg-warning-subtle text-warning border border-warning-subtle text-capitalize">
                            Tingkat: <?= esc($cs['difficulty']) ?>
                        </span>
                    </div>
                    <div class="card-body">
                        <h5 class="fw-bold text-dark mb-2"><?= esc($cs['title']) ?></h5>
                        <div class="p-2 bg-light rounded-2 border mb-3 small">
                            <strong>Pasien:</strong> <?= esc($cs['patient_name']) ?> (<?= esc($cs['patient_age']) ?>, <?= esc($cs['patient_gender']) ?>) &middot; <?= esc($cs['admission_type']) ?>
                        </div>
                        <p class="text-muted small mb-3">
                            <strong>Keluhan Utama:</strong> <?= esc(substr($cs['chief_complaint'], 0, 120)) ?>...
                        </p>
                        <div class="d-flex justify-content-between align-items-center border-top pt-3">
                            <a href="<?= site_url('mahasiswa/cases/play/' . $cs['id']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                <i class="bi bi-box-arrow-up-right me-1"></i> Simulasi Mahasiswa
                            </a>
                            <a href="<?= site_url('dosen/cases/' . $cs['id'] . '/submissions') ?>" class="btn btn-sm btn-green-official">
                                <i class="bi bi-check2-circle me-1"></i> Tinjau Jawaban Mahasiswa
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<!-- Modal Buat Kasus Resume Medis -->
<div class="modal fade" id="createCaseModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form action="<?= site_url('dosen/cases') ?>" method="post" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Rancang Kasus Resume Medis Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Judul Kasus</label>
                        <input type="text" name="title" class="form-control" placeholder="Contoh: Apendisitis Akut dengan Perforasi Lokal" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">Nama Pasien Fiktif</label>
                        <input type="text" name="patient_name" class="form-control" placeholder="Ny. Sulastri" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">Umur & Gender</label>
                        <div class="input-group">
                            <input type="text" name="patient_age" class="form-control" placeholder="34 Thn" required>
                            <select name="patient_gender" class="form-select">
                                <option value="L">L</option>
                                <option value="P">P</option>
                            </select>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Keluhan Utama & Anamnesis</label>
                    <textarea name="chief_complaint" class="form-control" rows="2" placeholder="Nyeri perut kanan bawah mendadak disertai demam dan mual..." required></textarea>
                </div>

                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Pemeriksaan Fisik (Tanda Vital & Abdomen)</label>
                        <textarea name="physical_exam" class="form-control" rows="2" placeholder="TD 120/80, Nadi 96, Suhu 38.2 C. Rovsing sign (+), McBurney tenderness (+)..." required></textarea>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Pemeriksaan Penunjang (Lab & USG/Rontgen)</label>
                        <textarea name="diagnostic_tests" class="form-control" rows="2" placeholder="Leukosit 14.800/uL. USG Abdomen: gambaran tubular non-kompresibel diameter 9 mm..."></textarea>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Catatan Resume Dokter DPJP (Diagnosis Akhir Klinisi)</label>
                    <textarea name="attending_physician_notes" class="form-control" rows="2" placeholder="Diagnosis DPJP: Akut Apendisitis Perforata. Pro Laparotomy Appendectomy." required></textarea>
                </div>

                <div class="p-3 bg-light rounded-3 border mb-3">
                    <div class="fw-bold small text-success mb-2"><i class="bi bi-key-fill me-1"></i> Kunci Koding & Standar Penilaian:</div>
                    <div class="row g-2 mb-2">
                        <div class="col-md-8">
                            <label class="form-label small">Nama Diagnosis Utama</label>
                            <input type="text" name="primary_diagnosis_title" class="form-control" placeholder="Acute appendicitis with localized peritonitis" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small">Kode ICD-10 Kunci</label>
                            <input type="text" name="primary_icd_code" class="form-control" placeholder="K35.8" required>
                        </div>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Langkah Penelusuran Lead Term (Volume 3)</label>
                        <input type="text" name="lead_term_steps" class="form-control" placeholder="Appendicitis -> acute -> with peritonitis (localized) -> K35.8" required>
                    </div>
                    <div class="mb-2">
                        <label class="form-label small">Verifikasi Tabular List (Volume 1)</label>
                        <input type="text" name="tabular_check_steps" class="form-control" placeholder="Buka Bab XI kategori K35 (Acute appendicitis). Verifikasi inklusi dan eksklusi." required>
                    </div>
                    <div>
                        <label class="form-label small">Referensi Resmi</label>
                        <input type="text" name="reference_source" class="form-control" placeholder="WHO ICD-10 Volume 1 & 3." required>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-green-official">Simpan Kasus</button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
