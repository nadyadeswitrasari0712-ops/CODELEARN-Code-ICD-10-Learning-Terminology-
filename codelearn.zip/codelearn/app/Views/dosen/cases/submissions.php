<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="mb-4">
    <a href="<?= site_url('dosen/cases') ?>" class="btn btn-sm btn-outline-secondary mb-2">
        <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar Kasus
    </a>
    <div class="d-flex flex-wrap justify-content-between align-items-center">
        <div>
            <h3 class="fw-bold text-dark mb-1">
                <i class="bi bi-person-check text-success me-2"></i>Jawaban Mahasiswa: <?= esc($case['title']) ?>
            </h3>
            <div class="text-muted small">
                Nomor RM: <code><?= esc($case['case_number']) ?></code> &middot; Pasien: <?= esc($case['patient_name']) ?>
            </div>
        </div>
        <div class="mt-3 mt-md-0">
            <span class="badge bg-success px-3 py-2 fs-6">
                Total <?= count($submissions) ?> Pengiriman Masuk
            </span>
        </div>
    </div>
</div>

<div class="card card-official">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
                <tr>
                    <th class="ps-4">Mahasiswa</th>
                    <th>NIM</th>
                    <th>Waktu Submit</th>
                    <th>Skor Otomatis (Parsial)</th>
                    <th>Skor Final Dosen</th>
                    <th>Catatan Dosen</th>
                    <th class="text-end pe-4">Koreksi / Override</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($submissions)): ?>
                    <tr>
                        <td colspan="7" class="text-center py-5 text-muted">
                            Belum ada mahasiswa yang mengirimkan jawaban untuk kasus ini.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($submissions as $sub): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold text-dark"><?= esc($sub['student_name']) ?></div>
                                <div class="text-muted small"><?= esc($sub['email']) ?></div>
                            </td>
                            <td><code><?= esc($sub['nim_nip'] ?? '-') ?></code></td>
                            <td class="small text-muted"><?= date('d M Y, H:i', strtotime($sub['submitted_at'])) ?></td>
                            <td>
                                <span class="badge bg-light text-dark border fs-6"><?= esc($sub['total_score']) ?></span>
                            </td>
                            <td>
                                <span class="fw-bold text-success fs-5">
                                    <?= esc($sub['dosen_override_score'] !== null ? $sub['dosen_override_score'] : $sub['total_score']) ?>
                                </span>
                            </td>
                            <td class="small text-muted" style="max-width: 200px;">
                                <?= esc($sub['dosen_notes'] ?? 'Belum ada catatan') ?>
                            </td>
                            <td class="text-end pe-4">
                                <button type="button" class="btn btn-sm btn-outline-green" data-bs-toggle="modal" data-bs-target="#overrideModal<?= $sub['id'] ?>">
                                    <i class="bi bi-pencil-square me-1"></i> Nilai & Beri Catatan
                                </button>
                            </td>
                        </tr>

                        <!-- Modal Override Skor & Komentar -->
                        <div class="modal fade" id="overrideModal<?= $sub['id'] ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <form action="<?= site_url('dosen/cases/submissions/' . $sub['id'] . '/override') ?>" method="post" class="modal-content">
                                    <?= csrf_field() ?>
                                    <div class="modal-header">
                                        <h6 class="modal-title fw-bold">Evaluasi Dosen: <?= esc($sub['student_name']) ?></h6>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body text-start">
                                        <div class="p-2 bg-light rounded-2 border mb-3 small">
                                            Skor Mesin Otomatis: <strong><?= esc($sub['total_score']) ?></strong><br>
                                            - Diagnosis Primer: <?= esc($sub['primary_score']) ?> / 50<br>
                                            - Diagnosis Sekunder: <?= esc($sub['secondary_score']) ?> / 30<br>
                                            - Ketepatan Prosedur: <?= esc($sub['additional_score']) ?> / 20
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label small fw-semibold">Nilai Override Dosen (0 - 100)</label>
                                            <input type="number" step="0.5" min="0" max="100" name="override_score" class="form-control" value="<?= esc($sub['dosen_override_score'] ?? $sub['total_score']) ?>" required>
                                        </div>
                                        <div class="mb-3">
                                            <label class="form-label small fw-semibold">Umpan Balik / Komentar Klinis untuk Mahasiswa</label>
                                            <textarea name="dosen_notes" class="form-control" rows="3" placeholder="Berikan catatan perbaikan terkait pemilihan lead term atau penelusuran tabular..."><?= esc($sub['dosen_notes'] ?? '') ?></textarea>
                                        </div>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                                        <button type="submit" class="btn btn-green-official btn-sm">Simpan Evaluasi</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
