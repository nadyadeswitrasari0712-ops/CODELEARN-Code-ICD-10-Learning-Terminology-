<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-card-checklist"></i> Bank Soal Terstandar</span>
            <span class="badge bg-light text-muted border">FR-20, FR-21</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-card-checklist text-success me-2"></i>Bank Soal Koding & Terminologi
        </h3>
        <p class="text-muted mb-0">Kelola butir soal pilihan ganda, benar/salah, dan isian kode diagnosis ICD-10 lengkap dengan pembahasan & referensi.</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <button type="button" class="btn btn-green-official" data-bs-toggle="modal" data-bs-target="#addQuestionModal">
            <i class="bi bi-plus-lg me-1"></i> Buat Butir Soal Baru
        </button>
    </div>
</div>

<!-- Question List -->
<div class="card card-official">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
                <tr>
                    <th class="ps-4">Teks Pertanyaan</th>
                    <th>Tipe Soal</th>
                    <th>Tingkat Kesulitan</th>
                    <th>Kunci / Kode Jawaban</th>
                    <th>Referensi Sumber</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($questions)): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5 text-muted">
                            Belum ada soal dibuat dalam bank soal.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($questions as $q): ?>
                        <tr>
                            <td class="ps-4 py-3" style="max-width: 380px;">
                                <div class="fw-semibold text-dark"><?= esc(strip_tags($q['question_text'])) ?></div>
                                <div class="text-muted small mt-1">
                                    <i class="bi bi-info-circle me-1"></i> Pembahasan: <?= esc(substr($q['explanation'], 0, 75)) ?>...
                                </div>
                            </td>
                            <td>
                                <span class="badge bg-light text-dark border">
                                    <?= esc(str_replace('_', ' ', ucfirst($q['type']))) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($q['difficulty'] === 'mudah'): ?>
                                    <span class="badge bg-success-subtle text-success">Mudah</span>
                                <?php elseif ($q['difficulty'] === 'sedang'): ?>
                                    <span class="badge bg-warning-subtle text-warning">Sedang</span>
                                <?php else: ?>
                                    <span class="badge bg-danger-subtle text-danger">Sulit</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($q['code_answer_key']): ?>
                                    <span class="icd-code-pill"><?= esc($q['code_answer_key']) ?></span>
                                <?php else: ?>
                                    <span class="badge bg-light text-secondary border">Lihat Opsi Kunci</span>
                                <?php endif; ?>
                            </td>
                            <td class="small text-muted" style="max-width: 200px;">
                                <?= esc($q['reference_source'] ?? 'WHO ICD-10') ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Tambah Butir Soal -->
<div class="modal fade" id="addQuestionModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form action="<?= site_url('dosen/questions') ?>" method="post" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Tambah Butir Soal Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Pilih Topik Materi</label>
                        <select name="topic_id" class="form-select">
                            <option value="">-- Umum / Tanpa Topik --</option>
                            <?php foreach ($topics as $tp): ?>
                                <option value="<?= $tp['id'] ?>"><?= esc($tp['title']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">Tipe Soal</label>
                        <select name="type" class="form-select" id="questionTypeSelect" onchange="toggleQuestionType()">
                            <option value="multiple_choice">Pilihan Ganda</option>
                            <option value="code_fill">Isian Kode ICD-10</option>
                            <option value="true_false">Benar / Salah</option>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">Tingkat Kesulitan</label>
                        <select name="difficulty" class="form-select">
                            <option value="mudah">Mudah</option>
                            <option value="sedang" selected>Sedang</option>
                            <option value="sulit">Sulit</option>
                        </select>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Teks Pertanyaan / Kasus Singkat</label>
                    <textarea name="question_text" class="form-control" rows="3" placeholder="Tuliskan pertanyaan di sini..." required></textarea>
                </div>

                <!-- Input Khusus Pilihan Ganda -->
                <div id="mcOptionsArea" class="p-3 bg-light rounded-3 border mb-3">
                    <label class="form-label small fw-bold text-success">Opsi Jawaban (Pilih satu sebagai kunci):</label>
                    <div class="input-group mb-2">
                        <div class="input-group-text">
                            <input class="form-check-input mt-0" type="radio" name="correct_option" value="0" checked>
                        </div>
                        <input type="text" name="options[]" class="form-control" placeholder="Pilihan A" value="">
                    </div>
                    <div class="input-group mb-2">
                        <div class="input-group-text">
                            <input class="form-check-input mt-0" type="radio" name="correct_option" value="1">
                        </div>
                        <input type="text" name="options[]" class="form-control" placeholder="Pilihan B" value="">
                    </div>
                    <div class="input-group mb-2">
                        <div class="input-group-text">
                            <input class="form-check-input mt-0" type="radio" name="correct_option" value="2">
                        </div>
                        <input type="text" name="options[]" class="form-control" placeholder="Pilihan C" value="">
                    </div>
                    <div class="input-group">
                        <div class="input-group-text">
                            <input class="form-check-input mt-0" type="radio" name="correct_option" value="3">
                        </div>
                        <input type="text" name="options[]" class="form-control" placeholder="Pilihan D" value="">
                    </div>
                </div>

                <!-- Input Khusus Isian Kode ICD -->
                <div id="codeFillArea" class="p-3 bg-light rounded-3 border mb-3" style="display: none;">
                    <label class="form-label small fw-bold text-success">Kode ICD-10 Kunci Jawaban:</label>
                    <input type="text" name="code_answer_key" class="form-control" placeholder="Contoh: I10 atau A09.0">
                    <div class="small text-muted mt-1">Sistem akan menormalisasi variasi titik, huruf kecil, dan spasi secara otomatis.</div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Pembahasan Alur Koding / Jawaban (FR-42)</label>
                    <textarea name="explanation" class="form-control" rows="2" placeholder="Jelaskan langkah pencarian lead term atau alasan ilmiah jawaban..." required></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Rujukan Sitasi Resmi (Buku Ajar / ICD-10 WHO)</label>
                    <input type="text" name="reference_source" class="form-control" placeholder="Contoh: WHO ICD-10 Volume 1 Bab IX, hal. 423" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-green-official">Simpan ke Bank Soal</button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    function toggleQuestionType() {
        const type = document.getElementById('questionTypeSelect').value;
        const mcArea = document.getElementById('mcOptionsArea');
        const codeArea = document.getElementById('codeFillArea');

        if (type === 'code_fill') {
            mcArea.style.display = 'none';
            codeArea.style.display = 'block';
        } else {
            mcArea.style.display = 'block';
            codeArea.style.display = 'none';
        }
    }
</script>
<?= $this->endSection() ?>
