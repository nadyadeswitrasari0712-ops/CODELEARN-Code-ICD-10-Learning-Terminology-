<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-person-video3"></i> Dosen Pengampu</span>
            <span class="badge bg-light text-muted border">FR-10, FR-12</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-journal-text text-success me-2"></i>Kelola Modul & Kurikulum Materi
        </h3>
        <p class="text-muted mb-0">Susun struktur materi bertingkat (*Modul > Topik > Subtopik*) untuk mahasiswa RMIK.</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <button type="button" class="btn btn-green-official" data-bs-toggle="modal" data-bs-target="#addModuleModal">
            <i class="bi bi-plus-lg me-1"></i> Tambah Modul Baru
        </button>
    </div>
</div>

<div class="row g-4">
    <?php foreach ($modules as $mod): ?>
        <div class="col-12">
            <div class="card card-official">
                <div class="card-header-official d-flex flex-wrap justify-content-between align-items-center gap-2">
                    <div class="d-flex align-items-center gap-2">
                        <i class="bi <?= esc($mod['icon']) ?> fs-4 text-success"></i>
                        <div>
                            <h5 class="fw-bold text-dark mb-0"><?= esc($mod['title']) ?></h5>
                            <small class="text-muted"><?= esc($mod['description']) ?></small>
                        </div>
                    </div>
                    <div>
                        <button class="btn btn-sm btn-outline-green" data-bs-toggle="modal" data-bs-target="#addTopicModal<?= $mod['id'] ?>">
                            <i class="bi bi-plus-circle me-1"></i> Tambah Topik
                        </button>
                    </div>
                </div>

                <div class="card-body p-0">
                    <div class="list-group list-group-flush">
                        <?php if (empty($mod['topics'])): ?>
                            <div class="p-4 text-center text-muted small">
                                Belum ada topik materi di dalam modul ini.
                            </div>
                        <?php else: ?>
                            <?php foreach ($mod['topics'] as $t): ?>
                                <div class="list-group-item d-flex justify-content-between align-items-center py-3 px-4">
                                    <div class="d-flex align-items-center gap-3">
                                        <span class="badge bg-light text-success border border-success fw-bold">
                                            Topik <?= esc($t['order_num']) ?>
                                        </span>
                                        <div>
                                            <div class="fw-semibold text-dark"><?= esc($t['title']) ?></div>
                                            <div class="text-muted small">
                                                <i class="bi bi-clock me-1"></i> Estimasi: <?= esc($t['estimated_minutes']) ?> Menit
                                            </div>
                                        </div>
                                    </div>
                                    <div>
                                        <a href="<?= site_url('mahasiswa/modules/read/' . $t['id']) ?>" target="_blank" class="btn btn-sm btn-outline-secondary">
                                            <i class="bi bi-eye"></i> Pratinjau
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Modal Tambah Topik -->
        <div class="modal fade" id="addTopicModal<?= $mod['id'] ?>" tabindex="-1">
            <div class="modal-dialog">
                <form action="<?= site_url('dosen/modules/' . $mod['id'] . '/topic') ?>" method="post" class="modal-content">
                    <?= csrf_field() ?>
                    <div class="modal-header">
                        <h6 class="modal-title fw-bold">Tambah Topik ke <?= esc($mod['title']) ?></h6>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Judul Topik Materi</label>
                            <input type="text" name="title" class="form-control" placeholder="Contoh: Aturan Reseleksi Diagnosis MB1-MB5" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small fw-semibold">Estimasi Waktu Belajar (Menit)</label>
                            <input type="number" name="estimated_minutes" class="form-control" value="20" required>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Batal</button>
                        <button type="submit" class="btn btn-green-official btn-sm">Simpan Topik</button>
                    </div>
                </form>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Modal Tambah Modul -->
<div class="modal fade" id="addModuleModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="<?= site_url('dosen/modules') ?>" method="post" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Tambah Modul Pembelajaran Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Judul Modul</label>
                    <input type="text" name="title" class="form-control" placeholder="Contoh: Koding Diagnosis Kasus Obstetri & Perinatal" required>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Deskripsi Singkat</label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Tujuan pembelajaran modul ini..."></textarea>
                </div>
                <div class="mb-3">
                    <label class="form-label small fw-semibold">Ikon Bootstrap</label>
                    <input type="text" name="icon" class="form-control" value="bi-journal-medical">
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-green-official">Simpan Modul</button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
