<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-graph-up-arrow"></i> Analitik Kelas Akademik</span>
            <span class="badge bg-light text-muted border">FR-50, FR-52, FR-54</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-pie-chart text-success me-2"></i>Peta Kompetensi & Pemantauan Kelas
        </h3>
        <p class="text-muted mb-0">Visualisasi radar penguasaan bab ICD-10, identifikasi topik lemah, dan deteksi mahasiswa berisiko (*at-risk students*).</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0 d-flex flex-wrap justify-content-md-end gap-2">
        <form method="get" action="<?= site_url('dosen/analytics') ?>" class="d-inline-flex gap-2">
            <select name="class_id" class="form-select form-select-sm" onchange="this.form.submit()">
                <?php foreach ($myClasses as $mc): ?>
                    <option value="<?= $mc['id'] ?>" <?= ($selectedClassId == $mc['id']) ? 'selected' : '' ?>>
                        Kelas: <?= esc($mc['class_name']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </form>
        <a href="<?= site_url('dosen/analytics/export/' . $selectedClassId) ?>" class="btn btn-sm btn-outline-success">
            <i class="bi bi-file-earmark-spreadsheet me-1"></i> Ekspor CSV
        </a>
    </div>
</div>

<div class="row g-4 mb-4">
    <!-- Radar Chart Visualisasi Penguasaan Bab ICD-10 -->
    <div class="col-lg-6">
        <div class="card card-official h-100 p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0 text-dark"><i class="bi bi-radar text-success me-2"></i>Radar Penguasaan Bab ICD-10</h5>
                <span class="badge bg-success-subtle text-success">Standar ≥ 75.0</span>
            </div>
            <div class="position-relative" style="height: 320px;">
                <canvas id="competencyRadarChart"></canvas>
            </div>
            <div class="text-center small text-muted mt-2">
                Grafik merefleksikan rata-rata akurasi koding mahasiswa per bab ICD-10 pada kelas ini.
            </div>
        </div>
    </div>

    <!-- Peringatan Mahasiswa Berisiko (FR-54) -->
    <div class="col-lg-6">
        <div class="card card-official h-100 p-4">
            <div class="d-flex justify-content-between align-items-center mb-3">
                <h5 class="fw-bold mb-0 text-danger"><i class="bi bi-exclamation-triangle-fill me-2"></i>Mahasiswa Butuh Pendampingan</h5>
                <span class="badge bg-danger-subtle text-danger border border-danger-subtle">Skor < 60%</span>
            </div>
            <p class="small text-muted mb-3">Daftar mahasiswa yang capaian kompetensi kodingnya di bawah ambang batas minimum dan berisiko saat pelaksanaan PKL.</p>

            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-light text-muted small text-uppercase">
                        <tr>
                            <th>Mahasiswa</th>
                            <th>Bab Bermasalah</th>
                            <th>Skor</th>
                            <th class="text-end">Tindakan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($atRiskStudents)): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4 text-success fw-semibold">
                                    <i class="bi bi-check-circle-fill me-1"></i> Tidak ada mahasiswa dalam kategori risiko tinggi pada kelas ini.
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($atRiskStudents as $ar): ?>
                                <tr>
                                    <td>
                                        <div class="fw-semibold text-dark"><?= esc($ar['name']) ?></div>
                                        <code class="small"><?= esc($ar['nim_nip'] ?? '-') ?></code>
                                    </td>
                                    <td>
                                        <span class="badge bg-light text-secondary border"><?= esc($ar['chapter_code']) ?></span>
                                    </td>
                                    <td>
                                        <span class="fw-bold text-danger"><?= esc($ar['score']) ?>%</span>
                                    </td>
                                    <td class="text-end">
                                        <a href="mailto:<?= esc($ar['email']) ?>" class="btn btn-sm btn-outline-danger">
                                            <i class="bi bi-envelope"></i> Intervensi
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Tabel Rincian Capaian Bab ICD-10 -->
<div class="card card-official p-4">
    <h5 class="fw-bold mb-3 text-dark"><i class="bi bi-table text-success me-2"></i>Tabel Capaian Nilai per Bab Klasifikasi</h5>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
                <tr>
                    <th class="ps-4">Kode Bab</th>
                    <th>Nama Klasifikasi Spesialisasi</th>
                    <th class="text-center">Rata-rata Skor</th>
                    <th class="text-center">Rentang (Min - Max)</th>
                    <th class="text-center">Status Bab</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($competencies)): ?>
                    <tr>
                        <td colspan="5" class="text-center py-4 text-muted">Belum ada data nilai kompetensi.</td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($competencies as $c): ?>
                        <tr>
                            <td class="ps-4">
                                <span class="badge bg-light text-dark border fw-bold"><?= esc($c['chapter_code']) ?></span>
                            </td>
                            <td>
                                <div class="fw-semibold text-dark"><?= esc($c['chapter_name']) ?></div>
                            </td>
                            <td class="text-center">
                                <span class="fs-6 fw-bold <?= ((float)$c['avg_score'] >= 75) ? 'text-success' : 'text-danger' ?>">
                                    <?= round((float)$c['avg_score'], 1) ?>%
                                </span>
                            </td>
                            <td class="text-center text-muted small">
                                <?= round((float)$c['min_score'], 1) ?>% &mdash; <?= round((float)$c['max_score'], 1) ?>%
                            </td>
                            <td class="text-center">
                                <?php if ((float)$c['avg_score'] >= 75): ?>
                                    <span class="badge bg-success-subtle text-success border border-success-subtle">Tercapai (Optimal)</span>
                                <?php else: ?>
                                    <span class="badge bg-warning-subtle text-warning border border-warning-subtle">Perlu Remedial</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>
    document.addEventListener("DOMContentLoaded", function() {
        const labels = <?= $radarLabels ?>;
        const data = <?= $radarScores ?>;

        const ctx = document.getElementById('competencyRadarChart').getContext('2d');
        new Chart(ctx, {
            type: 'radar',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Rata-rata Skor Kelas (%)',
                    data: data,
                    backgroundColor: 'rgba(5, 150, 105, 0.2)',
                    borderColor: '#059669',
                    pointBackgroundColor: '#047857',
                    pointBorderColor: '#fff',
                    pointHoverBackgroundColor: '#fff',
                    pointHoverBorderColor: '#047857'
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    r: {
                        angleLines: { color: 'rgba(0, 0, 0, 0.08)' },
                        suggestedMin: 0,
                        suggestedMax: 100,
                        ticks: { stepSize: 20 }
                    }
                }
            }
        });
    });
</script>
<?= $this->endSection() ?>
