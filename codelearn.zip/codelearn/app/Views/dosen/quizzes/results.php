<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="mb-4">
    <a href="<?= site_url('dosen/quizzes') ?>" class="btn btn-sm btn-outline-secondary mb-2">
        <i class="bi bi-arrow-left me-1"></i> Kembali ke Daftar Kuis
    </a>
    <div class="d-flex flex-wrap justify-content-between align-items-center">
        <div>
            <h3 class="fw-bold text-dark mb-1">
                <i class="bi bi-bar-chart-line text-success me-2"></i>Rekap Nilai: <?= esc($quiz['title']) ?>
            </h3>
            <div class="text-muted small">
                Standar Kelulusan: ≥ <?= esc($quiz['passing_score']) ?> &middot; Durasi: <?= esc($quiz['duration_minutes']) ?> Menit
            </div>
        </div>
        <div class="mt-3 mt-md-0">
            <span class="badge bg-success px-3 py-2 fs-6">
                Total <?= count($attempts) ?> Mahasiswa Mengikuti
            </span>
        </div>
    </div>
</div>

<div class="card card-official">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
                <tr>
                    <th class="ps-4">Nama Mahasiswa</th>
                    <th>NIM</th>
                    <th>Percobaan Ke</th>
                    <th>Waktu Pengiriman</th>
                    <th>Skor Akhir</th>
                    <th>Status Kelulusan</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($attempts)): ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">
                            Belum ada mahasiswa yang menyelesaikan kuis ini.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($attempts as $att): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold text-dark"><?= esc($att['student_name']) ?></div>
                                <div class="text-muted small"><?= esc($att['email']) ?></div>
                            </td>
                            <td><code><?= esc($att['nim_nip'] ?? '-') ?></code></td>
                            <td>Percobaan #<?= esc($att['attempt_number']) ?></td>
                            <td class="small text-muted">
                                <?= $att['submitted_at'] ? date('d M Y, H:i', strtotime($att['submitted_at'])) : '-' ?>
                            </td>
                            <td>
                                <span class="fs-5 fw-bold <?= ($att['score'] >= $quiz['passing_score']) ? 'text-success' : 'text-danger' ?>">
                                    <?= esc($att['score']) ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($att['passed']): ?>
                                    <span class="badge bg-success-subtle text-success border border-success-subtle">
                                        <i class="bi bi-check-circle me-1"></i> LULUS
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-danger-subtle text-danger border border-danger-subtle">
                                        <i class="bi bi-x-circle me-1"></i> REMEDIAL
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
