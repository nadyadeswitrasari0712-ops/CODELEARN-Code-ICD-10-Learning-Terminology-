<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-file-earmark-check"></i> Ujian & Kuis Resmi</span>
            <span class="badge bg-light text-muted border">FR-23, FR-24</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-file-earmark-check text-success me-2"></i>Manajemen Paket Kuis & Ujian
        </h3>
        <p class="text-muted mb-0">Rakit paket latihan kuis dan ujian koding diagnosis dengan batas waktu, passing score, dan auto-grading.</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <button type="button" class="btn btn-green-official" data-bs-toggle="modal" data-bs-target="#createQuizModal">
            <i class="bi bi-plus-lg me-1"></i> Buat Paket Kuis Baru
        </button>
    </div>
</div>

<div class="card card-official">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
                <tr>
                    <th class="ps-4">Judul Kuis</th>
                    <th>Kelas</th>
                    <th>Durasi</th>
                    <th>Standar Kelulusan</th>
                    <th>Total Soal</th>
                    <th class="text-end pe-4">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($quizzes)): ?>
                    <tr>
                        <td colspan="6" class="text-center py-5 text-muted">
                            Belum ada paket kuis dibuat untuk kelas Anda.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($quizzes as $qz): ?>
                        <tr>
                            <td class="ps-4">
                                <div class="fw-bold text-dark"><?= esc($qz['title']) ?></div>
                                <div class="text-muted small"><?= esc($qz['description'] ?? 'Tanpa deskripsi') ?></div>
                            </td>
                            <td>
                                <span class="badge bg-light text-secondary border"><?= esc($qz['class_name']) ?></span>
                            </td>
                            <td>
                                <span><i class="bi bi-clock me-1 text-muted"></i> <?= esc($qz['duration_minutes']) ?> Menit</span>
                            </td>
                            <td>
                                <span class="badge bg-success-subtle text-success">≥ <?= esc($qz['passing_score']) ?></span>
                            </td>
                            <td>
                                <span class="badge bg-primary-subtle text-primary fw-bold">
                                    <?= esc($qz['total_questions']) ?> Butir Soal
                                </span>
                            </td>
                            <td class="text-end pe-4">
                                <a href="<?= site_url('dosen/quizzes/' . $qz['id'] . '/results') ?>" class="btn btn-sm btn-outline-green">
                                    <i class="bi bi-bar-chart-line me-1"></i> Rekap Nilai
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Modal Buat Paket Kuis -->
<div class="modal fade" id="createQuizModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <form action="<?= site_url('dosen/quizzes') ?>" method="post" class="modal-content">
            <?= csrf_field() ?>
            <div class="modal-header">
                <h5 class="modal-title fw-bold">Rakit Paket Kuis Baru</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="row g-3 mb-3">
                    <div class="col-md-6">
                        <label class="form-label small fw-semibold">Pilih Kelas Perkuliahan</label>
                        <select name="class_id" class="form-select" required>
                            <?php foreach ($myClasses as $mc): ?>
                                <option value="<?= $mc['id'] ?>"><?= esc($mc['class_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">Durasi (Menit)</label>
                        <input type="number" name="duration_minutes" class="form-control" value="30" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label small fw-semibold">Ambang Kelulusan</label>
                        <input type="number" step="0.1" name="passing_score" class="form-control" value="70.0" required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Judul Paket Kuis</label>
                    <input type="text" name="title" class="form-control" placeholder="Contoh: Kuis Evaluasi Koding Bab I & IX" required>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-semibold">Deskripsi / Petunjuk Pengerjaan</label>
                    <textarea name="description" class="form-control" rows="2" placeholder="Petunjuk khusus untuk mahasiswa..."></textarea>
                </div>

                <div class="mb-3">
                    <label class="form-label small fw-bold text-success">Pilih Butir Soal dari Bank Soal:</label>
                    <div class="p-3 bg-light rounded-3 border" style="max-height: 250px; overflow-y: auto;">
                        <?php if (empty($allQuestions)): ?>
                            <div class="text-muted small">Belum ada butir soal di bank soal.</div>
                        <?php else: ?>
                            <?php foreach ($allQuestions as $aq): ?>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="checkbox" name="question_ids[]" value="<?= $aq['id'] ?>" id="chkQ<?= $aq['id'] ?>" checked>
                                    <label class="form-check-label small" for="chkQ<?= $aq['id'] ?>">
                                        <span class="badge bg-secondary-subtle text-secondary me-1"><?= ucfirst(esc($aq['type'])) ?></span>
                                        <?= esc(strip_tags($aq['question_text'])) ?>
                                    </label>
                                </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <button type="submit" class="btn btn-green-official">Terbitkan Kuis</button>
            </div>
        </form>
    </div>
</div>
<?= $this->endSection() ?>
