<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="row mb-4 align-items-center">
    <div class="col-md-7">
        <div class="d-flex align-items-center gap-2 mb-1">
            <span class="medical-seal"><i class="bi bi-patch-check-fill"></i> Standar WHO ICD-10 Resmi</span>
            <span class="badge bg-light text-muted border">FR-16</span>
        </div>
        <h3 class="fw-bold text-dark mb-1">
            <i class="bi bi-search text-success me-2"></i>Pencarian Kode Diagnosis ICD-10
        </h3>
        <p class="text-muted mb-0">Repositori kode diagnosis morbiditas dan mortalitas Volume 1 (Tabular List) & Volume 3 (Indeks Alfabetis).</p>
    </div>
    <div class="col-md-5 text-md-end mt-3 mt-md-0">
        <span class="badge bg-success px-3 py-2 fs-6">
            <i class="bi bi-database-check me-1"></i> <?= count($codes) ?> Kode Ditampilkan
        </span>
    </div>
</div>

<!-- Search & Chapter Filter -->
<div class="card card-official p-3 mb-4">
    <form method="get" action="<?= site_url('icd10') ?>" class="row g-2 align-items-center">
        <div class="col-md-6">
            <div class="input-group">
                <span class="input-group-text bg-white text-success border-end-0"><i class="bi bi-search"></i></span>
                <input type="text" name="q" class="form-control border-start-0" placeholder="Cari kode atau diagnosis (misal: I10, A09, Infark, Demam, Asma)..." value="<?= esc($q ?? '') ?>">
            </div>
        </div>
        <div class="col-md-4">
            <select name="chapter" class="form-select">
                <option value="">-- Semua Bab ICD-10 --</option>
                <?php foreach ($chapters as $chap): ?>
                    <option value="<?= $chap['chapter_no'] ?>" <?= ($chapter === $chap['chapter_no']) ? 'selected' : '' ?>>
                        <?= esc($chap['chapter_no']) ?>: <?= esc($chap['chapter_title']) ?> (<?= $chap['total_codes'] ?> kode)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="col-md-2">
            <button type="submit" class="btn btn-green-official w-100">
                <i class="bi bi-funnel"></i> Filter
            </button>
        </div>
    </form>
</div>

<!-- ICD Table List -->
<div class="card card-official">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light text-muted small text-uppercase">
                <tr>
                    <th class="ps-4">Kode ICD-10</th>
                    <th>Deskripsi Klinis (Inggris & Indonesia)</th>
                    <th>Bab Klasifikasi</th>
                    <th>Rentang Blok</th>
                    <th class="text-center">Status Koding</th>
                </tr>
            </thead>
            <tbody>
                <?php if (empty($codes)): ?>
                    <tr>
                        <td colspan="5" class="text-center py-5 text-muted">
                            <i class="bi bi-search text-muted fs-1 d-block mb-2"></i>
                            Tidak ada kode diagnosis yang cocok dengan pencarian Anda.
                        </td>
                    </tr>
                <?php else: ?>
                    <?php foreach ($codes as $c): ?>
                        <tr>
                            <td class="ps-4">
                                <span class="icd-code-pill fs-6"><?= esc($c['code']) ?></span>
                            </td>
                            <td>
                                <div class="fw-semibold text-dark"><?= esc($c['description']) ?></div>
                            </td>
                            <td>
                                <span class="badge bg-light text-secondary border">
                                    Bab <?= esc($c['chapter_no']) ?>: <?= esc($c['chapter_title']) ?>
                                </span>
                            </td>
                            <td>
                                <code><?= esc($c['block_range'] ?? '-') ?></code>
                            </td>
                            <td class="text-center">
                                <?php if ($c['valid_for_coding']): ?>
                                    <span class="badge bg-success-subtle text-success border border-success-subtle">
                                        <i class="bi bi-check-circle me-1"></i> Valid Koding
                                    </span>
                                <?php else: ?>
                                    <span class="badge bg-warning-subtle text-warning border border-warning-subtle">
                                        Perlu Karakter Ke-4
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?= $this->endSection() ?>
