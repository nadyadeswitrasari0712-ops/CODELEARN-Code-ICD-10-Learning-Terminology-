<?php

namespace App\Models;

use CodeIgniter\Model;

class QuizAttemptModel extends Model
{
    protected $table            = 'quiz_attempts';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'quiz_id',
        'user_id',
        'attempt_number',
        'score',
        'passed',
        'status',
        'started_at',
        'submitted_at',
    ];

    public function getUserAttempts(int $quizId, int $userId)
    {
        return $this->where('quiz_id', $quizId)
            ->where('user_id', $userId)
            ->orderBy('attempt_number', 'DESC')
            ->findAll();
    }
}
