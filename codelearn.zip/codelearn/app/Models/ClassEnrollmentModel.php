<?php

namespace App\Models;

use CodeIgniter\Model;

class ClassEnrollmentModel extends Model
{
    protected $table            = 'class_enrollments';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'class_id',
        'student_id',
        'enrolled_at',
    ];

    public function getStudentsByClass(int $classId)
    {
        return $this->select('class_enrollments.*, users.name, users.nim_nip, users.email, users.status')
            ->join('users', 'users.id = class_enrollments.student_id')
            ->where('class_enrollments.class_id', $classId)
            ->orderBy('users.name', 'ASC')
            ->findAll();
    }

    public function getStudentClasses(int $studentId)
    {
        return $this->select('classes.*, academic_years.year_name, academic_years.semester, users.name as dosen_name')
            ->join('classes', 'classes.id = class_enrollments.class_id')
            ->join('academic_years', 'academic_years.id = classes.academic_year_id', 'left')
            ->join('users', 'users.id = classes.dosen_id', 'left')
            ->where('class_enrollments.student_id', $studentId)
            ->findAll();
    }
}
