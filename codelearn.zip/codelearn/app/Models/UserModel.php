<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'users';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $useSoftDeletes   = false;
    protected $protectFields    = true;
    protected $allowedFields    = [
        'nim_nip',
        'name',
        'email',
        'password_hash',
        'role',
        'status',
        'avatar',
    ];

    protected bool $allowEmptyInserts = false;

    // Dates
    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    // Validation
    protected $validationRules = [
        'name'  => 'required|min_length[3]|max_length[100]',
        'email' => 'required|valid_email|is_unique[users.email,id,{id}]',
        'role'  => 'required|in_list[admin,dosen,mahasiswa]',
    ];

    /**
     * Cari user berdasarkan Email atau NIM/NIP untuk kebutuhan Login
     */
    public function findByCredentials(string $identifier)
    {
        return $this->where('email', $identifier)
                    ->orWhere('nim_nip', $identifier)
                    ->first();
    }
}
