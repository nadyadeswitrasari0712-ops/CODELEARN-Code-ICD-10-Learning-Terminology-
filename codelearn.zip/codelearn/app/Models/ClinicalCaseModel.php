<?php

namespace App\Models;

use CodeIgniter\Model;

class ClinicalCaseModel extends Model
{
    protected $table            = 'clinical_cases';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'case_number',
        'title',
        'patient_name',
        'patient_age',
        'patient_gender',
        'admission_type',
        'chief_complaint',
        'history_illness',
        'physical_exam',
        'diagnostic_tests',
        'medical_therapy',
        'attending_physician_notes',
        'difficulty',
        'status',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';

    public function getCaseWithKey(int $id)
    {
        $case = $this->find($id);
        if ($case) {
            $keyModel = new CaseKeyModel();
            $case['key'] = $keyModel->where('case_id', $id)->first();
        }
        return $case;
    }
}
