<?php

namespace App\Models;

use CodeIgniter\Model;

class CaseSubmissionModel extends Model
{
    protected $table            = 'case_submissions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'case_id',
        'user_id',
        'total_score',
        'primary_score',
        'secondary_score',
        'additional_score',
        'dosen_override_score',
        'dosen_notes',
        'submitted_at',
    ];

    public function getSubmissionsWithStudent(int $caseId)
    {
        return $this->select('case_submissions.*, users.name as student_name, users.nim_nip, users.email')
            ->join('users', 'users.id = case_submissions.user_id')
            ->where('case_submissions.case_id', $caseId)
            ->orderBy('case_submissions.submitted_at', 'DESC')
            ->findAll();
    }
}
