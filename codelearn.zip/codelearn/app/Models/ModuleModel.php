<?php

namespace App\Models;

use CodeIgniter\Model;

class ModuleModel extends Model
{
    protected $table            = 'modules';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'title',
        'description',
        'icon',
        'order_num',
        'is_published',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';

    public function getModulesWithTopics()
    {
        $modules = $this->where('is_published', 1)->orderBy('order_num', 'ASC')->findAll();
        $topicModel = new TopicModel();

        foreach ($modules as &$mod) {
            $mod['topics'] = $topicModel->where('module_id', $mod['id'])->orderBy('order_num', 'ASC')->findAll();
        }

        return $modules;
    }
}
