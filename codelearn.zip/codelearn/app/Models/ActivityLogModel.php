<?php

namespace App\Models;

use CodeIgniter\Model;

class ActivityLogModel extends Model
{
    protected $table            = 'activity_logs';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'user_id',
        'action',
        'module',
        'detail',
        'ip_address',
        'user_agent',
        'created_at',
    ];

    public function logActivity(?int $userId, string $action, string $module, ?string $detail = null)
    {
        $request = service('request');
        $ip = method_exists($request, 'getIPAddress') ? $request->getIPAddress() : '127.0.0.1';
        $ua = method_exists($request, 'getUserAgent') ? (string) $request->getUserAgent() : 'CLI / System';

        return $this->insert([
            'user_id'    => $userId,
            'action'     => $action,
            'module'     => $module,
            'detail'     => $detail,
            'ip_address' => $ip,
            'user_agent' => $ua,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function getRecentLogs(int $limit = 20)
    {
        return $this->select('activity_logs.*, users.name as user_name, users.role as user_role')
            ->join('users', 'users.id = activity_logs.user_id', 'left')
            ->orderBy('activity_logs.created_at', 'DESC')
            ->limit($limit)
            ->findAll();
    }
}
