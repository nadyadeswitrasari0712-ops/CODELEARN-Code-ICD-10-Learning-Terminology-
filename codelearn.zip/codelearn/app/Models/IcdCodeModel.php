<?php

namespace App\Models;

use CodeIgniter\Model;

class IcdCodeModel extends Model
{
    protected $table            = 'icd10_codes';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'code',
        'description',
        'chapter_no',
        'chapter_title',
        'block_range',
        'volume_type',
        'valid_for_coding',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';

    public function searchCodes(?string $query = null, ?string $chapter = null, int $limit = 50)
    {
        $builder = $this;

        if ($query) {
            $builder = $builder->groupStart()
                ->like('code', $query)
                ->orLike('description', $query)
                ->groupEnd();
        }

        if ($chapter) {
            $builder = $builder->where('chapter_no', $chapter);
        }

        return $builder->orderBy('code', 'ASC')->limit($limit)->findAll();
    }
}
