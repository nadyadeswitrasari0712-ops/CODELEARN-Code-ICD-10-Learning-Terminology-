<?php

namespace App\Models;

use CodeIgniter\Model;

class CaseKeyModel extends Model
{
    protected $table            = 'case_keys';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'case_id',
        'primary_diagnosis_title',
        'primary_icd_code',
        'primary_alternatives',
        'secondary_codes',
        'additional_codes',
        'lead_term_steps',
        'tabular_check_steps',
        'inclusion_exclusion_notes',
        'reference_source',
    ];
}
