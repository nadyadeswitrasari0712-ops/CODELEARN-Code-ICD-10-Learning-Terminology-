<?php

namespace App\Models;

use CodeIgniter\Model;

class AnnouncementModel extends Model
{
    protected $table            = 'announcements';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'class_id',
        'author_id',
        'title',
        'content',
        'created_at',
    ];

    public function getAnnouncementsByClass(?int $classId = null)
    {
        $builder = $this->select('announcements.*, users.name as author_name')
            ->join('users', 'users.id = announcements.author_id')
            ->orderBy('announcements.created_at', 'DESC');

        if ($classId) {
            $builder->groupStart()
                ->where('announcements.class_id', $classId)
                ->orWhere('announcements.class_id', null)
                ->groupEnd();
        }

        return $builder->findAll();
    }
}
