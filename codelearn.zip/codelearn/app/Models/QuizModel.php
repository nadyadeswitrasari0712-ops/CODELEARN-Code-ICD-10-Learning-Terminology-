<?php

namespace App\Models;

use CodeIgniter\Model;

class QuizModel extends Model
{
    protected $table            = 'quizzes';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'class_id',
        'title',
        'description',
        'duration_minutes',
        'passing_score',
        'max_attempts',
        'is_randomized',
        'is_published',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';

    public function getQuizWithQuestions(int $quizId)
    {
        $quiz = $this->find($quizId);
        if (! $quiz) {
            return null;
        }

        $db = \Config\Database::connect();
        $builder = $db->table('quiz_questions')
            ->select('questions.*, quiz_questions.weight')
            ->join('questions', 'questions.id = quiz_questions.question_id')
            ->where('quiz_questions.quiz_id', $quizId);

        if ($quiz['is_randomized']) {
            $builder->orderBy('RAND()');
        }

        $questions = $builder->get()->getResultArray();
        $optModel = new QuestionOptionModel();

        foreach ($questions as &$q) {
            if ($q['type'] === 'multiple_choice') {
                $q['options'] = $optModel->where('question_id', $q['id'])->findAll();
            }
        }

        $quiz['questions'] = $questions;
        return $quiz;
    }
}
