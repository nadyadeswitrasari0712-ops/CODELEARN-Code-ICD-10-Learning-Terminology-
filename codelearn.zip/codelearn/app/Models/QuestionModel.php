<?php

namespace App\Models;

use CodeIgniter\Model;

class QuestionModel extends Model
{
    protected $table            = 'questions';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'topic_id',
        'type',
        'difficulty',
        'question_text',
        'code_answer_key',
        'alternative_codes',
        'explanation',
        'reference_source',
        'created_by',
        'status',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';

    public function getQuestionWithOptions(int $id)
    {
        $question = $this->find($id);
        if ($question) {
            $optModel = new QuestionOptionModel();
            $question['options'] = $optModel->where('question_id', $id)->findAll();
        }
        return $question;
    }
}
