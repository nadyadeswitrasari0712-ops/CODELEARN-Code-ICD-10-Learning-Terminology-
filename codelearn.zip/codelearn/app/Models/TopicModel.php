<?php

namespace App\Models;

use CodeIgniter\Model;

class TopicModel extends Model
{
    protected $table            = 'topics';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'module_id',
        'title',
        'estimated_minutes',
        'order_num',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
}
