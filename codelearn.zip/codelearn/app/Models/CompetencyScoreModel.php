<?php

namespace App\Models;

use CodeIgniter\Model;

class CompetencyScoreModel extends Model
{
    protected $table            = 'competency_scores';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'user_id',
        'chapter_code',
        'chapter_name',
        'score',
        'total_assessments',
        'updated_at',
    ];

    public function getUserCompetencies(int $userId)
    {
        return $this->where('user_id', $userId)->orderBy('chapter_code', 'ASC')->findAll();
    }

    public function getClassCompetencyOverview(int $classId)
    {
        return $this->select('competency_scores.chapter_code, competency_scores.chapter_name, AVG(competency_scores.score) as avg_score, MIN(competency_scores.score) as min_score, MAX(competency_scores.score) as max_score, COUNT(DISTINCT competency_scores.user_id) as student_count')
            ->join('class_enrollments', 'class_enrollments.student_id = competency_scores.user_id')
            ->where('class_enrollments.class_id', $classId)
            ->groupBy('competency_scores.chapter_code')
            ->orderBy('competency_scores.chapter_code', 'ASC')
            ->findAll();
    }
}
