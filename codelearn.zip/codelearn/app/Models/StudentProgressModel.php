<?php

namespace App\Models;

use CodeIgniter\Model;

class StudentProgressModel extends Model
{
    protected $table            = 'student_topic_progress';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'user_id',
        'topic_id',
        'is_completed',
        'completed_at',
    ];

    public function markCompleted(int $userId, int $topicId)
    {
        $existing = $this->where('user_id', $userId)->where('topic_id', $topicId)->first();
        if ($existing) {
            return $this->update($existing['id'], [
                'is_completed' => 1,
                'completed_at' => date('Y-m-d H:i:s'),
            ]);
        }

        return $this->insert([
            'user_id'      => $userId,
            'topic_id'     => $topicId,
            'is_completed' => 1,
            'completed_at' => date('Y-m-d H:i:s'),
        ]);
    }

    public function getUserCompletedTopicIds(int $userId): array
    {
        $rows = $this->where('user_id', $userId)->where('is_completed', 1)->findAll();
        return array_column($rows, 'topic_id');
    }
}
