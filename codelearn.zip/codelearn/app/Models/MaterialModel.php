<?php

namespace App\Models;

use CodeIgniter\Model;

class MaterialModel extends Model
{
    protected $table            = 'materials';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'topic_id',
        'content',
        'attachment_url',
        'reference_source',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
}
