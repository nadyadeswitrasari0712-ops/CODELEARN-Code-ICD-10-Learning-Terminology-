<?php

namespace App\Models;

use CodeIgniter\Model;

class MedicalTermModel extends Model
{
    protected $table            = 'medical_terms';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'term',
        'meaning',
        'root_word',
        'prefix',
        'suffix',
        'body_system',
        'example_sentence',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';

    public function searchTerms(?string $keyword = null, ?string $system = null)
    {
        $builder = $this;

        if ($keyword) {
            $builder = $builder->groupStart()
                ->like('term', $keyword)
                ->orLike('meaning', $keyword)
                ->orLike('root_word', $keyword)
                ->groupEnd();
        }

        if ($system) {
            $builder = $builder->where('body_system', $system);
        }

        return $builder->orderBy('term', 'ASC')->findAll();
    }
}
