<?php

namespace App\Models;

use CodeIgniter\Model;

class ClassModel extends Model
{
    protected $table            = 'classes';
    protected $primaryKey       = 'id';
    protected $useAutoIncrement = true;
    protected $returnType       = 'array';
    protected $protectFields    = true;
    protected $allowedFields    = [
        'academic_year_id',
        'dosen_id',
        'class_name',
        'description',
    ];

    protected $useTimestamps = true;
    protected $dateFormat    = 'datetime';
    protected $createdField  = 'created_at';
    protected $updatedField  = 'updated_at';

    public function getClassesWithDetails(?int $dosenId = null)
    {
        $builder = $this->select('classes.*, academic_years.year_name, academic_years.semester, users.name as dosen_name, users.email as dosen_email, COUNT(class_enrollments.id) as total_students')
            ->join('academic_years', 'academic_years.id = classes.academic_year_id', 'left')
            ->join('users', 'users.id = classes.dosen_id', 'left')
            ->join('class_enrollments', 'class_enrollments.class_id = classes.id', 'left')
            ->groupBy('classes.id');

        if ($dosenId !== null) {
            $builder->where('classes.dosen_id', $dosenId);
        }

        return $builder->findAll();
    }
}
