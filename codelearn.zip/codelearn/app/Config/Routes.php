<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */

// Root - halaman utama (login/register) tanpa redirect
$routes->get('/', 'HomeController::index');
$routes->post('/', 'AuthController::attemptLogin');   // form login POST ke /

// Authentication routes (alias - agar tidak 404 jika diakses langsung)
$routes->get('login', 'AuthController::login');
$routes->post('login', 'AuthController::attemptLogin');
$routes->get('logout', 'AuthController::logout');

// Register routes (public - untuk pendaftaran akun baru)
$routes->get('register', 'AuthController::register');
$routes->post('register', 'AuthController::attemptRegister');
$routes->post('register-action', 'AuthController::attemptRegister'); // alias dari /

// Kamus & ICD-10 Search (Protected for logged-in users)
$routes->group('', ['filter' => 'auth'], static function ($routes) {
    $routes->get('kamus', 'TermController::index');
    $routes->get('icd10', 'IcdController::index');
    $routes->get('api/icd/search', 'IcdController::searchApi');
});

// Admin Routes (Protected by auth and role:admin)
$routes->group('admin', ['filter' => ['auth', 'role:admin']], static function ($routes) {
    $routes->get('dashboard', 'Admin\DashboardController::index');
    
    // User Management (FR-01, FR-02, FR-03)
    $routes->get('users', 'Admin\UserController::index');
    $routes->post('users', 'Admin\UserController::store');
    $routes->post('users/(:num)/toggle', 'Admin\UserController::toggleStatus/$1');
    $routes->post('users/import-csv', 'Admin\UserController::importCsv');

    // Class Management (FR-04, FR-70)
    $routes->get('classes', 'Admin\ClassController::index');
    $routes->post('classes', 'Admin\ClassController::store');
    $routes->get('classes/(:num)', 'Admin\ClassController::detail/$1');
    $routes->post('classes/(:num)/enroll', 'Admin\ClassController::enrollStudent/$1');
    $routes->post('classes/(:num)/remove/(:num)', 'Admin\ClassController::removeStudent/$1/$2');
});

// Dosen Routes (Protected by auth and role:dosen)
$routes->group('dosen', ['filter' => ['auth', 'role:dosen']], static function ($routes) {
    $routes->get('dashboard', 'Dosen\DashboardController::index');

    // Modul & Topik Materi (Fase 2)
    $routes->get('modules', 'Dosen\ModuleController::index');
    $routes->post('modules', 'Dosen\ModuleController::store');
    $routes->post('modules/(:num)/topic', 'Dosen\ModuleController::storeTopic/$1');

    // Bank Soal (Fase 3)
    $routes->get('questions', 'Dosen\QuestionBankController::index');
    $routes->post('questions', 'Dosen\QuestionBankController::store');

    // Manajemen Kuis (Fase 3)
    $routes->get('quizzes', 'Dosen\QuizController::index');
    $routes->post('quizzes', 'Dosen\QuizController::store');
    $routes->get('quizzes/(:num)/results', 'Dosen\QuizController::results/$1');

    // Kasus Resume Medis (Fase 4)
    $routes->get('cases', 'Dosen\CaseController::index');
    $routes->post('cases', 'Dosen\CaseController::store');
    $routes->get('cases/(:num)/submissions', 'Dosen\CaseController::submissions/$1');
    $routes->post('cases/submissions/(:num)/override', 'Dosen\CaseController::overrideGrade/$1');

    // Peta Analitik & Rekap Nilai (Fase 5)
    $routes->get('analytics', 'Dosen\AnalyticsController::index');
    $routes->get('analytics/export/(:num)', 'Dosen\AnalyticsController::exportCsv/$1');
});

// Mahasiswa Routes (Protected by auth and role:mahasiswa)
$routes->group('mahasiswa', ['filter' => ['auth', 'role:mahasiswa']], static function ($routes) {
    $routes->get('dashboard', 'Mahasiswa\DashboardController::index');

    // Pembelajaran Mandiri (Fase 2)
    $routes->get('modules', 'Mahasiswa\LearningController::index');
    $routes->get('modules/read/(:num)', 'Mahasiswa\LearningController::readTopic/$1');
    $routes->post('modules/complete/(:num)', 'Mahasiswa\LearningController::markCompleted/$1');

    // Latihan & Ujian Kuis (Fase 3)
    $routes->get('quizzes', 'Mahasiswa\QuizRunnerController::index');
    $routes->get('quizzes/start/(:num)', 'Mahasiswa\QuizRunnerController::start/$1');
    $routes->post('quizzes/submit/(:num)', 'Mahasiswa\QuizRunnerController::submit/$1');
    $routes->get('quizzes/review/(:num)', 'Mahasiswa\QuizRunnerController::review/$1');

    // Simulasi Resume Medis Klinis (Fase 4)
    $routes->get('cases', 'Mahasiswa\SimulationController::index');
    $routes->get('cases/play/(:num)', 'Mahasiswa\SimulationController::play/$1');
    $routes->post('cases/submit/(:num)', 'Mahasiswa\SimulationController::submit/$1');
    $routes->get('cases/review/(:num)', 'Mahasiswa\SimulationController::review/$1');

    // Peta Kompetensi & Kesiapan PKL (Fase 5)
    $routes->get('competency', 'Mahasiswa\CompetencyController::index');
});
