<?php

namespace App\Controllers;

use App\Models\IcdCodeModel;

class IcdController extends BaseController
{
    public function index()
    {
        $icdModel = new IcdCodeModel();
        $q = trim((string) $this->request->getGet('q'));
        $chapter = trim((string) $this->request->getGet('chapter'));

        $codes = $icdModel->searchCodes($q ?: null, $chapter ?: null, 60);

        // Ambil daftar bab unik
        $db = \Config\Database::connect();
        $chapters = $db->table('icd10_codes')
            ->select('chapter_no, chapter_title, COUNT(id) as total_codes')
            ->groupBy('chapter_no, chapter_title')
            ->orderBy('id', 'ASC')
            ->get()->getResultArray();

        return view('icd/index', [
            'title'    => 'Pencarian Kode Diagnosis ICD-10 - KodeMedis Learn',
            'codes'    => $codes,
            'q'        => $q,
            'chapter'  => $chapter,
            'chapters' => $chapters,
            'user'     => session()->get('user'),
        ]);
    }

    public function searchApi()
    {
        $icdModel = new IcdCodeModel();
        $q = trim((string) $this->request->getGet('q'));

        if (empty($q)) {
            return $this->response->setJSON([]);
        }

        $codes = $icdModel->searchCodes($q, null, 15);
        return $this->response->setJSON($codes);
    }
}
