<?php

namespace App\Controllers\Dosen;

use App\Controllers\BaseController;
use App\Models\QuizModel;
use App\Models\QuizAttemptModel;
use App\Models\ClassModel;
use App\Models\QuestionModel;

class QuizController extends BaseController
{
    protected QuizModel $quizModel;
    protected QuizAttemptModel $attemptModel;
    protected ClassModel $classModel;
    protected QuestionModel $questionModel;

    public function __construct()
    {
        $this->quizModel     = new QuizModel();
        $this->attemptModel   = new QuizAttemptModel();
        $this->classModel     = new ClassModel();
        $this->questionModel = new QuestionModel();
        helper(['form', 'url']);
    }

    public function index()
    {
        $dosenId = session()->get('user')['id'];
        $myClasses = $this->classModel->where('dosen_id', $dosenId)->findAll();
        $classIds = array_column($myClasses, 'id');

        $quizzes = [];
        if (! empty($classIds)) {
            $quizzes = $this->quizModel->select('quizzes.*, classes.class_name, COUNT(quiz_questions.id) as total_questions')
                ->join('classes', 'classes.id = quizzes.class_id')
                ->join('quiz_questions', 'quiz_questions.quiz_id = quizzes.id', 'left')
                ->whereIn('quizzes.class_id', $classIds)
                ->groupBy('quizzes.id')
                ->orderBy('quizzes.id', 'DESC')
                ->findAll();
        }

        $allQuestions = $this->questionModel->findAll();

        return view('dosen/quizzes/index', [
            'title'        => 'Manajemen Kuis & Ujian - KodeMedis Learn',
            'quizzes'      => $quizzes,
            'myClasses'    => $myClasses,
            'allQuestions' => $allQuestions,
            'user'         => session()->get('user'),
        ]);
    }

    public function store()
    {
        $classId   = (int) $this->request->getPost('class_id');
        $title     = trim((string) $this->request->getPost('title'));
        $duration  = (int) $this->request->getPost('duration_minutes') ?: 30;
        $passScore = (float) $this->request->getPost('passing_score') ?: 70.0;
        $questionIds = $this->request->getPost('question_ids') ?? [];

        if (empty($title) || empty($classId)) {
            return redirect()->back()->with('error', 'Lengkapi judul dan kelas kuis.');
        }

        $quizId = $this->quizModel->insert([
            'class_id'         => $classId,
            'title'            => $title,
            'description'      => trim((string) $this->request->getPost('description')),
            'duration_minutes' => $duration,
            'passing_score'    => $passScore,
            'max_attempts'     => 3,
            'is_randomized'    => 1,
            'is_published'     => 1,
        ]);

        if (! empty($questionIds)) {
            $db = \Config\Database::connect();
            $weightPerQ = count($questionIds) > 0 ? (100.0 / count($questionIds)) : 10.0;
            foreach ($questionIds as $qId) {
                $db->table('quiz_questions')->insert([
                    'quiz_id'     => $quizId,
                    'question_id' => (int) $qId,
                    'weight'      => $weightPerQ,
                ]);
            }
        }

        return redirect()->to(site_url('dosen/quizzes'))->with('success', 'Paket kuis berhasil dibuat dan diterbitkan untuk kelas.');
    }

    public function results(int $quizId)
    {
        $quiz = $this->quizModel->find($quizId);
        if (! $quiz) {
            return redirect()->to(site_url('dosen/quizzes'))->with('error', 'Kuis tidak ditemukan.');
        }

        $attempts = $this->attemptModel->select('quiz_attempts.*, users.name as student_name, users.nim_nip, users.email')
            ->join('users', 'users.id = quiz_attempts.user_id')
            ->where('quiz_attempts.quiz_id', $quizId)
            ->orderBy('quiz_attempts.score', 'DESC')
            ->findAll();

        return view('dosen/quizzes/results', [
            'title'    => 'Hasil Nilai Kuis: ' . $quiz['title'] . ' - KodeMedis Learn',
            'quiz'     => $quiz,
            'attempts' => $attempts,
            'user'     => session()->get('user'),
        ]);
    }
}
