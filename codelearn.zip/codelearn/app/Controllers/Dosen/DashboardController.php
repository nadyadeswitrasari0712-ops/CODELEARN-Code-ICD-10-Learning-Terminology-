<?php

namespace App\Controllers\Dosen;

use App\Controllers\BaseController;
use App\Models\ClassModel;
use App\Models\ClassEnrollmentModel;

class DashboardController extends BaseController
{
    public function index()
    {
        $dosenId = session()->get('user')['id'];
        $classModel = new ClassModel();

        $myClasses = $classModel->getClassesWithDetails($dosenId);

        return view('dosen/dashboard', [
            'title'     => 'Dashboard Dosen - KodeMedis Learn',
            'user'      => session()->get('user'),
            'myClasses' => $myClasses,
        ]);
    }
}
