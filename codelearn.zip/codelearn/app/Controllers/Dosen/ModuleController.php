<?php

namespace App\Controllers\Dosen;

use App\Controllers\BaseController;
use App\Models\ModuleModel;
use App\Models\TopicModel;
use App\Models\MaterialModel;

class ModuleController extends BaseController
{
    protected ModuleModel $moduleModel;
    protected TopicModel $topicModel;
    protected MaterialModel $materialModel;

    public function __construct()
    {
        $this->moduleModel   = new ModuleModel();
        $this->topicModel    = new TopicModel();
        $this->materialModel = new MaterialModel();
        helper(['form', 'url']);
    }

    public function index()
    {
        $modules = $this->moduleModel->getModulesWithTopics();

        return view('dosen/modules/index', [
            'title'   => 'Kelola Modul Pembelajaran - KodeMedis Learn',
            'modules' => $modules,
            'user'    => session()->get('user'),
        ]);
    }

    public function store()
    {
        $title = trim((string) $this->request->getPost('title'));
        $desc  = trim((string) $this->request->getPost('description'));
        $icon  = trim((string) $this->request->getPost('icon')) ?: 'bi-journal-medical';

        if (empty($title)) {
            return redirect()->back()->with('error', 'Judul modul wajib diisi.');
        }

        $this->moduleModel->insert([
            'title'        => $title,
            'description'  => $desc,
            'icon'         => $icon,
            'order_num'    => 99,
            'is_published' => 1,
        ]);

        return redirect()->to(site_url('dosen/modules'))->with('success', 'Modul pembelajaran berhasil ditambahkan.');
    }

    public function storeTopic(int $moduleId)
    {
        $title = trim((string) $this->request->getPost('title'));
        $est   = (int) $this->request->getPost('estimated_minutes') ?: 15;

        if (empty($title)) {
            return redirect()->back()->with('error', 'Judul topik wajib diisi.');
        }

        $topicId = $this->topicModel->insert([
            'module_id'         => $moduleId,
            'title'             => $title,
            'estimated_minutes' => $est,
            'order_num'         => 99,
        ]);

        // Buat materi awal
        $this->materialModel->insert([
            'topic_id'         => $topicId,
            'content'          => '<p>Tuliskan materi pembelajaran terminologi dan koding klinis di sini...</p>',
            'reference_source' => 'WHO ICD-10 Pedoman Klasifikasi.',
        ]);

        return redirect()->to(site_url('dosen/modules'))->with('success', 'Topik materi berhasil ditambahkan ke modul.');
    }
}
