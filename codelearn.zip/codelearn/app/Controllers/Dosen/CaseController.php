<?php

namespace App\Controllers\Dosen;

use App\Controllers\BaseController;
use App\Models\ClinicalCaseModel;
use App\Models\CaseKeyModel;
use App\Models\CaseSubmissionModel;

class CaseController extends BaseController
{
    protected ClinicalCaseModel $caseModel;
    protected CaseKeyModel $keyModel;
    protected CaseSubmissionModel $submissionModel;

    public function __construct()
    {
        $this->caseModel       = new ClinicalCaseModel();
        $this->keyModel        = new CaseKeyModel();
        $this->submissionModel = new CaseSubmissionModel();
        helper(['form', 'url']);
    }

    public function index()
    {
        $cases = $this->caseModel->findAll();

        return view('dosen/cases/index', [
            'title' => 'Simulasi Kasus Klinis (Resume Medis) - KodeMedis Learn',
            'cases' => $cases,
            'user'  => session()->get('user'),
        ]);
    }

    public function store()
    {
        $title          = trim((string) $this->request->getPost('title'));
        $patientName    = trim((string) $this->request->getPost('patient_name'));
        $patientAge     = trim((string) $this->request->getPost('patient_age'));
        $patientGender  = (string) $this->request->getPost('patient_gender');
        $chiefComplaint = trim((string) $this->request->getPost('chief_complaint'));
        $history        = trim((string) $this->request->getPost('history_illness'));
        $pe             = trim((string) $this->request->getPost('physical_exam'));
        $diagnostic     = trim((string) $this->request->getPost('diagnostic_tests'));
        $therapy        = trim((string) $this->request->getPost('medical_therapy'));
        $docNotes       = trim((string) $this->request->getPost('attending_physician_notes'));
        $difficulty     = (string) $this->request->getPost('difficulty');

        $primaryTitle = trim((string) $this->request->getPost('primary_diagnosis_title'));
        $primaryCode  = trim((string) $this->request->getPost('primary_icd_code'));
        $leadSteps    = trim((string) $this->request->getPost('lead_term_steps'));
        $tabSteps     = trim((string) $this->request->getPost('tabular_check_steps'));
        $ref          = trim((string) $this->request->getPost('reference_source'));

        $caseNumber = 'RM-' . date('Y') . '-' . rand(1000, 9999);

        $caseId = $this->caseModel->insert([
            'case_number'               => $caseNumber,
            'title'                     => $title,
            'patient_name'              => $patientName,
            'patient_age'               => $patientAge,
            'patient_gender'            => $patientGender,
            'admission_type'            => 'Rawat Inap',
            'chief_complaint'           => $chiefComplaint,
            'history_illness'           => $history,
            'physical_exam'             => $pe,
            'diagnostic_tests'          => $diagnostic,
            'medical_therapy'           => $therapy,
            'attending_physician_notes' => $docNotes,
            'difficulty'                => $difficulty,
            'status'                    => 'terbit',
        ]);

        $this->keyModel->insert([
            'case_id'                 => $caseId,
            'primary_diagnosis_title' => $primaryTitle,
            'primary_icd_code'        => $primaryCode,
            'primary_alternatives'    => json_encode([$primaryCode, strtolower($primaryCode)]),
            'secondary_codes'         => json_encode([]),
            'lead_term_steps'         => $leadSteps,
            'tabular_check_steps'     => $tabSteps,
            'reference_source'        => $ref ?: 'WHO ICD-10 Pedoman Klasifikasi.',
        ]);

        return redirect()->to(site_url('dosen/cases'))->with('success', 'Kasus resume medis baru berhasil dibuat.');
    }

    public function submissions(int $caseId)
    {
        $case = $this->caseModel->find($caseId);
        if (! $case) {
            return redirect()->to(site_url('dosen/cases'))->with('error', 'Kasus tidak ditemukan.');
        }

        $submissions = $this->submissionModel->getSubmissionsWithStudent($caseId);

        return view('dosen/cases/submissions', [
            'title'       => 'Jawaban Mahasiswa: ' . $case['title'] . ' - KodeMedis Learn',
            'case'        => $case,
            'submissions' => $submissions,
            'user'        => session()->get('user'),
        ]);
    }

    public function overrideGrade(int $submissionId)
    {
        $overrideScore = (float) $this->request->getPost('override_score');
        $notes         = trim((string) $this->request->getPost('dosen_notes'));

        $this->submissionModel->update($submissionId, [
            'dosen_override_score' => $overrideScore,
            'dosen_notes'          => $notes,
        ]);

        return redirect()->back()->with('success', 'Nilai dan evaluasi dosen berhasil disimpan.');
    }
}
