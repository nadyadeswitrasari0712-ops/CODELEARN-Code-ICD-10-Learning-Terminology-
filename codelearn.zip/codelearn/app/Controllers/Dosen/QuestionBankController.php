<?php

namespace App\Controllers\Dosen;

use App\Controllers\BaseController;
use App\Models\QuestionModel;
use App\Models\QuestionOptionModel;
use App\Models\TopicModel;

class QuestionBankController extends BaseController
{
    protected QuestionModel $questionModel;
    protected QuestionOptionModel $optionModel;
    protected TopicModel $topicModel;

    public function __construct()
    {
        $this->questionModel = new QuestionModel();
        $this->optionModel   = new QuestionOptionModel();
        $this->topicModel    = new TopicModel();
        helper(['form', 'url']);
    }

    public function index()
    {
        $topicFilter = $this->request->getGet('topic_id');
        $typeFilter  = $this->request->getGet('type');

        $query = $this->questionModel->select('questions.*, topics.title as topic_title')
            ->join('topics', 'topics.id = questions.topic_id', 'left');

        if ($topicFilter) {
            $query->where('questions.topic_id', $topicFilter);
        }
        if ($typeFilter) {
            $query->where('questions.type', $typeFilter);
        }

        $questions = $query->orderBy('questions.id', 'DESC')->findAll();
        $topics    = $this->topicModel->findAll();

        return view('dosen/questions/index', [
            'title'       => 'Bank Soal Koding & Terminologi - KodeMedis Learn',
            'questions'   => $questions,
            'topics'      => $topics,
            'topicFilter' => $topicFilter,
            'typeFilter'  => $typeFilter,
            'user'        => session()->get('user'),
        ]);
    }

    public function store()
    {
        $topicId        = (int) $this->request->getPost('topic_id');
        $type           = (string) $this->request->getPost('type');
        $difficulty     = (string) $this->request->getPost('difficulty');
        $questionText   = trim((string) $this->request->getPost('question_text'));
        $explanation    = trim((string) $this->request->getPost('explanation'));
        $ref            = trim((string) $this->request->getPost('reference_source'));
        $codeKey        = trim((string) $this->request->getPost('code_answer_key'));

        $questionId = $this->questionModel->insert([
            'topic_id'         => $topicId ?: null,
            'type'             => $type,
            'difficulty'       => $difficulty,
            'question_text'    => $questionText,
            'code_answer_key'  => $codeKey ?: null,
            'explanation'      => $explanation,
            'reference_source' => $ref,
            'created_by'       => session()->get('user')['id'],
            'status'           => 'terbit',
        ]);

        if ($type === 'multiple_choice') {
            $options = $this->request->getPost('options') ?? [];
            $correctIdx = (int) $this->request->getPost('correct_option');

            foreach ($options as $idx => $optText) {
                if (! empty(trim($optText))) {
                    $this->optionModel->insert([
                        'question_id' => $questionId,
                        'option_text' => trim($optText),
                        'is_correct'  => ($idx === $correctIdx) ? 1 : 0,
                    ]);
                }
            }
        }

        return redirect()->to(site_url('dosen/questions'))->with('success', 'Butir soal baru berhasil ditambahkan ke bank soal.');
    }
}
