<?php

namespace App\Controllers\Dosen;

use App\Controllers\BaseController;
use App\Models\ClassModel;
use App\Models\CompetencyScoreModel;
use App\Models\QuizAttemptModel;
use App\Models\CaseSubmissionModel;

class AnalyticsController extends BaseController
{
    public function index()
    {
        $dosenId = session()->get('user')['id'];
        $classModel = new ClassModel();
        $compModel  = new CompetencyScoreModel();

        $myClasses = $classModel->where('dosen_id', $dosenId)->findAll();
        $selectedClassId = (int) ($this->request->getGet('class_id') ?: ($myClasses[0]['id'] ?? 0));

        $competencies = $compModel->getClassCompetencyOverview($selectedClassId);

        // Cari mahasiswa berisiko (skor rata-rata < 55)
        $db = \Config\Database::connect();
        $atRiskStudents = $db->table('competency_scores')
            ->select('users.name, users.nim_nip, users.email, competency_scores.chapter_code, competency_scores.chapter_name, competency_scores.score')
            ->join('users', 'users.id = competency_scores.user_id')
            ->join('class_enrollments', 'class_enrollments.student_id = users.id')
            ->where('class_enrollments.class_id', $selectedClassId)
            ->where('competency_scores.score <', 60.0)
            ->orderBy('competency_scores.score', 'ASC')
            ->get()->getResultArray();

        // Data untuk Radar Chart
        $radarLabels = [];
        $radarScores = [];
        foreach ($competencies as $c) {
            $radarLabels[] = $c['chapter_code'] . ' ' . substr($c['chapter_name'], 0, 15) . '...';
            $radarScores[] = round((float) $c['avg_score'], 1);
        }

        return view('dosen/analytics/index', [
            'title'           => 'Peta Kompetensi & Pemantauan Kelas - KodeMedis Learn',
            'myClasses'       => $myClasses,
            'selectedClassId' => $selectedClassId,
            'competencies'    => $competencies,
            'atRiskStudents'  => $atRiskStudents,
            'radarLabels'     => json_encode($radarLabels),
            'radarScores'     => json_encode($radarScores),
            'user'            => session()->get('user'),
        ]);
    }

    public function exportCsv(int $classId)
    {
        $compModel = new CompetencyScoreModel();
        $competencies = $compModel->getClassCompetencyOverview($classId);

        $filename = 'rekap_kompetensi_kelas_' . $classId . '_' . date('Ymd_His') . '.csv';

        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');

        $output = fopen('php://output', 'w');
        fputcsv($output, ['Bab ICD-10', 'Nama Bab / Spesialisasi', 'Rata-rata Skor (%)', 'Skor Minimum', 'Skor Maksimum', 'Jumlah Mahasiswa']);

        foreach ($competencies as $c) {
            fputcsv($output, [
                $c['chapter_code'],
                $c['chapter_name'],
                round((float) $c['avg_score'], 2),
                round((float) $c['min_score'], 2),
                round((float) $c['max_score'], 2),
                $c['student_count'],
            ]);
        }

        fclose($output);
        exit;
    }
}
