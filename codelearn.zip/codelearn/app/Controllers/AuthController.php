<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\ActivityLogModel;
use CodeIgniter\Controller;

class AuthController extends Controller
{
    protected UserModel $userModel;
    protected ActivityLogModel $logModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->logModel  = new ActivityLogModel();
        helper(['form', 'url']);
    }

    public function login()
    {
        // Jika sudah login, langsung alihkan ke dashboard masing-masing
        if (session()->get('isLoggedIn')) {
            return $this->redirectByRole(session()->get('user')['role']);
        }

        return view('auth/login', [
            'title' => 'Masuk - KodeMedis Learn',
        ]);
    }

    public function register()
    {
        // Jika sudah login, langsung alihkan ke dashboard
        if (session()->get('isLoggedIn')) {
            return $this->redirectByRole(session()->get('user')['role']);
        }

        return view('auth/login', [
            'title' => 'Daftar Akun Baru - KodeMedis Learn',
        ]);
    }

    public function attemptRegister()
    {
        // Jika sudah login, tolak
        if (session()->get('isLoggedIn')) {
            return $this->redirectByRole(session()->get('user')['role']);
        }

        $rules = [
            'name'             => 'required|min_length[3]|max_length[100]',
            'email'            => 'required|valid_email|is_unique[users.email]',
            'nim_nip'          => 'permit_empty|is_unique[users.nim_nip]',
            'role'             => 'required|in_list[mahasiswa,dosen]',
            'password'         => 'required|min_length[6]',
            'password_confirm' => 'required|matches[password]',
        ];

        $messages = [
            'email'            => ['is_unique' => 'Email tersebut sudah terdaftar. Silakan gunakan email lain.'],
            'nim_nip'          => ['is_unique' => 'NIM/NIP tersebut sudah terdaftar.'],
            'password_confirm' => ['matches'   => 'Konfirmasi kata sandi tidak cocok.'],
            'password'         => ['min_length' => 'Kata sandi minimal 6 karakter.'],
        ];

        if (! $this->validate($rules, $messages)) {
            return redirect()->back()->withInput()
                ->with('errors', $this->validator->getErrors());
        }

        $nimNip = trim((string) $this->request->getPost('nim_nip'));

        $this->userModel->insert([
            'name'          => trim((string) $this->request->getPost('name')),
            'email'         => strtolower(trim((string) $this->request->getPost('email'))),
            'nim_nip'       => $nimNip ?: null,
            'role'          => (string) $this->request->getPost('role'),
            'password_hash' => password_hash((string) $this->request->getPost('password'), PASSWORD_BCRYPT),
            'status'        => 'active',
        ]);

        $this->logModel->logActivity(
            0,
            'SELF_REGISTER',
            'AUTH',
            'Pendaftaran akun baru: ' . $this->request->getPost('name')
        );

        return redirect()->to(site_url('/'))
            ->with('success', 'Akun berhasil dibuat! Silakan masuk dengan email dan kata sandi Anda.');
    }

    public function attemptLogin()
    {
        $rules = [
            'identifier' => 'required',
            'password'   => 'required|min_length[6]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $identifier = trim((string) $this->request->getPost('identifier'));
        $password   = (string) $this->request->getPost('password');

        $user = $this->userModel->findByCredentials($identifier);

        if (! $user) {
            return redirect()->to(site_url('/'))->withInput()->with('error', 'Akun dengan Email atau NIM/NIP tersebut tidak ditemukan.');
        }

        if ($user['status'] !== 'active') {
            return redirect()->to(site_url('/'))->withInput()->with('error', 'Akun Anda sedang dinonaktifkan oleh administrator.');
        }

        if (! password_verify($password, $user['password_hash'])) {
            return redirect()->to(site_url('/'))->withInput()->with('error', 'Kata sandi yang Anda masukkan salah.');
        }

        // Set session
        $sessionData = [
            'isLoggedIn' => true,
            'user'       => [
                'id'      => (int) $user['id'],
                'nim_nip' => $user['nim_nip'],
                'name'    => $user['name'],
                'email'   => $user['email'],
                'role'    => $user['role'],
            ],
        ];
        session()->set($sessionData);

        // Catat ke log aktivitas
        $this->logModel->logActivity(
            (int) $user['id'],
            'LOGIN',
            'AUTH',
            'Pengguna berhasil masuk ke sistem.'
        );

        return $this->redirectByRole($user['role']);
    }

    public function logout()
    {
        $userId = session()->get('user')['id'] ?? null;
        if ($userId) {
            $this->logModel->logActivity(
                (int) $userId,
                'LOGOUT',
                'AUTH',
                'Pengguna keluar dari sistem.'
            );
        }

        session()->destroy();
        return redirect()->to(site_url('/'))->with('success', 'Anda telah berhasil keluar.');
    }

    protected function redirectByRole(string $role)
    {
        return match ($role) {
            'admin'     => redirect()->to(site_url('admin/dashboard')),
            'dosen'     => redirect()->to(site_url('dosen/dashboard')),
            'mahasiswa' => redirect()->to(site_url('mahasiswa/dashboard')),
            default     => redirect()->to(site_url('/')),
        };
    }
}
