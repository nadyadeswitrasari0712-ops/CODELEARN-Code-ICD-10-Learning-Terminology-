<?php

namespace App\Controllers;

use CodeIgniter\Controller;

class HomeController extends Controller
{
    public function index()
    {
        // If user is logged in, redirect to appropriate dashboard
        if (session()->get('isLoggedIn')) {
            $role = session()->get('user')['role'] ?? '';
            return $this->redirectByRole($role);
        }
        // Not logged in, show login view
        return view('auth/login', [
            'title' => 'Masuk - KodeMedis Learn',
        ]);
    }

    protected function redirectByRole(string $role)
    {
        return match ($role) {
            'admin'     => redirect()->to(site_url('admin/dashboard')),
            'dosen'     => redirect()->to(site_url('dosen/dashboard')),
            'mahasiswa' => redirect()->to(site_url('mahasiswa/dashboard')),
            default     => redirect()->to(site_url('login')),
        };
    }
}
?>
