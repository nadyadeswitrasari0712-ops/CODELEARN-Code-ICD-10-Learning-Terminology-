<?php

namespace App\Controllers\Mahasiswa;

use App\Controllers\BaseController;
use App\Models\ClassEnrollmentModel;

class DashboardController extends BaseController
{
    public function index()
    {
        $studentId = session()->get('user')['id'];
        $enrollModel = new ClassEnrollmentModel();

        $enrolledClasses = $enrollModel->getStudentClasses($studentId);

        return view('mahasiswa/dashboard', [
            'title'           => 'Dashboard Mahasiswa - KodeMedis Learn',
            'user'            => session()->get('user'),
            'enrolledClasses' => $enrolledClasses,
        ]);
    }
}
