<?php

namespace App\Controllers\Mahasiswa;

use App\Controllers\BaseController;
use App\Models\QuizModel;
use App\Models\QuizAttemptModel;
use App\Models\ClassEnrollmentModel;
use App\Services\GradingService;

class QuizRunnerController extends BaseController
{
    protected QuizModel $quizModel;
    protected QuizAttemptModel $attemptModel;
    protected ClassEnrollmentModel $enrollModel;
    protected GradingService $gradingService;

    public function __construct()
    {
        $this->quizModel      = new QuizModel();
        $this->attemptModel    = new QuizAttemptModel();
        $this->enrollModel    = new ClassEnrollmentModel();
        $this->gradingService = new GradingService();
        helper(['form', 'url']);
    }

    public function index()
    {
        $userId = session()->get('user')['id'];
        $myClasses = $this->enrollModel->getStudentClasses($userId);
        $classIds = array_column($myClasses, 'id');

        $quizzes = [];
        if (! empty($classIds)) {
            $quizzes = $this->quizModel->whereIn('class_id', $classIds)->where('is_published', 1)->findAll();
        }

        // Ambil riwayat pengerjaan terakhir per kuis
        foreach ($quizzes as &$q) {
            $q['last_attempt'] = $this->attemptModel->where('quiz_id', $q['id'])
                ->where('user_id', $userId)
                ->orderBy('id', 'DESC')
                ->first();
        }

        return view('mahasiswa/quizzes/index', [
            'title'   => 'Latihan & Kuis Evaluasi - KodeMedis Learn',
            'quizzes' => $quizzes,
            'user'    => session()->get('user'),
        ]);
    }

    public function start(int $quizId)
    {
        $userId = session()->get('user')['id'];
        $quiz = $this->quizModel->getQuizWithQuestions($quizId);

        if (! $quiz) {
            return redirect()->to(site_url('mahasiswa/quizzes'))->with('error', 'Kuis tidak ditemukan.');
        }

        // Cek jumlah percobaan
        $attempts = $this->attemptModel->getUserAttempts($quizId, $userId);
        $nextAttemptNo = count($attempts) + 1;
        if ($nextAttemptNo > $quiz['max_attempts']) {
            return redirect()->to(site_url('mahasiswa/quizzes'))->with('error', 'Anda telah mencapai batas maksimal percobaan untuk kuis ini.');
        }

        // Catat attempt baru
        $attemptId = $this->attemptModel->insert([
            'quiz_id'        => $quizId,
            'user_id'        => $userId,
            'attempt_number' => $nextAttemptNo,
            'score'          => 0,
            'passed'         => 0,
            'status'         => 'in_progress',
            'started_at'     => date('Y-m-d H:i:s'),
        ]);

        return view('mahasiswa/quizzes/take', [
            'title'     => 'Mengerjakan: ' . $quiz['title'] . ' - KodeMedis Learn',
            'quiz'      => $quiz,
            'attemptId' => $attemptId,
            'user'      => session()->get('user'),
        ]);
    }

    public function submit(int $attemptId)
    {
        $userId = session()->get('user')['id'];
        $attempt = $this->attemptModel->find($attemptId);

        if (! $attempt || $attempt['user_id'] != $userId) {
            return redirect()->to(site_url('mahasiswa/quizzes'))->with('error', 'Sesi ujian tidak valid.');
        }

        $quiz = $this->quizModel->getQuizWithQuestions($attempt['quiz_id']);
        $userAnswers = $this->request->getPost('answers') ?? [];

        $totalEarnedScore = 0.0;
        $db = \Config\Database::connect();

        foreach ($quiz['questions'] as $q) {
            $qId = $q['id'];
            $ans = trim((string) ($userAnswers[$qId] ?? ''));
            $isCorrect = 0;
            $earned = 0.0;
            $weight = (float) ($q['weight'] ?? 10.0);

            if ($q['type'] === 'multiple_choice' || $q['type'] === 'true_false') {
                // Cek opsi yang is_correct = 1
                $correctOpt = $db->table('question_options')
                    ->where('question_id', $qId)
                    ->where('is_correct', 1)
                    ->get()->getRowArray();

                if ($correctOpt && strcasecmp(trim($correctOpt['option_text']), $ans) === 0) {
                    $isCorrect = 1;
                    $earned = $weight;
                }
            } elseif ($q['type'] === 'code_fill') {
                if ($this->gradingService->checkCodeAnswer($ans, (string) $q['code_answer_key'], $q['alternative_codes'])) {
                    $isCorrect = 1;
                    $earned = $weight;
                }
            }

            $totalEarnedScore += $earned;

            // Simpan rincian jawaban
            $db->table('quiz_attempt_answers')->insert([
                'attempt_id'   => $attemptId,
                'question_id'  => $qId,
                'user_answer'  => $ans,
                'is_correct'   => $isCorrect,
                'score_earned' => $earned,
            ]);
        }

        $passed = ($totalEarnedScore >= $quiz['passing_score']) ? 1 : 0;

        $this->attemptModel->update($attemptId, [
            'score'        => $totalEarnedScore,
            'passed'       => $passed,
            'status'       => 'completed',
            'submitted_at' => date('Y-m-d H:i:s'),
        ]);

        return redirect()->to(site_url('mahasiswa/quizzes/review/' . $attemptId))->with('success', 'Ujian selesai! Nilai dan pembahasan otomatis telah tersedia.');
    }

    public function review(int $attemptId)
    {
        $userId = session()->get('user')['id'];
        $attempt = $this->attemptModel->find($attemptId);

        if (! $attempt || $attempt['user_id'] != $userId) {
            return redirect()->to(site_url('mahasiswa/quizzes'))->with('error', 'Percobaan tidak ditemukan.');
        }

        $quiz = $this->quizModel->find($attempt['quiz_id']);
        $db = \Config\Database::connect();

        $answers = $db->table('quiz_attempt_answers')
            ->select('quiz_attempt_answers.*, questions.question_text, questions.type, questions.explanation, questions.reference_source, questions.code_answer_key')
            ->join('questions', 'questions.id = quiz_attempt_answers.question_id')
            ->where('quiz_attempt_answers.attempt_id', $attemptId)
            ->get()->getResultArray();

        return view('mahasiswa/quizzes/review', [
            'title'    => 'Hasil & Pembahasan: ' . $quiz['title'] . ' - KodeMedis Learn',
            'attempt'  => $attempt,
            'quiz'     => $quiz,
            'answers'  => $answers,
            'user'     => session()->get('user'),
        ]);
    }
}
