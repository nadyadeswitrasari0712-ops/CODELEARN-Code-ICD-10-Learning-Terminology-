<?php

namespace App\Controllers\Mahasiswa;

use App\Controllers\BaseController;
use App\Models\ModuleModel;
use App\Models\TopicModel;
use App\Models\MaterialModel;
use App\Models\StudentProgressModel;

class LearningController extends BaseController
{
    protected ModuleModel $moduleModel;
    protected TopicModel $topicModel;
    protected MaterialModel $materialModel;
    protected StudentProgressModel $progressModel;

    public function __construct()
    {
        $this->moduleModel   = new ModuleModel();
        $this->topicModel    = new TopicModel();
        $this->materialModel = new MaterialModel();
        $this->progressModel = new StudentProgressModel();
        helper(['url']);
    }

    public function index()
    {
        $userId = session()->get('user')['id'];
        $modules = $this->moduleModel->getModulesWithTopics();
        $completedTopicIds = $this->progressModel->getUserCompletedTopicIds($userId);

        // Hitung total topik & persentase penyelesaian
        $totalTopics = 0;
        foreach ($modules as $m) {
            $totalTopics += count($m['topics']);
        }
        $completedCount = count($completedTopicIds);
        $percent = $totalTopics > 0 ? round(($completedCount / $totalTopics) * 100) : 0;

        return view('mahasiswa/learning/index', [
            'title'             => 'Modul Pembelajaran Mandiri - KodeMedis Learn',
            'modules'           => $modules,
            'completedTopicIds' => $completedTopicIds,
            'totalTopics'       => $totalTopics,
            'completedCount'    => $completedCount,
            'percent'           => $percent,
            'user'              => session()->get('user'),
        ]);
    }

    public function readTopic(int $topicId)
    {
        $userId = session()->get('user')['id'];
        $topic = $this->topicModel->find($topicId);
        if (! $topic) {
            return redirect()->to(site_url('mahasiswa/modules'))->with('error', 'Topik materi tidak ditemukan.');
        }

        $material = $this->materialModel->where('topic_id', $topicId)->first();
        $module = $this->moduleModel->find($topic['module_id']);
        $isCompleted = in_array($topicId, $this->progressModel->getUserCompletedTopicIds($userId), true);

        // Topik selanjutnya dalam modul yang sama
        $nextTopic = $this->topicModel->where('module_id', $topic['module_id'])
            ->where('order_num >', $topic['order_num'])
            ->orderBy('order_num', 'ASC')
            ->first();

        return view('mahasiswa/learning/read', [
            'title'       => $topic['title'] . ' - KodeMedis Learn',
            'topic'       => $topic,
            'material'    => $material,
            'module'      => $module,
            'isCompleted' => $isCompleted,
            'nextTopic'   => $nextTopic,
            'user'        => session()->get('user'),
        ]);
    }

    public function markCompleted(int $topicId)
    {
        $userId = session()->get('user')['id'];
        $this->progressModel->markCompleted($userId, $topicId);

        return redirect()->back()->with('success', 'Selamat! Anda telah menyelesaikan topik materi ini.');
    }
}
