<?php

namespace App\Controllers\Mahasiswa;

use App\Controllers\BaseController;
use App\Models\ClinicalCaseModel;
use App\Models\CaseKeyModel;
use App\Models\CaseSubmissionModel;
use App\Services\CaseGradingService;

class SimulationController extends BaseController
{
    protected ClinicalCaseModel $caseModel;
    protected CaseKeyModel $keyModel;
    protected CaseSubmissionModel $submissionModel;
    protected CaseGradingService $gradingService;

    public function __construct()
    {
        $this->caseModel       = new ClinicalCaseModel();
        $this->keyModel        = new CaseKeyModel();
        $this->submissionModel = new CaseSubmissionModel();
        $this->gradingService  = new CaseGradingService();
        helper(['form', 'url']);
    }

    public function index()
    {
        $userId = session()->get('user')['id'];
        $cases  = $this->caseModel->where('status', 'terbit')->findAll();

        foreach ($cases as &$c) {
            $c['my_submission'] = $this->submissionModel->where('case_id', $c['id'])
                ->where('user_id', $userId)
                ->orderBy('id', 'DESC')
                ->first();
        }

        return view('mahasiswa/cases/index', [
            'title' => 'Simulasi Kasus Klinis (Resume Medis) - KodeMedis Learn',
            'cases' => $cases,
            'user'  => session()->get('user'),
        ]);
    }

    public function play(int $caseId)
    {
        $case = $this->caseModel->getCaseWithKey($caseId);
        if (! $case) {
            return redirect()->to(site_url('mahasiswa/cases'))->with('error', 'Kasus tidak ditemukan.');
        }

        return view('mahasiswa/cases/play', [
            'title' => 'Simulasi Kasus: ' . $case['title'] . ' - KodeMedis Learn',
            'case'  => $case,
            'user'  => session()->get('user'),
        ]);
    }

    public function submit(int $caseId)
    {
        $userId = session()->get('user')['id'];
        $case = $this->caseModel->getCaseWithKey($caseId);

        if (! $case || empty($case['key'])) {
            return redirect()->to(site_url('mahasiswa/cases'))->with('error', 'Data kasus tidak lengkap.');
        }

        $studentInput = [
            'primary_title' => trim((string) $this->request->getPost('primary_title')),
            'primary_icd'   => trim((string) $this->request->getPost('primary_icd')),
            'secondary_title' => trim((string) $this->request->getPost('secondary_title')),
            'secondary_icd' => trim((string) $this->request->getPost('secondary_icd')),
            'lead_term'     => trim((string) $this->request->getPost('lead_term')),
        ];

        // Jalankan Grading Engine Parsial
        $gradeResult = $this->gradingService->gradeCase($case['key'], $studentInput);

        $submissionId = $this->submissionModel->insert([
            'case_id'          => $caseId,
            'user_id'          => $userId,
            'total_score'      => $gradeResult['total_score'],
            'primary_score'    => $gradeResult['primary_score'],
            'secondary_score'  => $gradeResult['secondary_score'],
            'additional_score' => $gradeResult['additional_score'],
            'submitted_at'     => date('Y-m-d H:i:s'),
        ]);

        $db = \Config\Database::connect();
        // Simpan rincian kecocokan diagnosis primer
        $db->table('case_submission_details')->insert([
            'submission_id'        => $submissionId,
            'component_type'       => 'primary',
            'input_diagnosis_text' => $studentInput['primary_title'],
            'input_icd_code'       => $studentInput['primary_icd'],
            'match_level'          => $gradeResult['primary_eval']['match_level'],
            'earned_score'         => $gradeResult['primary_score'],
            'max_score'            => 50.00,
        ]);

        // Simpan rincian kecocokan diagnosis sekunder
        $db->table('case_submission_details')->insert([
            'submission_id'        => $submissionId,
            'component_type'       => 'secondary',
            'input_diagnosis_text' => $studentInput['secondary_title'],
            'input_icd_code'       => $studentInput['secondary_icd'],
            'match_level'          => $gradeResult['secondary_eval']['match_level'],
            'earned_score'         => $gradeResult['secondary_score'],
            'max_score'            => 30.00,
        ]);

        return redirect()->to(site_url('mahasiswa/cases/review/' . $submissionId))
            ->with('success', 'Jawaban berhasil dinilai otomatis! Simak langkah penelusuran koding.');
    }

    public function review(int $submissionId)
    {
        $userId = session()->get('user')['id'];
        $submission = $this->submissionModel->find($submissionId);

        if (! $submission || $submission['user_id'] != $userId) {
            return redirect()->to(site_url('mahasiswa/cases'))->with('error', 'Hasil simulasi tidak ditemukan.');
        }

        $case = $this->caseModel->getCaseWithKey($submission['case_id']);
        $db = \Config\Database::connect();
        $details = $db->table('case_submission_details')
            ->where('submission_id', $submissionId)
            ->get()->getResultArray();

        return view('mahasiswa/cases/review', [
            'title'      => 'Pembahasan Koding Resume Medis - KodeMedis Learn',
            'case'       => $case,
            'submission' => $submission,
            'details'    => $details,
            'user'       => session()->get('user'),
        ]);
    }
}
