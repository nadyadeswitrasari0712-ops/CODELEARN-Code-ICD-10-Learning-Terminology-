<?php

namespace App\Controllers\Mahasiswa;

use App\Controllers\BaseController;
use App\Models\CompetencyScoreModel;
use App\Models\ModuleModel;

class CompetencyController extends BaseController
{
    public function index()
    {
        $userId = session()->get('user')['id'];
        $compModel = new CompetencyScoreModel();
        $moduleModel = new ModuleModel();

        $scores = $compModel->getUserCompetencies($userId);

        // Hitung rata-rata akumulasi
        $total = 0;
        $count = count($scores);
        $radarLabels = [];
        $radarValues = [];
        $weakChapters = [];

        foreach ($scores as $s) {
            $total += (float) $s['score'];
            $radarLabels[] = $s['chapter_code'];
            $radarValues[] = (float) $s['score'];

            if ((float) $s['score'] < 70.0) {
                $weakChapters[] = $s;
            }
        }

        $overallAvg = $count > 0 ? round($total / $count, 1) : 0;

        // Kategori Kesiapan PKL sesuai PRD Bab 9
        $readiness = match (true) {
            $overallAvg >= 85 => ['status' => 'Mahir', 'class' => 'success', 'desc' => 'Sangat siap menjalani Praktik Kerja Lapangan (PKL) di fasilitas pelayanan kesehatan.'],
            $overallAvg >= 70 => ['status' => 'Cakap', 'class' => 'info', 'desc' => 'Siap melaksanakan koding klinis dengan supervisi umum.'],
            $overallAvg >= 55 => ['status' => 'Berkembang', 'class' => 'warning', 'desc' => 'Perlu memperbanyak latihan kasus sebelum penempatan PKL.'],
            default           => ['status' => 'Perlu Pendampingan', 'class' => 'danger', 'desc' => 'Wajib mengikuti program tutorial dan penguatan konsep dasar koding.'],
        };

        // Modul rekomendasi
        $recommendedModules = $moduleModel->where('is_published', 1)->findAll(3);

        return view('mahasiswa/competency/index', [
            'title'              => 'Peta Kompetensi & Kesiapan PKL - KodeMedis Learn',
            'scores'             => $scores,
            'overallAvg'         => $overallAvg,
            'readiness'          => $readiness,
            'radarLabels'        => json_encode($radarLabels),
            'radarValues'        => json_encode($radarValues),
            'weakChapters'       => $weakChapters,
            'recommendedModules' => $recommendedModules,
            'user'               => session()->get('user'),
        ]);
    }
}
