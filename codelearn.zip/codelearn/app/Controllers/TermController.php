<?php

namespace App\Controllers;

use App\Models\MedicalTermModel;

class TermController extends BaseController
{
    public function index()
    {
        $termModel = new MedicalTermModel();
        $q = trim((string) $this->request->getGet('q'));
        $system = trim((string) $this->request->getGet('system'));

        $terms = $termModel->searchTerms($q ?: null, $system ?: null);

        // Daftar sistem organ untuk filter
        $systems = ['Kardiovaskular', 'Pencernaan', 'Respirasi', 'Urogenital', 'Muskuloskeletal', 'Saraf'];

        return view('terms/index', [
            'title'   => 'Kamus Terminologi Medis - KodeMedis Learn',
            'terms'   => $terms,
            'q'       => $q,
            'system'  => $system,
            'systems' => $systems,
            'user'    => session()->get('user'),
        ]);
    }
}
