<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\ClassModel;
use App\Models\AcademicYearModel;
use App\Models\ActivityLogModel;

class DashboardController extends BaseController
{
    public function index()
    {
        $userModel = new UserModel();
        $classModel = new ClassModel();
        $logModel = new ActivityLogModel();
        $yearModel = new AcademicYearModel();

        $stats = [
            'total_students' => $userModel->where('role', 'mahasiswa')->countAllResults(),
            'total_lecturers' => $userModel->where('role', 'dosen')->countAllResults(),
            'total_classes' => $classModel->countAllResults(),
            'active_year' => $yearModel->getActiveYear(),
        ];

        $recentLogs = $logModel->getRecentLogs(10);

        return view('admin/dashboard', [
            'title'      => 'Dashboard Administrator - KodeMedis Learn',
            'stats'      => $stats,
            'recentLogs' => $recentLogs,
            'user'       => session()->get('user'),
        ]);
    }
}
