<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\ActivityLogModel;

class UserController extends BaseController
{
    protected UserModel $userModel;
    protected ActivityLogModel $logModel;

    public function __construct()
    {
        $this->userModel = new UserModel();
        $this->logModel  = new ActivityLogModel();
        helper(['form', 'url']);
    }

    public function index()
    {
        $roleFilter = $this->request->getGet('role');
        $search = $this->request->getGet('q');

        $query = $this->userModel;

        if ($roleFilter && in_array($roleFilter, ['admin', 'dosen', 'mahasiswa'])) {
            $query = $query->where('role', $roleFilter);
        }

        if ($search) {
            $query = $query->groupStart()
                           ->like('name', $search)
                           ->orLike('email', $search)
                           ->orLike('nim_nip', $search)
                           ->groupEnd();
        }

        $users = $query->orderBy('role', 'ASC')->orderBy('name', 'ASC')->findAll();

        return view('admin/users/index', [
            'title'      => 'Manajemen Pengguna - KodeMedis Learn',
            'users'      => $users,
            'roleFilter' => $roleFilter,
            'search'     => $search,
            'user'       => session()->get('user'),
        ]);
    }

    public function store()
    {
        $rules = [
            'name'     => 'required|min_length[3]|max_length[100]',
            'email'    => 'required|valid_email|is_unique[users.email]',
            'nim_nip'  => 'permit_empty|is_unique[users.nim_nip]',
            'role'     => 'required|in_list[admin,dosen,mahasiswa]',
            'password' => 'required|min_length[6]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->userModel->insert([
            'name'          => trim((string) $this->request->getPost('name')),
            'email'         => trim((string) $this->request->getPost('email')),
            'nim_nip'       => trim((string) $this->request->getPost('nim_nip')) ?: null,
            'role'          => (string) $this->request->getPost('role'),
            'password_hash' => password_hash((string) $this->request->getPost('password'), PASSWORD_BCRYPT),
            'status'        => 'active',
        ]);

        $this->logModel->logActivity(
            session()->get('user')['id'],
            'CREATE_USER',
            'USER_MGMT',
            'Menambahkan pengguna baru: ' . $this->request->getPost('name')
        );

        return redirect()->to(site_url('admin/users'))->with('success', 'Pengguna berhasil ditambahkan.');
    }

    public function toggleStatus(int $id)
    {
        $user = $this->userModel->find($id);
        if (! $user) {
            return redirect()->back()->with('error', 'Pengguna tidak ditemukan.');
        }

        // Jangan nonaktifkan akun sendiri
        if ($user['id'] == session()->get('user')['id']) {
            return redirect()->back()->with('error', 'Anda tidak dapat menonaktifkan akun Anda sendiri.');
        }

        $newStatus = ($user['status'] === 'active') ? 'inactive' : 'active';
        $this->userModel->update($id, ['status' => $newStatus]);

        $this->logModel->logActivity(
            session()->get('user')['id'],
            'TOGGLE_USER_STATUS',
            'USER_MGMT',
            "Mengubah status pengguna {$user['name']} menjadi {$newStatus}."
        );

        return redirect()->to(site_url('admin/users'))->with('success', "Status pengguna berhasil diperbarui menjadi {$newStatus}.");
    }

    public function importCsv()
    {
        $file = $this->request->getFile('csv_file');

        if (! $file || ! $file->isValid() || $file->getExtension() !== 'csv') {
            return redirect()->back()->with('error', 'Harap unggah berkas CSV yang valid.');
        }

        $handle = fopen($file->getTempName(), 'r');
        if ($handle === false) {
            return redirect()->back()->with('error', 'Gagal membaca berkas CSV.');
        }

        $header = fgetcsv($handle, 1000, ',');
        $importedCount = 0;
        $defaultPassword = password_hash('password123', PASSWORD_BCRYPT);

        while (($row = fgetcsv($handle, 1000, ',')) !== false) {
            // Expected columns: nim_nip, name, email, role
            if (count($row) >= 4) {
                $nimNip = trim($row[0]);
                $name   = trim($row[1]);
                $email  = trim($row[2]);
                $role   = strtolower(trim($row[3]));

                if (in_array($role, ['admin', 'dosen', 'mahasiswa']) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    // Cek jika email sudah terdaftar
                    $existing = $this->userModel->where('email', $email)->first();
                    if (! $existing) {
                        $this->userModel->insert([
                            'nim_nip'       => $nimNip ?: null,
                            'name'          => $name,
                            'email'         => $email,
                            'role'          => $role,
                            'password_hash' => $defaultPassword,
                            'status'        => 'active',
                        ]);
                        $importedCount++;
                    }
                }
            }
        }
        fclose($handle);

        $this->logModel->logActivity(
            session()->get('user')['id'],
            'IMPORT_CSV_USERS',
            'USER_MGMT',
            "Berhasil mengimpor {$importedCount} pengguna dari CSV."
        );

        return redirect()->to(site_url('admin/users'))->with('success', "Berhasil mengimpor {$importedCount} data pengguna.");
    }
}
