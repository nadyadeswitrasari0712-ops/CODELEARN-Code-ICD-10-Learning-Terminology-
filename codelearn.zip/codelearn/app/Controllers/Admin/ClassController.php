<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\ClassModel;
use App\Models\ClassEnrollmentModel;
use App\Models\UserModel;
use App\Models\AcademicYearModel;
use App\Models\ActivityLogModel;

class ClassController extends BaseController
{
    protected ClassModel $classModel;
    protected ClassEnrollmentModel $enrollModel;
    protected UserModel $userModel;
    protected AcademicYearModel $yearModel;
    protected ActivityLogModel $logModel;

    public function __construct()
    {
        $this->classModel  = new ClassModel();
        $this->enrollModel = new ClassEnrollmentModel();
        $this->userModel   = new UserModel();
        $this->yearModel   = new AcademicYearModel();
        $this->logModel    = new ActivityLogModel();
        helper(['form', 'url']);
    }

    public function index()
    {
        $classes = $this->classModel->getClassesWithDetails();
        $lecturers = $this->userModel->where('role', 'dosen')->where('status', 'active')->findAll();
        $academicYears = $this->yearModel->orderBy('id', 'DESC')->findAll();

        return view('admin/classes/index', [
            'title'         => 'Manajemen Kelas - KodeMedis Learn',
            'classes'       => $classes,
            'lecturers'     => $lecturers,
            'academicYears' => $academicYears,
            'user'          => session()->get('user'),
        ]);
    }

    public function store()
    {
        $rules = [
            'class_name'       => 'required|min_length[3]|max_length[50]',
            'academic_year_id' => 'required|is_not_unique[academic_years.id]',
            'dosen_id'         => 'required|is_not_unique[users.id]',
        ];

        if (! $this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $this->classModel->insert([
            'class_name'       => trim((string) $this->request->getPost('class_name')),
            'academic_year_id' => (int) $this->request->getPost('academic_year_id'),
            'dosen_id'         => (int) $this->request->getPost('dosen_id'),
            'description'      => trim((string) $this->request->getPost('description')),
        ]);

        $this->logModel->logActivity(
            session()->get('user')['id'],
            'CREATE_CLASS',
            'CLASS_MGMT',
            'Menambahkan kelas baru: ' . $this->request->getPost('class_name')
        );

        return redirect()->to(site_url('admin/classes'))->with('success', 'Kelas berhasil dibuat.');
    }

    public function detail(int $id)
    {
        $class = $this->classModel->select('classes.*, academic_years.year_name, academic_years.semester, users.name as dosen_name')
            ->join('academic_years', 'academic_years.id = classes.academic_year_id', 'left')
            ->join('users', 'users.id = classes.dosen_id', 'left')
            ->where('classes.id', $id)
            ->first();

        if (! $class) {
            return redirect()->to(site_url('admin/classes'))->with('error', 'Kelas tidak ditemukan.');
        }

        $enrolledStudents = $this->enrollModel->getStudentsByClass($id);
        
        // Mahasiswa yang belum masuk ke kelas ini
        $enrolledStudentIds = array_column($enrolledStudents, 'student_id');
        $availableStudentsQuery = $this->userModel->where('role', 'mahasiswa')->where('status', 'active');
        if (! empty($enrolledStudentIds)) {
            $availableStudentsQuery->whereNotIn('id', $enrolledStudentIds);
        }
        $availableStudents = $availableStudentsQuery->orderBy('name', 'ASC')->findAll();

        return view('admin/classes/detail', [
            'title'             => 'Detail Kelas ' . $class['class_name'] . ' - KodeMedis Learn',
            'class'             => $class,
            'enrolledStudents'  => $enrolledStudents,
            'availableStudents' => $availableStudents,
            'user'              => session()->get('user'),
        ]);
    }

    public function enrollStudent(int $classId)
    {
        $studentId = (int) $this->request->getPost('student_id');
        if (! $studentId) {
            return redirect()->back()->with('error', 'Pilih mahasiswa yang valid.');
        }

        // Cek duplikasi
        $exists = $this->enrollModel->where('class_id', $classId)->where('student_id', $studentId)->first();
        if (! $exists) {
            $this->enrollModel->insert([
                'class_id'    => $classId,
                'student_id'  => $studentId,
                'enrolled_at' => date('Y-m-d H:i:s'),
            ]);

            $this->logModel->logActivity(
                session()->get('user')['id'],
                'ENROLL_STUDENT',
                'CLASS_MGMT',
                "Mendaftarkan mahasiswa ID {$studentId} ke kelas ID {$classId}."
            );
        }

        return redirect()->to(site_url('admin/classes/' . $classId))->with('success', 'Mahasiswa berhasil ditambahkan ke kelas.');
    }

    public function removeStudent(int $classId, int $studentId)
    {
        $this->enrollModel->where('class_id', $classId)->where('student_id', $studentId)->delete();

        $this->logModel->logActivity(
            session()->get('user')['id'],
            'REMOVE_STUDENT_CLASS',
            'CLASS_MGMT',
            "Menghapus mahasiswa ID {$studentId} dari kelas ID {$classId}."
        );

        return redirect()->to(site_url('admin/classes/' . $classId))->with('success', 'Mahasiswa telah dikeluarkan dari kelas.');
    }
}
