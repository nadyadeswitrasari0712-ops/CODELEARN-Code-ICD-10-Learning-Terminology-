<?php

namespace App\Services;

class CaseGradingService
{
    protected GradingService $gradingService;

    public function __construct()
    {
        $this->gradingService = new GradingService();
    }

    /**
     * Mengevaluasi tingkat kecocokan kode ICD-10 secara parsial atau penuh
     * Return: ['match_level' => 'full'|'4_char'|'3_char'|'none', 'ratio' => 1.0|0.7|0.4|0.0]
     */
    public function evaluateCodeMatch(string $inputCode, string $keyCode, ?array $alternatives = []): array
    {
        $input = $this->gradingService->normalizeIcdCode($inputCode);
        $key   = $this->gradingService->normalizeIcdCode($keyCode);

        if (empty($input)) {
            return ['match_level' => 'none', 'ratio' => 0.0];
        }

        // 1. Cek kecocokan penuh (Full Match)
        if ($input === $key) {
            return ['match_level' => 'full', 'ratio' => 1.0];
        }

        if (! empty($alternatives)) {
            foreach ($alternatives as $alt) {
                if ($input === $this->gradingService->normalizeIcdCode((string) $alt)) {
                    return ['match_level' => 'full', 'ratio' => 1.0];
                }
            }
        }

        // 2. Cek kecocokan 4 karakter (Subkategori) - misal I21.0 vs I21.9
        $input4 = substr($input, 0, 5); // I21.0
        $key4   = substr($key, 0, 5);
        if (strlen($input) >= 4 && $input4 === $key4) {
            return ['match_level' => '4_char', 'ratio' => 0.70];
        }

        // 3. Cek kecocokan 3 karakter (Kategori) - misal I21
        $input3 = substr($input, 0, 3);
        $key3   = substr($key, 0, 3);
        if (strlen($input) >= 3 && $input3 === $key3) {
            return ['match_level' => '3_char', 'ratio' => 0.40];
        }

        return ['match_level' => 'none', 'ratio' => 0.0];
    }

    /**
     * Menghitung total skor kasus resume medis
     */
    public function gradeCase(array $caseKey, array $studentInput): array
    {
        $primaryMaxWeight   = 50.0;
        $secondaryMaxWeight = 30.0;
        $additionalMax      = 20.0;

        // Diagnosis Primer
        $primaryKey = $caseKey['primary_icd_code'];
        $primaryAlternatives = json_decode($caseKey['primary_alternatives'] ?? '[]', true) ?: [];
        $primaryEval = $this->evaluateCodeMatch($studentInput['primary_icd'] ?? '', $primaryKey, $primaryAlternatives);
        $primaryScore = round($primaryMaxWeight * $primaryEval['ratio'], 2);

        // Diagnosis Sekunder
        $secondaryKeys = json_decode($caseKey['secondary_codes'] ?? '[]', true) ?: [];
        $secondaryKey = ! empty($secondaryKeys) ? ($secondaryKeys[0]['code'] ?? '') : '';
        $secondaryAlternatives = ! empty($secondaryKeys) ? ($secondaryKeys[0]['alternatives'] ?? []) : [];
        $secondaryEval = $this->evaluateCodeMatch($studentInput['secondary_icd'] ?? '', $secondaryKey, $secondaryAlternatives);
        $secondaryScore = round($secondaryMaxWeight * $secondaryEval['ratio'], 2);

        // Alasan / Lead term check
        $leadTermInput = trim((string) ($studentInput['lead_term'] ?? ''));
        $additionalScore = ! empty($leadTermInput) ? $additionalMax : 0.0;

        $totalScore = $primaryScore + $secondaryScore + $additionalScore;

        return [
            'total_score'      => $totalScore,
            'primary_score'    => $primaryScore,
            'secondary_score'  => $secondaryScore,
            'additional_score' => $additionalScore,
            'primary_eval'     => $primaryEval,
            'secondary_eval'   => $secondaryEval,
        ];
    }
}
