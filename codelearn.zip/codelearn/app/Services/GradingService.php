<?php

namespace App\Services;

class GradingService
{
    /**
     * Normalisasi string kode ICD-10:
     * - Trim spasi awal & akhir
     * - Ubah ke huruf kapital (uppercase)
     * - Mengatasi variasi titik (contoh: A090 -> A09.0 atau A09.0 -> A09.0)
     */
    public function normalizeIcdCode(string $code): string
    {
        $clean = strtoupper(trim($code));
        $clean = preg_replace('/\s+/', '', $clean);

        // Jika panjang 4 karakter tanpa titik (misal: I210 atau A090), format menjadi I21.0
        if (preg_match('/^[A-Z][0-9]{3}$/', $clean)) {
            $clean = substr($clean, 0, 3) . '.' . substr($clean, 3, 1);
        }

        return $clean;
    }

    /**
     * Memeriksa apakah input kode cocok dengan kunci jawaban atau alternatif yang valid
     */
    public function checkCodeAnswer(string $inputCode, string $key, ?string $alternativesJson = null): bool
    {
        $normalizedInput = $this->normalizeIcdCode($inputCode);
        $normalizedKey   = $this->normalizeIcdCode($key);

        if ($normalizedInput === $normalizedKey) {
            return true;
        }

        if ($alternativesJson) {
            $alternatives = json_decode($alternativesJson, true);
            if (is_array($alternatives)) {
                foreach ($alternatives as $alt) {
                    if ($normalizedInput === $this->normalizeIcdCode((string) $alt)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }
}
