<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class MasterMedicalDataSeeder extends Seeder
{
    public function run()
    {
        $now = date('Y-m-d H:i:s');

        // ==========================================
        // 1. MODULES, TOPICS & MATERIALS
        // ==========================================
        $modules = [
            [
                'id'           => 1,
                'title'        => 'Dasar Terminologi Medis & Unsur Pembentuk Kata',
                'description'  => 'Mempelajari konsep dasar akar kata (root), awalan (prefix), akhiran (suffix), serta vokal penghubung dalam istilah anatomi dan patologi.',
                'icon'         => 'bi-translate',
                'order_num'    => 1,
                'is_published' => 1,
                'created_at'   => $now,
                'updated_at'   => $now,
            ],
            [
                'id'           => 2,
                'title'        => 'Klasifikasi Penyakit & Konvensi ICD-10',
                'description'  => 'Memahami struktur 3 volume ICD-10, tanda baca klinis, aturan penentuan diagnosis utama (MB1-MB5), dan kode ganda dagger-asterisk (+/*).',
                'icon'         => 'bi-journal-check',
                'order_num'    => 2,
                'is_published' => 1,
                'created_at'   => $now,
                'updated_at'   => $now,
            ],
            [
                'id'           => 3,
                'title'        => 'Koding Klinis Penyakit Sirkulasi & Pencernaan',
                'description'  => 'Latihan spesifik koding diagnosis Bab IX (Sistem Kardiovaskular) dan Bab XI (Sistem Digestif) beserta komplikasi dan komorbiditasnya.',
                'icon'         => 'bi-heart-pulse',
                'order_num'    => 3,
                'is_published' => 1,
                'created_at'   => $now,
                'updated_at'   => $now,
            ],
        ];
        $this->db->table('modules')->ignore(true)->insertBatch($modules);

        $topics = [
            [
                'id'                => 1,
                'module_id'         => 1,
                'title'             => 'Unsur Kata: Akar Kata (Root), Prefiks, dan Sufiks',
                'estimated_minutes' => 20,
                'order_num'         => 1,
                'created_at'        => $now,
                'updated_at'        => $now,
            ],
            [
                'id'                => 2,
                'module_id'         => 1,
                'title'             => 'Singkatan Medis dan Arah Posisi Tubuh',
                'estimated_minutes' => 15,
                'order_num'         => 2,
                'created_at'        => $now,
                'updated_at'        => $now,
            ],
            [
                'id'                => 3,
                'module_id'         => 2,
                'title'             => 'Struktur 3 Volume ICD-10 & Alur Koding Standar',
                'estimated_minutes' => 25,
                'order_num'         => 1,
                'created_at'        => $now,
                'updated_at'        => $now,
            ],
            [
                'id'                => 4,
                'module_id'         => 3,
                'title'             => 'Koding Hipertensi, IHD, dan Infark Miokard Akut (STEMI)',
                'estimated_minutes' => 30,
                'order_num'         => 1,
                'created_at'        => $now,
                'updated_at'        => $now,
            ],
        ];
        $this->db->table('topics')->ignore(true)->insertBatch($topics);

        $materials = [
            [
                'id'               => 1,
                'topic_id'         => 1,
                'content'          => '<h4>1. Konsep Dasar Pembentukan Istilah Medis</h4><p>Terminologi medis adalah bahasa khusus yang digunakan dalam pelayanan kesehatan untuk mendeskripsikan tubuh manusia, proses fisiologis, patologi penyakit, dan prosedur tindakan medis. Mayoritas istilah berasal dari bahasa Yunani Kuno dan Latin.</p><h5>Komponen Utama:</h5><ul><li><strong>Akar Kata (Root):</strong> Inti makna istilah medis, umumnya merujuk pada organ atau jaringan tubuh. Contoh: <code>cardi/o</code> (jantung), <code>gastr/o</code> (lambung), <code>nephr/o</code> (ginjal).</li><li><strong>Awalan (Prefix):</strong> Terletak di depan akar kata untuk menunjukkan lokasi, waktu, arah, jumlah, atau kondisi. Contoh: <code>tachy-</code> (cepat), <code>brady-</code> (lambat), <code>hyper-</code> (berlebih), <code>dys-</code> (sulit/nyeri).</li><li><strong>Akhiran (Suffix):</strong> Terletak di akhir istilah untuk menunjukkan penyakit, kondisi, gejala, atau prosedur bedah. Contoh: <code>-itis</code> (radang), <code>-ectomy</code> (pengangkatan/eksisi), <code>-algia</code> (nyeri), <code>-megaly</code> (pembesaran).</li><li><strong>Vokal Penghubung (Combining Vowel):</strong> Biasanya huruf <code>o</code> atau <code>i</code> yang menghubungkan dua akar kata atau akar kata dengan akhiran yang diawali konsonan.</li></ul><div class="alert alert-success mt-3"><strong>Contoh Analisis Kata:</strong><br><em>Gastroenteritis</em> = <code>gastr/o</code> (lambung) + <code>enter/o</code> (usus halus) + <code>-itis</code> (peradangan) = Peradangan pada membran mukosa lambung dan usus halus.</div>',
                'attachment_url'   => null,
                'reference_source' => 'Chabner, D. E. (2020). The Language of Medicine (12th ed.). Elsevier Saunders.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 2,
                'topic_id'         => 3,
                'content'          => '<h4>Langkah-Langkah Koding Diagnosis Sesuai Pedoman WHO</h4><p>Untuk memastikan mutu koding diagnosis morbiditas dan mortalitas yang valid, perekam medis wajib mengikuti langkah sistematis <strong>ICD-10 (International Statistical Classification of Diseases and Related Health Problems)</strong>:</p><ol><li><strong>Identifikasi Diagnosis Utama:</strong> Baca resume keluar (discharge summary) dan tentukan kondisi yang setelah pemeriksaan terbukti menjadi penyebab utama pasien dirawat.</li><li><strong>Tentukan Lead Term (Kata Kunci Utama):</strong> Cari kata kunci patologis atau keluhan pada Volume 3 (Indeks Alfabetis). <em>Jangan pernah mencari langsung dengan nama organ/lokasi anatomi kecuali tidak ada alternatif.</em></li><li><strong>Telusuri Volume 3:</strong> Perhatikan petunjuk silang (<em>see</em>, <em>see also</em>) dan subterm di bawah lead term.</li><li><strong>Verifikasi Kode di Volume 1 (Tabular List):</strong> Buka kode di Volume 1 untuk memastikan karakter ke-4 atau ke-5 dan membaca catatan <strong>Inklusi (Includes)</strong> serta <strong>Eksklusi (Excludes)</strong>.</li><li><strong>Periksa Kode Ganda (+ / *):</strong> Bila terdapat tanda sangkur (dagger †) dan bintang (asterisk *), diagnosis primer diberi kode sangkur (†) dan manifestasi diberi kode bintang (*).</li></ol>',
                'attachment_url'   => null,
                'reference_source' => 'World Health Organization (WHO). ICD-10 International Statistical Classification of Diseases, Volume 2: Instruction Manual.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
        ];
        $this->db->table('materials')->ignore(true)->insertBatch($materials);

        // Progress baca awal untuk Raisa
        $progress = [
            [
                'id'           => 1,
                'user_id'      => 3,
                'topic_id'     => 1,
                'is_completed' => 1,
                'completed_at' => $now,
            ],
        ];
        $this->db->table('student_topic_progress')->ignore(true)->insertBatch($progress);

        // ==========================================
        // 2. KAMUS TERMINOLOGI MEDIS (FR-14)
        // ==========================================
        $medicalTerms = [
            [
                'id'               => 1,
                'term'             => 'Cardiomegaly',
                'meaning'          => 'Pembesaran ukuran organ jantung melebihi batas normal yang terlihat pada foto rontgen toraks.',
                'root_word'        => 'cardi/o (jantung)',
                'prefix'           => null,
                'suffix'           => '-megaly (pembesaran)',
                'body_system'      => 'Kardiovaskular',
                'example_sentence' => 'Pemeriksaan rontgen toraks menunjukkan cardiomegaly dengan CTR > 55%.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 2,
                'term'             => 'Gastroenteritis',
                'meaning'          => 'Peradangan pada saluran pencernaan yang melibatkan lambung dan usus halus, sering bermanifestasi sebagai diare dan muntah.',
                'root_word'        => 'gastr/o (lambung), enter/o (usus)',
                'prefix'           => null,
                'suffix'           => '-itis (radang)',
                'body_system'      => 'Pencernaan',
                'example_sentence' => 'Pasien didiagnosis gastroenteritis akut dehidrasi sedang.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 3,
                'term'             => 'Nephrolithiasis',
                'meaning'          => 'Kondisi terbentuknya batu pada saluran atau parenkim ginjal.',
                'root_word'        => 'nephr/o (ginjal), lith/o (batu)',
                'prefix'           => null,
                'suffix'           => '-iasis (kondisi pembentukan)',
                'body_system'      => 'Urogenital',
                'example_sentence' => 'Hasil USG abdomen mengonfirmasi nephrolithiasis kutub bawah ginjal kanan berukuran 8 mm.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 4,
                'term'             => 'Appendectomy',
                'meaning'          => 'Tindakan bedah pembedahan untuk mengangkat umbai cacing (apendiks vermiformis) yang mengalami peradangan akut.',
                'root_word'        => 'appendic/o (apendiks)',
                'prefix'           => null,
                'suffix'           => '-ectomy (pemotongan/eksisi bedah)',
                'body_system'      => 'Pencernaan',
                'example_sentence' => 'Dokter spesialis bedah memutuskan melakukan cito laparotomy appendectomy.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 5,
                'term'             => 'Bradycardia',
                'meaning'          => 'Frekuensi denyut jantung lambat di bawah 60 kali per menit pada orang dewasa saat istirahat.',
                'root_word'        => 'cardi/o (jantung)',
                'prefix'           => 'brady- (lambat)',
                'suffix'           => '-ia (keadaan)',
                'body_system'      => 'Kardiovaskular',
                'example_sentence' => 'Pasien mengalami sinus bradycardia dengan laju nadi 48x/menit.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 6,
                'term'             => 'Tachycardia',
                'meaning'          => 'Frekuensi denyut jantung cepat di atas 100 kali per menit saat istirahat.',
                'root_word'        => 'cardi/o (jantung)',
                'prefix'           => 'tachy- (cepat)',
                'suffix'           => '-ia (keadaan)',
                'body_system'      => 'Kardiovaskular',
                'example_sentence' => 'Pasien syok anafilaktik mengalami tachycardia reaktif mencapai 130x/menit.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 7,
                'term'             => 'Dyspnea',
                'meaning'          => 'Sensasi kesulitan bernapas atau sesak napas yang dirasakan pasien.',
                'root_word'        => 'pnea (pernapasan)',
                'prefix'           => 'dys- (sulit/abnormal)',
                'suffix'           => null,
                'body_system'      => 'Respirasi',
                'example_sentence' => 'Keluhan utama pasien asma adalah dyspnea berat berulang.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 8,
                'term'             => 'Hematemesis',
                'meaning'          => 'Muntah darah segar atau kehitaman menyerupai bubuk kopi akibat perdarahan saluran cerna bagian atas.',
                'root_word'        => 'hemat/o (darah)',
                'prefix'           => null,
                'suffix'           => '-emesis (muntah)',
                'body_system'      => 'Pencernaan',
                'example_sentence' => 'Pasien dengan riwayat sirosis hepatis mengeluh hematemesis melena masif.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 9,
                'term'             => 'Osteoarthritis',
                'meaning'          => 'Penyakit sendi degeneratif non-inflamasi yang ditandai kerusakan kartilago sendi artikular.',
                'root_word'        => 'oste/o (tulang), arthr/o (sendi)',
                'prefix'           => null,
                'suffix'           => '-itis (radang)',
                'body_system'      => 'Muskuloskeletal',
                'example_sentence' => 'Pasien lansia menderita osteoarthritis genu bilateral grade III.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
            [
                'id'               => 10,
                'term'             => 'Hypertension',
                'meaning'          => 'Kondisi peningkatan tekanan darah sistemik secara persisten dengan tekanan sistolik >= 140 mmHg atau diastolik >= 90 mmHg.',
                'root_word'        => 'tens/o (tekanan)',
                'prefix'           => 'hyper- (tinggi/berlebih)',
                'suffix'           => '-ion (proses/kondisi)',
                'body_system'      => 'Kardiovaskular',
                'example_sentence' => 'Diagnosis primer pasien adalah essential primary hypertension stadium 2.',
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
        ];
        $this->db->table('medical_terms')->ignore(true)->insertBatch($medicalTerms);

        // ==========================================
        // 3. MASTER KODE ICD-10 (FR-16)
        // ==========================================
        $icdCodes = [
            // Bab I: Infeksi & Parasit (A00-B99)
            ['code' => 'A09.0', 'description' => 'Other and unspecified gastroenteritis and colitis of infectious origin', 'chapter_no' => 'I', 'chapter_title' => 'Penyakit Infeksi dan Parasit Tertentu', 'block_range' => 'A00-A09', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'A09.9', 'description' => 'Gastroenteritis and colitis of unspecified origin', 'chapter_no' => 'I', 'chapter_title' => 'Penyakit Infeksi dan Parasit Tertentu', 'block_range' => 'A00-A09', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'A01.0', 'description' => 'Typhoid fever (Demam tifoid)', 'chapter_no' => 'I', 'chapter_title' => 'Penyakit Infeksi dan Parasit Tertentu', 'block_range' => 'A00-A09', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'A15.0', 'description' => 'Tuberculosis of lung, confirmed by sputum microscopy with or without culture', 'chapter_no' => 'I', 'chapter_title' => 'Penyakit Infeksi dan Parasit Tertentu', 'block_range' => 'A15-A19', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'A90',   'description' => 'Dengue fever [classical dengue]', 'chapter_no' => 'I', 'chapter_title' => 'Penyakit Infeksi dan Parasit Tertentu', 'block_range' => 'A90-A99', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'A91',   'description' => 'Dengue haemorrhagic fever (DHF)', 'chapter_no' => 'I', 'chapter_title' => 'Penyakit Infeksi dan Parasit Tertentu', 'block_range' => 'A90-A99', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'B20',   'description' => 'Human immunodeficiency virus [HIV] disease resulting in infectious and parasitic diseases', 'chapter_no' => 'I', 'chapter_title' => 'Penyakit Infeksi dan Parasit Tertentu', 'block_range' => 'B20-B24', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],

            // Bab II: Neoplasma (C00-D48)
            ['code' => 'C50.9', 'description' => 'Malignant neoplasm: Breast, unspecified', 'chapter_no' => 'II', 'chapter_title' => 'Neoplasma', 'block_range' => 'C50', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'D50.9', 'description' => 'Iron deficiency anaemia, unspecified', 'chapter_no' => 'III', 'chapter_title' => 'Penyakit Darah dan Organ Pembentuk Darah', 'block_range' => 'D50-D53', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],

            // Bab IV: Endokrin (E00-E90)
            ['code' => 'E11.9', 'description' => 'Type 2 diabetes mellitus without complications', 'chapter_no' => 'IV', 'chapter_title' => 'Penyakit Endokrin, Nutrisi dan Metabolik', 'block_range' => 'E10-E14', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'E11.5', 'description' => 'Type 2 diabetes mellitus with peripheral circulatory complications (Diabetic foot ulcer)', 'chapter_no' => 'IV', 'chapter_title' => 'Penyakit Endokrin, Nutrisi dan Metabolik', 'block_range' => 'E10-E14', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],

            // Bab IX: Sirkulasi (I00-I99)
            ['code' => 'I10',   'description' => 'Essential (primary) hypertension', 'chapter_no' => 'IX', 'chapter_title' => 'Penyakit Sistem Sirkulasi', 'block_range' => 'I10-I15', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'I11.0', 'description' => 'Hypertensive heart disease with (congestive) heart failure', 'chapter_no' => 'IX', 'chapter_title' => 'Penyakit Sistem Sirkulasi', 'block_range' => 'I10-I15', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'I21.0', 'description' => 'Acute transmural myocardial infarction of anterior wall (STEMI Anteroseptal)', 'chapter_no' => 'IX', 'chapter_title' => 'Penyakit Sistem Sirkulasi', 'block_range' => 'I20-I25', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'I21.9', 'description' => 'Acute myocardial infarction, unspecified', 'chapter_no' => 'IX', 'chapter_title' => 'Penyakit Sistem Sirkulasi', 'block_range' => 'I20-I25', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'I50.0', 'description' => 'Congestive heart failure (Gagal jantung kongestif)', 'chapter_no' => 'IX', 'chapter_title' => 'Penyakit Sistem Sirkulasi', 'block_range' => 'I50', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'I64',   'description' => 'Stroke, not specified as haemorrhage or infarction', 'chapter_no' => 'IX', 'chapter_title' => 'Penyakit Sistem Sirkulasi', 'block_range' => 'I60-I69', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],

            // Bab X: Respirasi (J00-J99)
            ['code' => 'J06.9', 'description' => 'Acute upper respiratory infection, unspecified (ISPA Akut)', 'chapter_no' => 'X', 'chapter_title' => 'Penyakit Sistem Respirasi', 'block_range' => 'J00-J06', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'J18.9', 'description' => 'Pneumonia, unspecified', 'chapter_no' => 'X', 'chapter_title' => 'Penyakit Sistem Respirasi', 'block_range' => 'J12-J18', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'J45.9', 'description' => 'Asthma, unspecified', 'chapter_no' => 'X', 'chapter_title' => 'Penyakit Sistem Respirasi', 'block_range' => 'J45-J46', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],

            // Bab XI: Digestif (K00-K93)
            ['code' => 'K29.7', 'description' => 'Gastritis, unspecified', 'chapter_no' => 'XI', 'chapter_title' => 'Penyakit Sistem Pencernaan', 'block_range' => 'K29', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'K35.8', 'description' => 'Other and unspecified acute appendicitis', 'chapter_no' => 'XI', 'chapter_title' => 'Penyakit Sistem Pencernaan', 'block_range' => 'K35', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'K40.9', 'description' => 'Unilateral or unspecified inguinal hernia, without obstruction or gangrene', 'chapter_no' => 'XI', 'chapter_title' => 'Penyakit Sistem Pencernaan', 'block_range' => 'K40', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],

            // Bab XIV: Urogenital (N00-N99)
            ['code' => 'N20.0', 'description' => 'Calculus of kidney (Nefrolitiasis)', 'chapter_no' => 'XIV', 'chapter_title' => 'Penyakit Sistem Genitourinaria', 'block_range' => 'N20-N23', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'N39.0', 'description' => 'Urinary tract infection, site not specified (ISK)', 'chapter_no' => 'XIV', 'chapter_title' => 'Penyakit Sistem Genitourinaria', 'block_range' => 'N39', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],

            // Bab XV: Kehamilan & Persalinan (O00-O99)
            ['code' => 'O80.0', 'description' => 'Spontaneous vertex delivery (Partus spontan normal)', 'chapter_no' => 'XV', 'chapter_title' => 'Kehamilan, Persalinan dan Masa Nifas', 'block_range' => 'O80-O84', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],

            // Bab XIX & XXI: Cedera & Faktor Kontak (S00-T98, Z00-Z99)
            ['code' => 'S06.0', 'description' => 'Concussion (Komosio serebri / Cedera kepala ringan)', 'chapter_no' => 'XIX', 'chapter_title' => 'Cedera, Keracunan dan Konsekuensi Lain', 'block_range' => 'S00-S09', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'Z00.0', 'description' => 'General medical examination (Medical check up)', 'chapter_no' => 'XXI', 'chapter_title' => 'Faktor yang Mempengaruhi Status Kesehatan', 'block_range' => 'Z00-Z13', 'volume_type' => 1, 'valid_for_coding' => 1, 'created_at' => $now, 'updated_at' => $now],
        ];
        $this->db->table('icd10_codes')->ignore(true)->insertBatch($icdCodes);

        // ==========================================
        // 4. BANK SOAL, KUIS & ATTEMPTS (FASE 3)
        // ==========================================
        $questions = [
            [
                'id'                => 1,
                'topic_id'          => 1,
                'type'              => 'multiple_choice',
                'difficulty'        => 'mudah',
                'question_text'     => 'Unsur kata yang berfungsi sebagai penunjuk organ atau jaringan tubuh utama dalam terminologi medis disebut sebagai...',
                'code_answer_key'   => null,
                'alternative_codes' => null,
                'explanation'       => 'Akar kata (Root) adalah bagian inti dari istilah medis yang menunjukkan bagian organ tubuh manusia (misal: nephr = ginjal, cardi = jantung).',
                'reference_source'  => 'Chabner, D. E. (2020). The Language of Medicine. Hal. 3.',
                'created_by'        => 2,
                'status'            => 'terbit',
                'created_at'        => $now,
                'updated_at'        => $now,
            ],
            [
                'id'                => 2,
                'topic_id'          => 1,
                'type'              => 'multiple_choice',
                'difficulty'        => 'sedang',
                'question_text'     => 'Istilah medis yang bermakna pemotongan atau pengangkatan kantung empedu melalui tindakan bedah adalah...',
                'code_answer_key'   => null,
                'alternative_codes' => null,
                'explanation'       => 'Cholecystectomy terdiri dari cholecyst/o (kantung empedu) + -ectomy (eksisi/pengangkatan bedah).',
                'reference_source'  => 'Dorland\'s Illustrated Medical Dictionary. 33rd Edition.',
                'created_by'        => 2,
                'status'            => 'terbit',
                'created_at'        => $now,
                'updated_at'        => $now,
            ],
            [
                'id'                => 3,
                'topic_id'          => 4,
                'type'              => 'code_fill',
                'difficulty'        => 'sedang',
                'question_text'     => 'Tuliskan kode ICD-10 yang tepat untuk diagnosis pasien: <strong>Essential (primary) hypertension</strong> tanpa komplikasi gagal jantung atau ginjal.',
                'code_answer_key'   => 'I10',
                'alternative_codes' => json_encode(['I10', 'i10']),
                'explanation'       => 'Sesuai ICD-10 Volume 1 Bab IX, Hipertensi Primer/Esensial diklasifikasikan pada kategori 3 karakter I10.',
                'reference_source'  => 'WHO ICD-10 Volume 1 (Tabular List) Chapter IX: Diseases of the circulatory system.',
                'created_by'        => 2,
                'status'            => 'terbit',
                'created_at'        => $now,
                'updated_at'        => $now,
            ],
            [
                'id'                => 4,
                'topic_id'          => 4,
                'type'              => 'code_fill',
                'difficulty'        => 'sulit',
                'question_text'     => 'Tuliskan kode ICD-10 untuk diagnosis: <strong>Acute transmural myocardial infarction of anterior wall (STEMI Anterior)</strong>.',
                'code_answer_key'   => 'I21.0',
                'alternative_codes' => json_encode(['I21.0', 'i21.0', 'I210']),
                'explanation'       => 'Penelusuran Volume 3: Infarction -> myocardium -> anterior wall -> I21.0. Diverifikasi pada Tabular List Volume 1.',
                'reference_source'  => 'WHO ICD-10 Volume 1 dan 3, Kode I21.0.',
                'created_by'        => 2,
                'status'            => 'terbit',
                'created_at'        => $now,
                'updated_at'        => $now,
            ],
        ];
        $this->db->table('questions')->ignore(true)->insertBatch($questions);

        $options = [
            ['question_id' => 1, 'option_text' => 'Akar Kata (Root)', 'is_correct' => 1],
            ['question_id' => 1, 'option_text' => 'Awalan (Prefix)', 'is_correct' => 0],
            ['question_id' => 1, 'option_text' => 'Akhiran (Suffix)', 'is_correct' => 0],
            ['question_id' => 1, 'option_text' => 'Vokal Penghubung', 'is_correct' => 0],

            ['question_id' => 2, 'option_text' => 'Cholecystectomy', 'is_correct' => 1],
            ['question_id' => 2, 'option_text' => 'Cholecystitis', 'is_correct' => 0],
            ['question_id' => 2, 'option_text' => 'Cholelithiasis', 'is_correct' => 0],
            ['question_id' => 2, 'option_text' => 'Colectomy', 'is_correct' => 0],
        ];
        $this->db->table('question_options')->ignore(true)->insertBatch($options);

        // Kuis Resmi
        $quizzes = [
            [
                'id'               => 1,
                'class_id'         => 1,
                'title'            => 'Kuis Evaluasi Kompetensi: Dasar Terminologi & Sirkulasi (ICD-10)',
                'description'      => 'Kuis formatif terstandar untuk menguji kemampuan pembentukan istilah medis dan penetapan kode diagnosis kardiovaskular.',
                'duration_minutes' => 30,
                'passing_score'    => 70.00,
                'max_attempts'     => 3,
                'is_randomized'    => 1,
                'is_published'     => 1,
                'created_at'       => $now,
                'updated_at'       => $now,
            ],
        ];
        $this->db->table('quizzes')->ignore(true)->insertBatch($quizzes);

        $quizQuestions = [
            ['quiz_id' => 1, 'question_id' => 1, 'weight' => 25.00],
            ['quiz_id' => 1, 'question_id' => 2, 'weight' => 25.00],
            ['quiz_id' => 1, 'question_id' => 3, 'weight' => 25.00],
            ['quiz_id' => 1, 'question_id' => 4, 'weight' => 25.00],
        ];
        $this->db->table('quiz_questions')->ignore(true)->insertBatch($quizQuestions);

        // Percobaan Kuis oleh Raisa (skor 75.00)
        $attempt = [
            'id'             => 1,
            'quiz_id'        => 1,
            'user_id'        => 3,
            'attempt_number' => 1,
            'score'          => 75.00,
            'passed'         => 1,
            'status'         => 'completed',
            'started_at'     => date('Y-m-d H:i:s', strtotime('-40 minutes')),
            'submitted_at'   => date('Y-m-d H:i:s', strtotime('-15 minutes')),
        ];
        $this->db->table('quiz_attempts')->ignore(true)->insert($attempt);

        $attemptAnswers = [
            ['attempt_id' => 1, 'question_id' => 1, 'user_answer' => 'Akar Kata (Root)', 'is_correct' => 1, 'score_earned' => 25.00],
            ['attempt_id' => 1, 'question_id' => 2, 'user_answer' => 'Cholecystectomy', 'is_correct' => 1, 'score_earned' => 25.00],
            ['attempt_id' => 1, 'question_id' => 3, 'user_answer' => 'I10', 'is_correct' => 1, 'score_earned' => 25.00],
            ['attempt_id' => 1, 'question_id' => 4, 'user_answer' => 'I21.9', 'is_correct' => 0, 'score_earned' => 0.00],
        ];
        $this->db->table('quiz_attempt_answers')->ignore(true)->insertBatch($attemptAnswers);

        // ==========================================
        // 5. SIMULASI KASUS RESUME MEDIS (FASE 4)
        // ==========================================
        $clinicalCases = [
            [
                'id'                        => 1,
                'case_number'               => 'RM-2026-0881',
                'title'                     => 'Simulasi Kasus 1: Nyeri Dada Akut pada Pasien Hipertensi Kronis',
                'patient_name'              => 'Tn. Hendra Wijaya (Fiktif)',
                'patient_age'               => '58 Tahun',
                'patient_gender'            => 'L',
                'admission_type'            => 'Rawat Inap Cito (IGD)',
                'chief_complaint'           => 'Nyeri dada kiri hebat seperti tertimpa beban berat sejak 2 jam sebelum masuk RS, menjalar ke leher dan lengan kiri disertai keringat dingin.',
                'history_illness'           => 'Pasien memiliki riwayat Hipertensi sejak 7 tahun lalu namun tidak teratur minum obat. Riwayat perokok aktif 1 bungkus per hari selama 30 tahun. Tidak ada riwayat DM atau asma.',
                'physical_exam'             => 'Keadaan umum: Tampak sakit berat, gelisah dan diaforesis. Tekanan Darah: 165/100 mmHg. Nadi: 104x/menit. Respirasi: 24x/menit. Suhu: 36.8°C. Suara jantung S1-S2 reguler, tidak ada murmur. Suara paru vesikuler tanpa ronki.',
                'diagnostic_tests'          => 'EKG: ST elevasi > 2 mm pada lead V1-V4 (Anteroseptal AMI). Laboratorium: Troponin I positif tinggi (8.4 ng/mL, rujukan <0.04), CK-MB 68 U/L. GDS: 118 mg/dL. Rontgen Toraks: CTR 52%, tidak ada kardiomegali nyata.',
                'medical_therapy'           => 'Oksigen kanul 3 lpm, Aspirin 160 mg kunyah, Clopidogrel 300 mg loading, ISDN 5 mg sublingual, Morfin 2.5 mg IV, Heparinisasi dan rujukan PCI cito.',
                'attending_physician_notes' => 'Resume Dokter DPJP: Pasien dirawat inap dengan diagnosis kerja Sindrom Koroner Akut (STEMI Akut Dinding Anterior) dengan komorbid Hipertensi Esensial.',
                'difficulty'                => 'menengah',
                'status'                    => 'terbit',
                'created_at'                => $now,
                'updated_at'                => $now,
            ],
        ];
        $this->db->table('clinical_cases')->ignore(true)->insertBatch($clinicalCases);

        $caseKeys = [
            [
                'id'                        => 1,
                'case_id'                   => 1,
                'primary_diagnosis_title'   => 'Acute transmural myocardial infarction of anterior wall (STEMI Anterior)',
                'primary_icd_code'          => 'I21.0',
                'primary_alternatives'      => json_encode(['I21.0', 'i21.0', 'I21.9', 'I21']),
                'secondary_codes'           => json_encode([
                    ['title' => 'Essential (primary) hypertension', 'code' => 'I10', 'alternatives' => ['I10', 'i10']]
                ]),
                'additional_codes'          => json_encode([]),
                'lead_term_steps'           => '1. Buka ICD-10 Volume 3 (Indeks Alfabetis).' . "\n" . '2. Cari Lead Term: "Infarction".' . "\n" . '3. Telusuri subterm: "- myocardium (acute or with a stated duration of 4 weeks or less)".' . "\n" . '4. Telusuri spesifikasi anatomis: "-- anterior (wall) (transmural)" -> mengarahkan ke I21.0.',
                'tabular_check_steps'       => 'Buka ICD-10 Volume 1 (Tabular List) pada kategori I21 (Acute myocardial infarction). Subkategori I21.0 memuat deskripsi spesifik "Acute transmural myocardial infarction of anterior wall". Pastikan tidak ada pengecualian yang berlaku.',
                'inclusion_exclusion_notes' => 'Perhatikan aturan Excludes pada I21: recurrent myocardial infarction (I22.-). Pada kasus ini, ini adalah serangan pertama sehingga tepat menggunakan I21.0.',
                'reference_source'          => 'WHO ICD-10 Volume 1 (Tabular List) Bab IX dan Pedoman Koding Kemenkes RI.',
            ],
        ];
        $this->db->table('case_keys')->ignore(true)->insertBatch($caseKeys);

        // Simulasi Submission oleh Raisa
        $caseSubmission = [
            'id'                   => 1,
            'case_id'              => 1,
            'user_id'              => 3,
            'total_score'          => 85.00,
            'primary_score'        => 50.00,
            'secondary_score'      => 30.00,
            'additional_score'     => 5.00,
            'dosen_override_score' => 88.00,
            'dosen_notes'          => 'Penalaran diagnosis utama sangat tepat. Penentuan kode I21.0 sempurna. Terus pertahankan ketelitian mencari lead term.',
            'submitted_at'         => date('Y-m-d H:i:s', strtotime('-1 day')),
        ];
        $this->db->table('case_submissions')->ignore(true)->insert($caseSubmission);

        $submissionDetails = [
            [
                'submission_id'        => 1,
                'component_type'       => 'primary',
                'input_diagnosis_text' => 'STEMI Akut Anterior',
                'input_icd_code'       => 'I21.0',
                'match_level'          => 'full',
                'earned_score'         => 50.00,
                'max_score'            => 50.00,
            ],
            [
                'submission_id'        => 1,
                'component_type'       => 'secondary',
                'input_diagnosis_text' => 'Hipertensi Primer',
                'input_icd_code'       => 'I10',
                'match_level'          => 'full',
                'earned_score'         => 30.00,
                'max_score'            => 30.00,
            ],
        ];
        $this->db->table('case_submission_details')->ignore(true)->insertBatch($submissionDetails);

        // ==========================================
        // 6. ANALITIK KOMPETENSI (FASE 5)
        // ==========================================
        $competencyScores = [
            ['user_id' => 3, 'chapter_code' => 'Bab I',   'chapter_name' => 'Penyakit Infeksi & Parasit (A00-B99)', 'score' => 82.50, 'total_assessments' => 4, 'updated_at' => $now],
            ['user_id' => 3, 'chapter_code' => 'Bab II',  'chapter_name' => 'Neoplasma (C00-D48)',                  'score' => 70.00, 'total_assessments' => 2, 'updated_at' => $now],
            ['user_id' => 3, 'chapter_code' => 'Bab IV',  'chapter_name' => 'Endokrin & Nutrisi (E00-E90)',         'score' => 78.00, 'total_assessments' => 3, 'updated_at' => $now],
            ['user_id' => 3, 'chapter_code' => 'Bab IX',  'chapter_name' => 'Sistem Sirkulasi (I00-I99)',          'score' => 88.00, 'total_assessments' => 5, 'updated_at' => $now],
            ['user_id' => 3, 'chapter_code' => 'Bab X',   'chapter_name' => 'Sistem Respirasi (J00-J99)',           'score' => 52.00, 'total_assessments' => 3, 'updated_at' => $now], // At risk
            ['user_id' => 3, 'chapter_code' => 'Bab XI',  'chapter_name' => 'Sistem Pencernaan (K00-K93)',          'score' => 85.00, 'total_assessments' => 4, 'updated_at' => $now],
            ['user_id' => 3, 'chapter_code' => 'Bab XIV', 'chapter_name' => 'Sistem Urogenital (N00-N99)',          'score' => 74.00, 'total_assessments' => 2, 'updated_at' => $now],
        ];
        $this->db->table('competency_scores')->ignore(true)->insertBatch($competencyScores);

        // Pengumuman
        $announcements = [
            [
                'id'         => 1,
                'class_id'   => 1,
                'author_id'  => 2,
                'title'      => 'Persiapan Ujian Evaluasi Mandiri Koding Diagnosis Sebelum PKL',
                'content'    => 'Diberitahukan kepada seluruh mahasiswa kelas RMIK 3A bahwa latihan simulasi kasus resume medis telah dibuka. Pastikan Anda menyelesaikan minimal 2 kasus klinis dan mempelajari kamus terminologi medis sebelum jadwal pembekalan PKL minggu depan.',
                'created_at' => $now,
            ],
        ];
        $this->db->table('announcements')->ignore(true)->insertBatch($announcements);
    }
}
