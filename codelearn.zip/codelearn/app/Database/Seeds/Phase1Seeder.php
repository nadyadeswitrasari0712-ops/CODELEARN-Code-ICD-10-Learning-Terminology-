<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Phase1Seeder extends Seeder
{
    public function run()
    {
        $now = date('Y-m-d H:i:s');
        $defaultPassword = password_hash('password123', PASSWORD_BCRYPT);

        // 1. Users (Admin, Dosen, Mahasiswa)
        $users = [
            [
                'id'            => 1,
                'nim_nip'       => 'ADMIN01',
                'name'          => 'Pak Dedi (Admin Prodi)',
                'email'         => 'admin@kodemedis.ac.id',
                'password_hash' => $defaultPassword,
                'role'          => 'admin',
                'status'        => 'active',
                'created_at'    => $now,
                'updated_at'    => $now,
            ],
            [
                'id'            => 2,
                'nim_nip'       => '198501152010122001',
                'name'          => 'Bu Ratna, M.Kes (Dosen Koding)',
                'email'         => 'ratna@kodemedis.ac.id',
                'password_hash' => $defaultPassword,
                'role'          => 'dosen',
                'status'        => 'active',
                'created_at'    => $now,
                'updated_at'    => $now,
            ],
            [
                'id'            => 3,
                'nim_nip'       => '202401001',
                'name'          => 'Raisa Mahasiswi',
                'email'         => 'raisa@student.kodemedis.ac.id',
                'password_hash' => $defaultPassword,
                'role'          => 'mahasiswa',
                'status'        => 'active',
                'created_at'    => $now,
                'updated_at'    => $now,
            ],
        ];

        $this->db->table('users')->ignore(true)->insertBatch($users);

        // 2. Tahun Akademik
        $academicYear = [
            'id'         => 1,
            'year_name'  => '2026/2027',
            'semester'   => 'ganjil',
            'is_active'  => 1,
            'created_at' => $now,
            'updated_at' => $now,
        ];
        $this->db->table('academic_years')->ignore(true)->insert($academicYear);

        // 3. Kelas Perkuliahan
        $class = [
            'id'               => 1,
            'academic_year_id' => 1,
            'dosen_id'         => 2,
            'class_name'       => 'RMIK 3A - Koding Diagnosis & Terminologi',
            'description'      => 'Kelas pembelajaran koding klinis ICD-10 dan terminologi medis semester 3.',
            'created_at'       => $now,
            'updated_at'       => $now,
        ];
        $this->db->table('classes')->ignore(true)->insert($class);

        // 4. Enrollment Mahasiswa ke Kelas
        $enrollment = [
            'id'          => 1,
            'class_id'    => 1,
            'student_id'  => 3,
            'enrolled_at' => $now,
        ];
        $this->db->table('class_enrollments')->ignore(true)->insert($enrollment);
    }
}
