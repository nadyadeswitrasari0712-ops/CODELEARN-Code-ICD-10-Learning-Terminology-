<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreatePhases2To5Tables extends Migration
{
    public function up()
    {
        // ==========================================
        // FASE 2: Modul, Topik, Materi, Kamus & ICD
        // ==========================================

        // 1. Table modules
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'title' => [
                'type'       => 'VARCHAR',
                'constraint' => '150',
            ],
            'description' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'icon' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
                'default'    => 'bi-journal-medical',
            ],
            'order_num' => [
                'type'       => 'INT',
                'constraint' => 5,
                'default'    => 1,
            ],
            'is_published' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 1,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('modules', true);

        // 2. Table topics
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'module_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'title' => [
                'type'       => 'VARCHAR',
                'constraint' => '150',
            ],
            'estimated_minutes' => [
                'type'       => 'INT',
                'constraint' => 5,
                'default'    => 15,
            ],
            'order_num' => [
                'type'       => 'INT',
                'constraint' => 5,
                'default'    => 1,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('module_id', 'modules', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('topics', true);

        // 3. Table materials
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'topic_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'content' => [
                'type' => 'LONGTEXT',
            ],
            'attachment_url' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
                'null'       => true,
            ],
            'reference_source' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('topic_id', 'topics', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('materials', true);

        // 4. Table student_topic_progress
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'user_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'topic_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'is_completed' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 1,
            ],
            'completed_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addUniqueKey(['user_id', 'topic_id']);
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('topic_id', 'topics', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('student_topic_progress', true);

        // 5. Table medical_terms (Kamus Terminologi Medis)
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'term' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'meaning' => [
                'type' => 'TEXT',
            ],
            'root_word' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
                'null'       => true,
            ],
            'prefix' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
                'null'       => true,
            ],
            'suffix' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
                'null'       => true,
            ],
            'body_system' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
                'null'       => true,
            ],
            'example_sentence' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('medical_terms', true);

        // 6. Table icd10_codes (Master ICD-10)
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'code' => [
                'type'       => 'VARCHAR',
                'constraint' => '20',
            ],
            'description' => [
                'type' => 'TEXT',
            ],
            'chapter_no' => [
                'type'       => 'VARCHAR',
                'constraint' => '10',
            ],
            'chapter_title' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'block_range' => [
                'type'       => 'VARCHAR',
                'constraint' => '30',
                'null'       => true,
            ],
            'volume_type' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 1, // 1: Tabular, 3: Alphabetical Index
            ],
            'valid_for_coding' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 1,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addKey('code');
        $this->forge->createTable('icd10_codes', true);

        // ==========================================
        // FASE 3: Bank Soal & Kuis Auto-Grading
        // ==========================================

        // 7. Table questions
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'topic_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
                'null'       => true,
            ],
            'type' => [
                'type'       => 'ENUM',
                'constraint' => ['multiple_choice', 'true_false', 'code_fill', 'short_answer'],
                'default'    => 'multiple_choice',
            ],
            'difficulty' => [
                'type'       => 'ENUM',
                'constraint' => ['mudah', 'sedang', 'sulit'],
                'default'    => 'sedang',
            ],
            'question_text' => [
                'type' => 'TEXT',
            ],
            'code_answer_key' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
                'null'       => true,
            ],
            'alternative_codes' => [
                'type' => 'TEXT', // JSON array of acceptable variations
                'null' => true,
            ],
            'explanation' => [
                'type' => 'TEXT',
            ],
            'reference_source' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
                'null'       => true,
            ],
            'created_by' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
                'null'       => true,
            ],
            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['draft', 'terbit'],
                'default'    => 'terbit',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('topic_id', 'topics', 'id', 'SET NULL', 'CASCADE');
        $this->forge->addForeignKey('created_by', 'users', 'id', 'SET NULL', 'CASCADE');
        $this->forge->createTable('questions', true);

        // 8. Table question_options
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'question_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'option_text' => [
                'type' => 'TEXT',
            ],
            'is_correct' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 0,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('question_id', 'questions', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('question_options', true);

        // 9. Table quizzes
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'class_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'title' => [
                'type'       => 'VARCHAR',
                'constraint' => '150',
            ],
            'description' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'duration_minutes' => [
                'type'       => 'INT',
                'constraint' => 5,
                'default'    => 30,
            ],
            'passing_score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 70.00,
            ],
            'max_attempts' => [
                'type'       => 'INT',
                'constraint' => 3,
                'default'    => 3,
            ],
            'is_randomized' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 1,
            ],
            'is_published' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 1,
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('class_id', 'classes', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('quizzes', true);

        // 10. Table quiz_questions
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'quiz_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'question_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'weight' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 1.00,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('quiz_id', 'quizzes', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('question_id', 'questions', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('quiz_questions', true);

        // 11. Table quiz_attempts
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'quiz_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'user_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'attempt_number' => [
                'type'       => 'INT',
                'constraint' => 3,
                'default'    => 1,
            ],
            'score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 0.00,
            ],
            'passed' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 0,
            ],
            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['in_progress', 'completed'],
                'default'    => 'in_progress',
            ],
            'started_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'submitted_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('quiz_id', 'quizzes', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('quiz_attempts', true);

        // 12. Table quiz_attempt_answers
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'attempt_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'question_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'user_answer' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'is_correct' => [
                'type'       => 'TINYINT',
                'constraint' => 1,
                'default'    => 0,
            ],
            'score_earned' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 0.00,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('attempt_id', 'quiz_attempts', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('question_id', 'questions', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('quiz_attempt_answers', true);

        // ==========================================
        // FASE 4: Simulasi Resume Medis & Kasus Klinis
        // ==========================================

        // 13. Table clinical_cases
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'case_number' => [
                'type'       => 'VARCHAR',
                'constraint' => '30',
            ],
            'title' => [
                'type'       => 'VARCHAR',
                'constraint' => '200',
            ],
            'patient_name' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'patient_age' => [
                'type'       => 'VARCHAR',
                'constraint' => '30',
            ],
            'patient_gender' => [
                'type'       => 'ENUM',
                'constraint' => ['L', 'P'],
            ],
            'admission_type' => [
                'type'       => 'VARCHAR',
                'constraint' => '50',
                'default'    => 'Rawat Inap',
            ],
            'chief_complaint' => [
                'type' => 'TEXT',
            ],
            'history_illness' => [
                'type' => 'TEXT',
            ],
            'physical_exam' => [
                'type' => 'TEXT',
            ],
            'diagnostic_tests' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'medical_therapy' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'attending_physician_notes' => [
                'type' => 'TEXT',
            ],
            'difficulty' => [
                'type'       => 'ENUM',
                'constraint' => ['dasar', 'menengah', 'kompleks'],
                'default'    => 'menengah',
            ],
            'status' => [
                'type'       => 'ENUM',
                'constraint' => ['draft', 'terbit'],
                'default'    => 'terbit',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->createTable('clinical_cases', true);

        // 14. Table case_keys
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'case_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'primary_diagnosis_title' => [
                'type'       => 'VARCHAR',
                'constraint' => '200',
            ],
            'primary_icd_code' => [
                'type'       => 'VARCHAR',
                'constraint' => '20',
            ],
            'primary_alternatives' => [
                'type' => 'TEXT', // JSON array
                'null' => true,
            ],
            'secondary_codes' => [
                'type' => 'TEXT', // JSON: [{"title": "...", "code": "..."}]
                'null' => true,
            ],
            'additional_codes' => [
                'type' => 'TEXT', // JSON: dagger/asterisk, external causes
                'null' => true,
            ],
            'lead_term_steps' => [
                'type' => 'TEXT',
            ],
            'tabular_check_steps' => [
                'type' => 'TEXT',
            ],
            'inclusion_exclusion_notes' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'reference_source' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('case_id', 'clinical_cases', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('case_keys', true);

        // 15. Table case_submissions
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'case_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'user_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'total_score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 0.00,
            ],
            'primary_score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 0.00,
            ],
            'secondary_score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 0.00,
            ],
            'additional_score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 0.00,
            ],
            'dosen_override_score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'null'       => true,
            ],
            'dosen_notes' => [
                'type' => 'TEXT',
                'null' => true,
            ],
            'submitted_at' => [
                'type' => 'DATETIME',
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('case_id', 'clinical_cases', 'id', 'CASCADE', 'CASCADE');
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('case_submissions', true);

        // 16. Table case_submission_details
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'submission_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'component_type' => [
                'type'       => 'ENUM',
                'constraint' => ['primary', 'secondary', 'additional'],
            ],
            'input_diagnosis_text' => [
                'type'       => 'VARCHAR',
                'constraint' => '200',
            ],
            'input_icd_code' => [
                'type'       => 'VARCHAR',
                'constraint' => '20',
            ],
            'match_level' => [
                'type'       => 'ENUM',
                'constraint' => ['full', '4_char', '3_char', 'none'],
                'default'    => 'none',
            ],
            'earned_score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 0.00,
            ],
            'max_score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 50.00,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('submission_id', 'case_submissions', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('case_submission_details', true);

        // ==========================================
        // FASE 5: Analitik Kompetensi & Pengumuman
        // ==========================================

        // 17. Table competency_scores
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'user_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'chapter_code' => [
                'type'       => 'VARCHAR',
                'constraint' => '20',
            ],
            'chapter_name' => [
                'type'       => 'VARCHAR',
                'constraint' => '150',
            ],
            'score' => [
                'type'       => 'DECIMAL',
                'constraint' => '5,2',
                'default'    => 0.00,
            ],
            'total_assessments' => [
                'type'       => 'INT',
                'constraint' => 5,
                'default'    => 1,
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('user_id', 'users', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('competency_scores', true);

        // 18. Table announcements
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 11,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'class_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
                'null'       => true,
            ],
            'author_id' => [
                'type'       => 'INT',
                'constraint' => 11,
                'unsigned'   => true,
            ],
            'title' => [
                'type'       => 'VARCHAR',
                'constraint' => '200',
            ],
            'content' => [
                'type' => 'TEXT',
            ],
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        $this->forge->addForeignKey('author_id', 'users', 'id', 'CASCADE', 'CASCADE');
        $this->forge->createTable('announcements', true);
    }

    public function down()
    {
        $this->forge->dropTable('announcements', true);
        $this->forge->dropTable('competency_scores', true);
        $this->forge->dropTable('case_submission_details', true);
        $this->forge->dropTable('case_submissions', true);
        $this->forge->dropTable('case_keys', true);
        $this->forge->dropTable('clinical_cases', true);
        $this->forge->dropTable('quiz_attempt_answers', true);
        $this->forge->dropTable('quiz_attempts', true);
        $this->forge->dropTable('quiz_questions', true);
        $this->forge->dropTable('quizzes', true);
        $this->forge->dropTable('question_options', true);
        $this->forge->dropTable('questions', true);
        $this->forge->dropTable('icd10_codes', true);
        $this->forge->dropTable('medical_terms', true);
        $this->forge->dropTable('student_topic_progress', true);
        $this->forge->dropTable('materials', true);
        $this->forge->dropTable('topics', true);
        $this->forge->dropTable('modules', true);
    }
}
