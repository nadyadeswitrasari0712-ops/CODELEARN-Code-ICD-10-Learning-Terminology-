<?php
/**
 * Front Controller Proxy for CodeLearn
 */
require_once __DIR__ . '/public/index.php';
